col parameter format a500
col parameter format a500
select sid || '.' || name || '=' || value
  from V$SPPARAMETER
 where ISSPECIFIED = 'TRUE'
   and sid <> '*'
union
select a.sid || '.' || rp.name || '=' ||
       case when a.value >= rp.use_larger_value
         then a.value
         else rp.use_larger_value
       end
  from V$SPPARAMETER a,
        dba_ora.SPFILE_PARAMETERS_10G@rm_temp rp
  where rp.name = 'sga_target'
    and a.name = 'sga_max_size'
union
select '*.' || a.name || '=' ||
      (case when a.type = 2 then chr(39) end) ||
       case when rp.gsk_value is not null
         then rp.gsk_value
         else (case when rp.use_9i_value_flg is not null
                 then (case when a.type = 2
                         then replace(a.value,', ',chr(39) || ',' || chr(39))
                         else a.value
                       end)
                 else (case when a.type = 3 
                         then (case when to_number(a.value) >= to_number(rp.use_larger_value)
                                 then a.value
                                 else (case when to_number(rp.use_larger_value) > to_number(rp.default_value)
                                         then rp.use_larger_value
                                       end)
                               end)
                         else (case when a.value >= rp.use_larger_value
                                 then a.value
                                 else (case when rp.use_larger_value > rp.default_value
                                         then rp.use_larger_value
                                       end)
                               end)
                       end)
               end)
       end
      || (case when a.type = 2 then chr(39) end) parameter
  from v$parameter a,
       dba_ora.SPFILE_PARAMETERS_10G@rm_temp rp
  where a.name (+) = rp.name
    and rp.use_10g_value_flg is null
    and a.ISDEFAULT = 'FALSE'
    and a.name <> 'sga_max_size'
    and a.name not in (select sp.name from V$SPPARAMETER sp where sp.ISSPECIFIED = 'TRUE' and sp.sid <> '*')
    and (rp.gsk_value is not null
         or rp.use_9i_value_flg is not null
         or a.value >= rp.use_larger_value
         or rp.use_larger_value > rp.default_value)
;
