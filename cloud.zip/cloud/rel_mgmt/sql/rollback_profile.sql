set pagesize 1000 linesize 132
set echo off feedback off heading off trimspool on

accept sid prompt "Enter SID -> "

spool rollback_&&sid..sql

select command from dba_ora.rm_undo order by cmd_seq;

spool off

spool rollback_&&sid..log

set echo on feedback on heading on

@rollback_&&sid..sql

spool off
