SET SERVEROUTPUT ON

-- This routine should be run as SYS.

-- This code resolves CPUOct2007 published Bug 6510213
--  as documented in Note:464862.1
-- 
-- tob50752 20080219  Initial filing.
--
DECLARE

   v_grantee dba_role_privs.grantee%TYPE;

   TYPE GRANTEECurTyp IS REF CURSOR;

   c_cursor1       GRANTEECurTyp;
   sql_stmt        VARCHAR2(300);
   v_count         NUMBER;

-- Declare Exceptions
--
   no_CPUOct2007   EXCEPTION;
   no_registry     EXCEPTION;

   v_sqlcode       NUMBER;
   v_sqlerrm       VARCHAR2(512);

BEGIN

   -- Reset DBMS_OUTPUT.
   --
   DBMS_OUTPUT.DISABLE;
   DBMS_OUTPUT.ENABLE(50000);

   -- Verify Patch Registry Table exists.
   --
   SELECT count(*) INTO v_count 
   FROM sys.dba_tables
   WHERE table_name =  'REGISTRY$HISTORY'
   AND   owner      =  'SYS';

   IF v_count = 0 THEN
      RAISE no_registry;
   END IF;

   -- Verify CPU Patch was run.
   --
   SELECT count(*) INTO v_count 
   FROM sys.registry$history
   WHERE comments LIKE 'CPUOct2007%';

   IF v_count = 0 THEN
      RAISE no_CPUOct2007;
   END IF;

   --  Get grantees that have EXP_FULL_DATABASE privs.
   --
   sql_stmt := 'SELECT grantee FROM dba_role_privs ' || 
   'WHERE grantee != ' || '''SYS'''                  ||
   'AND granted_role IN '                            || 
   '(' || '''EXP_FULL_DATABASE'''    ||
   ',' || '''DBA'''                  || 
   ')';

   -- Loop throught cursor of grantees and grant permissions.
   --
   OPEN c_cursor1 for sql_stmt;
   LOOP
      FETCH c_cursor1 into v_grantee;
      EXIT WHEN c_cursor1%NOTFOUND;
      EXECUTE IMMEDIATE 'GRANT EXECUTE ON SYS.DBMS_DEFER_IMPORT_INTERNAL TO ' || v_grantee ;
      EXECUTE IMMEDIATE 'GRANT EXECUTE ON SYS.DBMS_EXPORT_EXTENSION      TO ' || v_grantee ;
   END LOOP;

--  Exception Handling.
--
EXCEPTION

   WHEN no_registry   THEN
      DBMS_OUTPUT.put_line('No Registry History Table.');

   WHEN no_CPUOct2007 THEN
      DBMS_OUTPUT.put_line('No CPUOct2007 Applied.');

   WHEN OTHERS THEN  

      DBMS_OUTPUT.PUT_LINE('EXCEPTION ERROR');
      RAISE;

   CLOSE c_cursor1;

END;
/
