Rem
Rem Copyright (c) 2013,2014 Oracle. All rights reserved.
Rem
Rem    NAME
Rem     upg_tzv_check.sql - time zone update check script for 11gR2 (and higher)
Rem  Version 1.9
Rem     published in note 1585343.1 Scripts to automatically update the RDBMS DST (timezone) version in an 11gR2 or 12cR1 database .
Rem
Rem    NOTES
Rem      * This script must be run using SQL*PLUS from the database home.
Rem      * This script must be connected AS SYSDBA to run.
Rem      * The database need to be 11.2.0.1 or higher.
Rem      * The database will NOT be restarted .
Rem      * NO downtime is needed for this script.
Rem   	 * This script takes no arguments.
Rem      * This script WILL exit SQL*PLUS when an error is detected
Rem      * The dba_recyclebin WILL be purged.
Rem      * This script will check for all known issues at time of last update.
Rem      * An UPG_TZV table will be created.
Rem      * TZ_VERSION in Registry$database will be updated with current version.
Rem      * The upg_tzv_apply.sql script depends on this script.
Rem      * The script will write a line into the alert.log when ending succesfully.
Rem
Rem    DESCRIPTION
Rem      This script prepares a database to update the database to the highest
Rem      installed timezone definitions using the upg_tzv_apply.sql script.
Rem
Rem  MODIFIED (MM/DD/YY)
Rem     gvermeir  08/22/14 - updated to handle CDB/PDB (Multitenant) DST updates
Rem     gvermeir  07/10/14 - changed 1882 in DST$ERROR_TABLE from error to warning
Rem     gvermeir  05/23/14 - changed detection of Bug 14732853 to avoid using DBA_TSTZ_TAB_COLS
Rem     gvermeir  03/17/14 - logging of time makes more sense in minutes
Rem     gvermeir  03/04/14 - known bug detection is now faster on some dbs
Rem     gvermeir  02/20/14 - added logging to alert.log
Rem     gvermeir  12/23/13 - minor changes on error handling
Rem     gvermeir  09/20/13 - enhanced error checking and handling
Rem     gvermeir  06/12/13 - enhanced storing of found result
Rem     gvermeir  06/07/13 - corrected check for bug 14732853
Rem     gvermeir  05/16/13 - Additional check added/typos fixed
Rem     gvermeir  05/13/13 - Initial internal release
Rem     gvermeir  04/23/13 - created
Rem
SET TERMOUT OFF
SET SERVEROUTPUT ON
SET FEEDBACK OFF
-- Get time
VARIABLE V_TIME NUMBER 
EXEC :V_TIME := DBMS_UTILITY.GET_TIME
-- Set client_info so one can use:
-- select .... from V$SESSION where CLIENT_INFO = 'upg_tzv';
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('upg_tzv');
whenever SQLERROR EXIT
-- Alter session to avoid performance issues
ALTER session SET nls_sort='BINARY';
-- Faster selects on ALL_TSTZ_TAB_COLS
ALTER session SET "_with_subquery"='MATERIALIZE';
SET TERMOUT ON
-- Check if user is sys
DECLARE
  V_CHECKVAR1 VARCHAR2(10 CHAR);
BEGIN
  EXECUTE immediate 'select substr(SYS_CONTEXT(''USERENV'',''CURRENT_USER''),1,10) from dual' INTO V_CHECKVAR1 ;
  IF V_CHECKVAR1 = TO_CHAR('SYS') THEN
    NULL;
  ELSE
    DBMS_OUTPUT.PUT_LINE('ERROR: Current connection is not a sysdba connection!');
    RAISE_APPLICATION_ERROR(-20001,'Stopping script - see previous message .....');
  END IF;
END;
/
-- Give some info
EXEC DBMS_OUTPUT.PUT_LINE('INFO: Starting with RDBMS DST update preparation.' );
EXEC DBMS_OUTPUT.PUT_LINE('INFO: NO actual RDBMS DST update will be done by this script.' );
EXEC DBMS_OUTPUT.PUT_LINE('INFO: If an ERROR occurs the script will EXIT sqlplus.' );
EXEC DBMS_OUTPUT.PUT_LINE('INFO: Doing checks for known issues ...' );
-- All pre-checks
DECLARE
  V_DBVERSION VARCHAR2(8 CHAR);
  V_ISPDB     VARCHAR2(3 CHAR);
  V_OLDDBTZV  NUMBER;
  V_CHECKNUM1 NUMBER;
  V_CHECKNUM2 NUMBER;
  V_CHECKVAR1 VARCHAR2(255 CHAR);
  V_CHECKVAR2 VARCHAR2(255 CHAR);
BEGIN
  -- Making sure that only Release 11gR2 and up uses this script
  BEGIN
    BEGIN
      EXECUTE immediate 'SELECT substr(VERSION,1,8)from V$INSTANCE' INTO V_DBVERSION ;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
      DBMS_OUTPUT.PUT_LINE('ERROR: VERSION from V$INSTANCE gives no rows.');
      DBMS_OUTPUT.PUT_LINE('ERROR: Do an manual update and checks as documented in ');
      DBMS_OUTPUT.PUT_LINE('ERROR: of note 977512.1 for 11gR2 or note 1509653.1 for 12c.');
      RAISE_APPLICATION_ERROR(-20010,'Stopping script - see previous message .....');
    END;
    IF SUBSTR(V_DBVERSION,1,6) IN ('8.1.7.','8.1.6.','8.1.5.','8.0.6.','8.0.5.','8.0.4.','9.0.1.','9.2.0.','10.1.0','10.2.0','11.1.0') THEN
      DBMS_OUTPUT.PUT_LINE('ERROR: This script cannot be used in Release ' || V_DBVERSION);
      DBMS_OUTPUT.PUT_LINE('ERROR: Please see note 412160.1 for the relevant note ');
      DBMS_OUTPUT.PUT_LINE('ERROR: when applying a DST patch to a database. ');
      DBMS_OUTPUT.PUT_LINE('ERROR: When upgrading to 11.2 or higher you need to run ' );
      DBMS_OUTPUT.PUT_LINE('ERROR: the upg_tzv_check.sql and upg_tzv_apply(_pdb).sql scripts ' );
      DBMS_OUTPUT.PUT_LINE('ERROR: AFTER the RDBMS version upgrade. ' );
      RAISE_APPLICATION_ERROR(-20011,'Stopping script - see previous message .....');
    ELSE
      DBMS_OUTPUT.PUT_LINE('INFO: Database version is '|| V_DBVERSION || ' .');
    END IF;
  END;
  -- check if db is READ WRITE 
  BEGIN
    EXECUTE immediate 'select OPEN_MODE from V$DATABASE' INTO V_CHECKVAR2;
    IF V_CHECKVAR2 != TO_CHAR('READ WRITE') THEN
      DBMS_OUTPUT.PUT_LINE('ERROR: This database is in ' || V_CHECKVAR2 ||' mode.');
      DBMS_OUTPUT.PUT_LINE('ERROR: Please restart the database READ WRITE mode ');
      RAISE_APPLICATION_ERROR(-20021,'Stopping script - see previous message .....');
    END IF;
  END;
  -- check if 12c database is Multitenant or not and warn when updating CDB$ROOT for open PDBs
  V_CHECKVAR1 := SUBSTR(V_DBVERSION,1,4);
  BEGIN
    IF V_CHECKVAR1 IN ('12.1','12.2') THEN
      EXECUTE immediate 'select CDB from V$DATABASE' INTO V_CHECKVAR2;
      IF V_CHECKVAR2 = TO_CHAR('NO') THEN
        V_ISPDB     := TO_CHAR('NO');
      ELSE
        DBMS_OUTPUT.PUT_LINE('INFO: This database is a Multitenant database.');
        EXECUTE immediate 'select SYS_CONTEXT(''USERENV'',''CON_NAME'') from dual' INTO V_CHECKVAR1;
        IF V_CHECKVAR1 = TO_CHAR('CDB$ROOT') THEN
		  DBMS_OUTPUT.PUT_LINE('INFO: Current container is CDB$ROOT .');		
		  DBMS_OUTPUT.PUT_LINE('INFO: Updating the RDBMS DST version of the CDB / CDB$ROOT database ');
		  DBMS_OUTPUT.PUT_LINE('INFO: will NOT update the RDBMS DST version of PDB databases in this CDB.');		
          V_ISPDB := TO_CHAR('NO');
		  EXECUTE immediate 'select count(*) from V$PDBS where NAME != TO_CHAR(''PDB$SEED'') and OPEN_MODE != TO_CHAR(''MOUNTED'')' INTO V_CHECKNUM1;
			IF V_CHECKNUM1 = TO_NUMBER('0') THEN
			  DBMS_OUTPUT.PUT_LINE('INFO: There are no open PDBs .');
			ELSE
			  DBMS_OUTPUT.PUT_LINE('WARNING: There are '|| V_CHECKNUM1 ||' open PDBs .');
			  DBMS_OUTPUT.PUT_LINE('WARNING: They will be closed when running upg_tzv_apply.sql .');
			END IF;
        ELSE
		  DBMS_OUTPUT.PUT_LINE('INFO: This database is a PDB.');
		  DBMS_OUTPUT.PUT_LINE('INFO: Current PDB is '||V_CHECKVAR1||' .');	
          V_ISPDB := TO_CHAR('YES');		
        END IF;
      END IF;
	ELSE
	  V_ISPDB := TO_CHAR('NO');
    END IF;
  END;
  -- Check if DST_UPGRADE_STATE is NONE
  BEGIN
    BEGIN
      EXECUTE immediate 'select substr(PROPERTY_VALUE, 1, 10) from DATABASE_PROPERTIES where PROPERTY_NAME = ''DST_UPGRADE_STATE''' INTO V_CHECKVAR1;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
      DBMS_OUTPUT.PUT_LINE('ERROR: DST_PRIMARY_TT_VERSION from DATABASE_PROPERTIES gives no rows.');
      DBMS_OUTPUT.PUT_LINE('ERROR: Do an manual update and checks as documented in ');
      DBMS_OUTPUT.PUT_LINE('ERROR: of note 977512.1 for 11gR2 or note 1509653.1 for 12c.');
      RAISE_APPLICATION_ERROR(-20031,'Stopping script - see previous message .....');
    END;
    IF V_CHECKVAR1 = TO_CHAR('NONE') THEN
      NULL;
    ELSIF V_CHECKVAR1 = TO_CHAR('PREPARE') THEN
      DBMS_OUTPUT.PUT_LINE('WARNING: Current DST_UPGRADE_STATE is '|| V_CHECKVAR1 || ' !');
      DBMS_OUTPUT.PUT_LINE('WARNING: DST_UPGRADE_STATE in DATABASE_PROPERTIES need to be NONE ');
      DBMS_OUTPUT.PUT_LINE('WARNING: before running upg_tzv_check.sql .');
      DBMS_OUTPUT.PUT_LINE('WARNING: Trying to end PREPARE window and then continue');
      DBMS_DST.END_PREPARE;
      -- if this fails it will error out in next Check if DST_SECONDARY_TT_VERSION is zero check
    ELSIF V_CHECKVAR1 like TO_CHAR('DATAPUMP')||'%' THEN
      DBMS_OUTPUT.PUT_LINE('ERROR: Current DST_UPGRADE_STATE is '|| V_CHECKVAR1 || ' !');
      DBMS_OUTPUT.PUT_LINE('ERROR: DST_UPGRADE_STATE in DATABASE_PROPERTIES need to be NONE ');
      DBMS_OUTPUT.PUT_LINE('ERROR: before running upg_tzv_check.sql .');
      DBMS_OUTPUT.PUT_LINE('ERROR: wait until the datapump load is done or check ');
      DBMS_OUTPUT.PUT_LINE('ERROR: Note 336014.1 How To Cleanup Orphaned DataPump Jobs In DBA_DATAPUMP_JOBS ?');
      RAISE_APPLICATION_ERROR(-20032,'Stopping script - see previous message .....');
    ELSIF V_CHECKVAR1 = TO_CHAR('UPGRADE') THEN
      DBMS_OUTPUT.PUT_LINE('ERROR: Current DST_UPGRADE_STATE is '|| V_CHECKVAR1 || ' !');
      DBMS_OUTPUT.PUT_LINE('ERROR: DST_UPGRADE_STATE in DATABASE_PROPERTIES need to be NONE ');
      DBMS_OUTPUT.PUT_LINE('ERROR: before running upg_tzv_check.sql .');
      DBMS_OUTPUT.PUT_LINE('ERROR: Check if an other DBA is doing a DST upgrade .');
      DBMS_OUTPUT.PUT_LINE('ERROR: If not then do the checks as documented in point 3 ');
      DBMS_OUTPUT.PUT_LINE('ERROR: of note 977512.1 for 11gR2 or note 1509653.1 for 12c .');
      RAISE_APPLICATION_ERROR(-20033,'Stopping script - see previous message .....');
    ELSE
      DBMS_OUTPUT.PUT_LINE('ERROR: Current DST_UPGRADE_STATE is '|| V_CHECKVAR1 || ' !');
      DBMS_OUTPUT.PUT_LINE('ERROR: DST_UPGRADE_STATE in DATABASE_PROPERTIES need to be NONE ');
      DBMS_OUTPUT.PUT_LINE('ERROR: before running upg_tzv_check.sql.');
      DBMS_OUTPUT.PUT_LINE('ERROR: Do the checks as documented in point 3 ');
      DBMS_OUTPUT.PUT_LINE('ERROR: of note 977512.1 for 11gR2 or note 1509653.1 for 12c .');
      RAISE_APPLICATION_ERROR(-20034,'Stopping script - see previous message .....');
    END IF;
  END;
  -- Check if DST_SECONDARY_TT_VERSION is zero
  BEGIN
    BEGIN
      EXECUTE immediate 'select substr(PROPERTY_VALUE, 1, 3) from DATABASE_PROPERTIES where PROPERTY_NAME = ''DST_SECONDARY_TT_VERSION''' INTO V_CHECKNUM1;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
      DBMS_OUTPUT.PUT_LINE('ERROR: DST_PRIMARY_TT_VERSION from DATABASE_PROPERTIES gives no rows.');
      DBMS_OUTPUT.PUT_LINE('ERROR: Do an manual update and checks as documented in ');
      DBMS_OUTPUT.PUT_LINE('ERROR: of note 977512.1 for 11gR2 or note 1509653.1 for 12c.');
      RAISE_APPLICATION_ERROR(-20040,'Stopping script - see previous message .....');
    END;
    IF V_CHECKNUM1 = '0' THEN
      NULL;
    ELSE
      DBMS_OUTPUT.PUT_LINE('ERROR: Current DST_SECONDARY_TT_VERSION is '|| TO_CHAR(V_CHECKNUM1) || ' !');
      DBMS_OUTPUT.PUT_LINE('ERROR: DST_SECONDARY_TT_VERSION in DATABASE_PROPERTIES need to be 0 ');
      DBMS_OUTPUT.PUT_LINE('ERROR: before this script can be run. ');
      DBMS_OUTPUT.PUT_LINE('ERROR: Do the checks as documented in point 3 ');
      DBMS_OUTPUT.PUT_LINE('ERROR: of note 977512.1 for 11gR2 or note 1509653.1 for 12c .');
      RAISE_APPLICATION_ERROR(-20041,'Stopping script - see previous message .....');
    END IF;
  END;
  -- Get current TZ version seen in v$timezone_file
  -- Check that DST_PRIMARY_TT_VERSION value matches VERSION of V$TIMEZONE_FILE
  -- If not then someone messed with the *.dat files (renamed them or made symbolic links)
  BEGIN
    BEGIN
      EXECUTE immediate 'select VERSION from V$TIMEZONE_FILE' INTO V_OLDDBTZV ;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
      DBMS_OUTPUT.PUT_LINE('ERROR: VERSION from V$TIMEZONE_FILE gives no rows.');
      DBMS_OUTPUT.PUT_LINE('ERROR: Do an manual update and checks as documented in ');
      DBMS_OUTPUT.PUT_LINE('ERROR: of note 977512.1 for 11gR2 or note 1509653.1 for 12c.');
      RAISE_APPLICATION_ERROR(-20050,'Stopping script - see previous message .....');
    END;
    BEGIN
      EXECUTE immediate 'select substr(PROPERTY_VALUE, 1, 3) from DATABASE_PROPERTIES where PROPERTY_NAME = ''DST_PRIMARY_TT_VERSION''' INTO V_CHECKNUM1 ;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
      DBMS_OUTPUT.PUT_LINE('ERROR: DST_PRIMARY_TT_VERSION from DATABASE_PROPERTIES gives no rows.');
      DBMS_OUTPUT.PUT_LINE('ERROR: Do an manual update and checks as documented in ');
      DBMS_OUTPUT.PUT_LINE('ERROR: of note 977512.1 for 11gR2 or note 1509653.1 for 12c.');
      RAISE_APPLICATION_ERROR(-20051,'Stopping script - see previous message .....');
    END;
    IF V_OLDDBTZV = V_CHECKNUM1 THEN
      DBMS_OUTPUT.PUT_LINE('INFO: Database RDBMS DST version is DSTv'|| TO_CHAR(V_OLDDBTZV) || ' .');
    ELSE
      DBMS_OUTPUT.PUT_LINE('ERROR: Current Server RDBMS DST version cannot be determined.');
      DBMS_OUTPUT.PUT_LINE('ERROR: Do an manual update and checks as documented in ');
      DBMS_OUTPUT.PUT_LINE('ERROR: of note 977512.1 for 11gR2 or note 1509653.1 for 12c.');
      RAISE_APPLICATION_ERROR(-20052,'Stopping script - see previous message .....');
    END IF;
  END;
  -- REGISTRY$DATABASE cleanup of previous versions of this script
  -- Set TZ_VERSION_UPGRADE column to null if it exists
  BEGIN
    EXECUTE immediate 'update REGISTRY$DATABASE set TZ_VERSION_UPGRADE =  NULL';
	COMMIT;
  EXCEPTION
  WHEN OTHERS THEN
    IF SQLCODE = -904 THEN -- REGISTRY$DATABASE exists but no TZ_VERSION_UPGRADE
      NULL;
    END IF;
    IF SQLCODE = -942 THEN -- no REGISTRY$DATABASE table
      NULL;
    END IF;
  END;
  -- Set TZ_VERSION column to current DST version
  BEGIN
    EXECUTE immediate 'update REGISTRY$DATABASE set TZ_VERSION = :1' USING V_OLDDBTZV;
   COMMIT;	
  EXCEPTION
  WHEN OTHERS THEN
    IF SQLCODE = -904 THEN -- REGISTRY$DATABASE exists but no TZ_VERSION
      NULL;
    END IF;
    IF SQLCODE = -942 THEN -- no REGISTRY$DATABASE table
      NULL;
    END IF;
  END;
  -- Drop table used by this script
  BEGIN
    EXECUTE immediate 'drop table UPG_TZV purge';
  EXCEPTION
  WHEN OTHERS THEN
    IF SQLCODE = -942 THEN -- ignore error if no UPG_TZV table
      NULL;
    END IF;
  END;  
  -- Version dependent checks for known bugs
  -- V_CHECKNUM2 is used to count issues found
  V_CHECKNUM2 := TO_NUMBER('0');
  --  11.2.0.1 only bugs
  IF V_DBVERSION IN ('11.2.0.1') THEN
    -- Check if case insensitive table or column names exist
    -- They give ORA-00904: invalid identifier
    -- or ORA-01747: invalid user.table.column, table.column, or column specification.
    -- Fixed in 11.2.0.2
    BEGIN
      EXECUTE immediate 'select count (*) from DBA_TAB_COLUMNS where DATA_TYPE like ''TIMESTAMP% WITH TIME ZONE'' and ( upper(TABLE_NAME) != TABLE_NAME or upper(COLUMN_NAME) != COLUMN_NAME)' INTO V_CHECKNUM1 ;
      IF V_CHECKNUM1 = TO_NUMBER('0') THEN
        NULL;
      ELSE
        DBMS_OUTPUT.PUT_LINE('ERROR: Case insensitive table or column names exist.');
        DBMS_OUTPUT.PUT_LINE('ERROR: ORA-00904 or ORA-01747 will be seen duing DBMS_DST.');
        DBMS_OUTPUT.PUT_LINE('ERROR: See known issues section of Note 977512.1 .');
        V_CHECKNUM2 := V_CHECKNUM2 + TO_NUMBER('1');
      END IF;
    END;
  END IF;
  -- no 11.2.0.2 only bugs exist
  -- 11.2.0.1, 11.2.0.2, 11.2.0.3 only bugs
  IF V_DBVERSION IN ('11.2.0.1','11.2.0.2','11.2.0.3') THEN
    -- Check if TIMESTAMP WITH TIME ZONE data type as part of an object subtype exist
    -- They give ORA-00907: missing right parenthesis
    -- Bug 13833939 - ora-0907 when preparing for dst upgrade.
    -- Fixed in 11.2.0.4 and 12c
    BEGIN
      EXECUTE immediate 'select count (*) from DBA_TSTZ_TAB_COLS where instr(QUALIFIED_COL_NAME,''TREAT'',1,1) > 0' INTO V_CHECKNUM1 ;
      IF V_CHECKNUM1 = TO_NUMBER('0') THEN
        NULL;
      ELSE
        DBMS_OUTPUT.PUT_LINE('ERROR: TSTZ data type as part of an object subtype exist.');
        DBMS_OUTPUT.PUT_LINE('ERROR: ORA-00907 will be seen during DBMS_DST.');
        DBMS_OUTPUT.PUT_LINE('ERROR: See known issues section of Note 977512.1 ');
        DBMS_OUTPUT.PUT_LINE('ERROR: for bug 13833939 .');
        V_CHECKNUM2 := V_CHECKNUM2 + TO_NUMBER('1');
      END IF;
    END;
    -- Check if there are virtual TSTZ columns
    -- They give ORA-54017: UPDATE operation disallowed on virtual columns
    -- Bug 13436809: ORA-54017 UPDATE OPERATION DISALLOWED ON VIRTUAL COLUMNS ERROR RUNNING DBMS_DST
    -- Fixed in 11.2.0.4 and 12c
    BEGIN
      EXECUTE immediate 'select count (*) from DBA_TAB_COLS C, DBA_OBJECTS O where C.DATA_TYPE like ''%WITH TIME ZONE'' and C.VIRTUAL_COLUMN =''YES'' and O.OBJECT_TYPE = ''TABLE'' and C.OWNER = O.OWNER and C.TABLE_NAME = O.OBJECT_NAME ' INTO V_CHECKNUM1 ;
      IF V_CHECKNUM1 = TO_NUMBER('0') THEN
        NULL;
      ELSE
        DBMS_OUTPUT.PUT_LINE('ERROR: Virtual TSTZ columns exist.');
        DBMS_OUTPUT.PUT_LINE('ERROR: ORA-54017 will be seen during DBMS_DST.');
        DBMS_OUTPUT.PUT_LINE('ERROR: See known issues section of Note 977512.1 ');
        DBMS_OUTPUT.PUT_LINE('ERROR: for bug 13436809 .');
        V_CHECKNUM2 := V_CHECKNUM2 + TO_NUMBER('1');
      END IF;
    END;
  END IF;
  -- Bugs not fixed in 11gR2 or 12c at time of script creation
  -- Check if there are unused TSTZ columns
  -- They give ORA-00904: "T"."SYS_C00001_-random number here-": invalid identifier
  -- Bug 14732853 - DBMS_DST DOES NOT HANDLE UNUSED TIMESTAMP WITH TIME ZONE COLUMNS
  -- NOT Fixed yet
  BEGIN
    EXECUTE immediate 'select count (*) from dba_tab_cols c, DBA_UNUSED_COL_TABS o where c.data_type like ''%WITH TIME ZONE'' and c.owner=o.owner and c.table_name = o.table_name and c.HIDDEN_COLUMN = ''YES''' INTO V_CHECKNUM1 ;
    IF V_CHECKNUM1 = TO_NUMBER('0')THEN
      NULL;
    ELSE
      DBMS_OUTPUT.PUT_LINE('ERROR: Unused TSTZ columns exist.');
      DBMS_OUTPUT.PUT_LINE('ERROR: ORA-00904 will be seen during DBMS_DST.');
      DBMS_OUTPUT.PUT_LINE('ERROR: See the known issues section of  ');
      DBMS_OUTPUT.PUT_LINE('ERROR: note 977512.1 for 11gR2 or note 1509653.1 for 12c .');
      DBMS_OUTPUT.PUT_LINE('ERROR: for bug 14732853 .');
      V_CHECKNUM2 := V_CHECKNUM2 + TO_NUMBER('1');
    END IF;
  END;
  -- Error out if one of above problems is detected
  BEGIN
    IF V_CHECKNUM2 != TO_NUMBER('0') THEN
      RAISE_APPLICATION_ERROR(-20060,'Stopping script - see previous message .....');
    ELSE
      DBMS_OUTPUT.PUT_LINE('INFO: No known issues detected.');
    END IF;
  END;
  -- create table for script
  BEGIN
    EXECUTE immediate 'create table UPG_TZV (NEW_TZ_VERSION number, ISPDB varchar2(3 char))';
  END;
  -- insert row to indicate PDB or not
  BEGIN
    EXECUTE immediate 'insert into UPG_TZV (NEW_TZ_VERSION,ISPDB) values (NULL,:1)' USING V_ISPDB;
	COMMIT;
  END;
  -- End block
END;
/
