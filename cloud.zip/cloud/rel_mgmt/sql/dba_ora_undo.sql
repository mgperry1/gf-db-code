set pagesize 1000 linesize 132
set echo off feedback off heading off trimspool on

accept sid prompt "Enter SID -> "

spool testing_&&sid..sql

select * from dba_ora.rm_undo;

spool off

spool testing_&&sid..log

set echo on feedback on heading on

@testing_&&sid..sql

spool off

