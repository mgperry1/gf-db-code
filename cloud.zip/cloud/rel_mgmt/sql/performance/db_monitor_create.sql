-- This script should be executed as DBA_ORA
set serverout on size 1000000

declare
   v_table_list        VARCHAR2 (1000)
      := 'GV_$SQLTEXT,GV_$SESSION,GV_$SESSION_WAIT,GV_$SQL_PLAN,GV_$SESSION_EVENT,GV_$PROCESS,GV_$LOCK,DBA_JOBS_RUNNING';
      v_bigstr         VARCHAR2 (2000) := v_table_list ;
      v_smlstr         VARCHAR2 (2000) := NULL ;
      v_idxval         NUMBER          := 0 ;
      v_command        VARCHAR (2000)  := NULL ;
      v_no_of_tables   NUMBER          := 0 ;
   BEGIN
--      dbms_output.put_line ('Create Tables Procedure Called')  ;
      LOOP
         v_idxval := INSTR (v_bigstr, ',') ;

         IF v_idxval = 0
         THEN
            v_smlstr := v_bigstr ;
         ELSE
            v_smlstr := SUBSTR (v_bigstr, 1, v_idxval - 1) ;
            v_bigstr := SUBSTR (v_bigstr, v_idxval + 1) ;
         END IF ;

         SELECT COUNT (1)
         INTO   v_no_of_tables
         FROM   dba_tables
         WHERE  owner = 'DBA_ORA' 
         AND    table_name = 'HIST_' || v_smlstr ;

         IF v_no_of_tables = 0
         THEN
            DBMS_OUTPUT.put_line ('Creating Table        : HIST_' || v_smlstr)  ;
            BEGIN
               v_command := 'create table dba_ora.hist_' 
                  || v_smlstr 
                  || ' tablespace tools as SELECT sysdate created, a.* FROM sys.'
                  || v_smlstr
                  || ' a WHERE 1=0 ' ;

               EXECUTE IMMEDIATE v_command ;
            EXCEPTION
               WHEN OTHERS
               THEN
                   dbms_output.put_line ('Error while creating tables.. ' ) ;
                   dbms_output.put_line ('Error Message ' || SQLERRM(SQLCODE) ) ;
            END ;
         END IF ;
         EXIT WHEN v_idxval = 0 ;
      END LOOP ;
      
      SELECT COUNT(1) 
      INTO v_no_of_tables
      FROM dba_tables 
      WHERE owner      = 'DBA_ORA' 
      AND   table_name = 'DB_MONITOR_ALERTING' ;
      
      IF v_no_of_tables = 0 THEN
         v_command := 'create table dba_ora.db_monitor_alerting ' || 
                     '( ' ||
                     'group_email_id            varchar2(100) not null, ' ||
                     'username          varchar2(30), ' ||
                     'terminal          varchar2(30), ' ||
                     'program                   varchar2(48), ' ||
                     'osuser                    varchar2(30), ' ||
                     'resolving_agency  varchar2(50), ' ||
                     'ticket_priority         varchar2(10) ' ||
                     ') tablespace tools ' ;
         EXECUTE IMMEDIATE v_command ;
      END IF ;

      SELECT COUNT(1) 
      INTO v_no_of_tables
      FROM dba_tables 
      WHERE owner      = 'DBA_ORA' 
      AND   table_name = 'DB_MONITOR_ALERTING_LOG' ;
      
      IF v_no_of_tables = 0 THEN
         v_command := 'create table dba_ora.db_monitor_alerting_log ' || 
                     '( ' ||
                     'created    date, ' ||
                     'email_addr varchar(200) ' ||
                     ') tablespace tools ' ;
         EXECUTE IMMEDIATE v_command ;
      END IF ;

      SELECT COUNT(1) 
      INTO v_no_of_tables
      FROM dba_tables 
      WHERE owner      = 'DBA_ORA' 
      AND   table_name = 'DB_MONITOR_IDLE_EVENTS' ;
      
      IF v_no_of_tables = 0 THEN
         v_command := 'create table dba_ora.db_monitor_idle_events ' || 
                     '( ' ||
                     'event VARCHAR2(64 BYTE)  ' ||
                     ') tablespace tools ' ;
         EXECUTE IMMEDIATE v_command ;
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''class slave wait'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''client message'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''DIAG idle wait'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''dispatcher timer'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''gcs for action'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''gcs remote message'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''ges remote message'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''i/o slave wait'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''jobq slave wait'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''lock manager wait for remote message'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''null event'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''parallel query dequeue'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''pipe get'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''PL/SQL lock timer'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''pmon timer'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''PX Deq Credit: need buffer'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''PX Deq Credit: send blkd'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''PX Deq: Execute Reply'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''PX Deq: Execution Msg'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''PX Deq: Join ACK'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''PX Deq: Msg Fragment'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''PX Deq: Par Recov Change Vector'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''PX Deq: Par Recov Execute'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''PX Deq: Par Recov Reply'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''PX Deq: Parse Reply'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''PX Deq: Signal ACK'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''PX Deq: reap credit'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''PX Deq: Table Q Normal'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''PX Deque wait'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''PX Idle Wait'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''queue messages'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''rdbms ipc message'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''single-task message'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''slave wait'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''smon timer'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''SQL*Net message from client'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''SQL*Net message to client'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''SQL*Net more data from client'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''Streams AQ: qmn coordinator idle wait'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''Streams AQ: qmn slave idle wait'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''Streams AQ: RAC qmn coordinator idle wait'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''Streams AQ: waiting for messages in the queue'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''Streams AQ: waiting for time management or cleanup tasks'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''virtual circuit status'')';
         execute immediate 'insert into dba_ora.db_monitor_idle_events values (''wakeup time manager'')';
         execute immediate 'grant select on dba_ora.db_monitor_idle_events to public ' ;
     END IF ;
   END ;
/

CREATE OR REPLACE PACKAGE dba_ora.db_monitor
AS
/******************************************************************************
   Name:       db_monitor
   Author:     Prashant Khandke/Johnny Baker
   Version:    2.0
   Date:       30 Aug 2007

   PURPOSE: Monitor database wait events (includes blocking locks), long running session etc.
   REVISIONS:
   Ver        Date         Author             Description
   ---------  -----------  ---------------    ------------------------------------
   1.0        12 Mar 2007  Prashant Khandke   1. Created this package.
   2.0        19 Dec 2007  JBaker/PKhandke    2. Bug Fix

******************************************************************************/
   v_email_msg          VARCHAR2 (32000) := NULL ;
   v_waits_heading      VARCHAR2 (4000)  := NULL ;
   v_build_user_sql     VARCHAR2 (32000) := NULL ;
   v_send_email_flag    BOOLEAN          := FALSE;
   v_blocking_lock_flag BOOLEAN          := FALSE;
   v_long_running_flag  BOOLEAN          := NULL ;
   v_wait_event_flag    BOOLEAN          := NULL ;
   v_created            DATE             := NULL ;
   gv_wait_time         NUMBER           := 15   ;
   gv_long_run_time     NUMBER           := 3600 ;
   v_table_list         VARCHAR2 (1000)
      := 'GV_$SQLTEXT,GV_$SESSION,GV_$SESSION_WAIT,GV_$SQL_PLAN,GV_$SESSION_EVENT,GV_$PROCESS,GV_$LOCK,DBA_JOBS_RUNNING';

   PROCEDURE get_current_waits (v_wait_time IN NUMBER DEFAULT 15, v_long_run_time IN NUMBER DEFAULT 3600);

   PROCEDURE send_email (p_created IN DATE);

   PROCEDURE purge_old_data (dtk IN NUMBER DEFAULT 30);

   PROCEDURE show_user_sql_long ( p_created   IN   VARCHAR2 DEFAULT TO_CHAR (v_created, 'DD-MON-YYYY HH24:MI:SS')) ;

   PROCEDURE user_sql ( p_created   IN   DATE DEFAULT v_created, p_show IN CHAR DEFAULT 'N', p_resend_email IN CHAR DEFAULT 'N') ;

   PROCEDURE show_buffer (p_buffer  IN VARCHAR2) ;

   PROCEDURE create_tables;
  
   PROCEDURE upgrade_tables ;

END db_monitor;
/
show err

CREATE OR REPLACE PACKAGE BODY DBA_ORA.db_monitor
AS
   PROCEDURE create_tables
   IS
      v_bigstr         VARCHAR2 (2000) := v_table_list ;
      v_smlstr         VARCHAR2 (2000) := NULL ;
      v_idxval         NUMBER          := 0 ;
      v_command        VARCHAR (2000)  := NULL ;
      v_no_of_tables   NUMBER          := 0 ;
   BEGIN
--      dbms_output.put_line ('Create Tables Procedure Called')  ;
      LOOP
         v_idxval := INSTR (v_bigstr, ',') ;

         IF v_idxval = 0
         THEN
            v_smlstr := v_bigstr ;
         ELSE
            v_smlstr := SUBSTR (v_bigstr, 1, v_idxval - 1) ;
            v_bigstr := SUBSTR (v_bigstr, v_idxval + 1) ;
         END IF ;

         SELECT COUNT (1)
         INTO   v_no_of_tables
         FROM   dba_tables
         WHERE  table_name = 'HIST_' || v_smlstr 
         AND    owner = 'DBA_ORA' ;

         IF v_no_of_tables = 0
         THEN
--            DBMS_OUTPUT.put_line ('Creating Table        : HIST_' || v_smlstr)  ;
            BEGIN
               v_command :=
                     'create table dba_ora.hist_'
                  || v_smlstr
                  || ' tablespace tools as SELECT sysdate created, a.* FROM sys.'
                  || v_smlstr
                  || ' a WHERE 1=0 ' ;

               EXECUTE IMMEDIATE v_command ;
            EXCEPTION
               WHEN OTHERS
               THEN
                  v_email_msg :=
                        'DB_MONITOR.create_tables procedure failed to create HIST_'
                     || v_smlstr
                     || CHR (10)
                     || SQLERRM ;
--                  DBMS_OUTPUT.put_line (v_email_msg)  ;
                  v_send_email_flag := TRUE ;
            END ;
         END IF ;

         EXIT WHEN v_idxval = 0 ;
      END LOOP ;
   END ;

   PROCEDURE upgrade_tables
   IS
      v_bigstr         VARCHAR2 (2000) := v_table_list ;
      v_smlstr         VARCHAR2 (2000) := NULL ;
      v_idxval         NUMBER          := 0 ;
      v_command        VARCHAR (2000)  := NULL ;
      v_no_of_tables   NUMBER          := 0 ;
   BEGIN
      LOOP
         v_idxval := INSTR (v_bigstr, ',') ;

         IF v_idxval = 0
         THEN
            v_smlstr := v_bigstr ;
         ELSE
            v_smlstr := SUBSTR (v_bigstr, 1, v_idxval - 1) ;
            v_bigstr := SUBSTR (v_bigstr, v_idxval + 1) ;
         END IF ;

         SELECT COUNT (1)
         INTO   v_no_of_tables
         FROM   dba_tables
         WHERE  table_name = 'HIST_' || v_smlstr
         AND    owner = 'DBA_ORA' ;

         IF v_no_of_tables = 1
         THEN
            DBMS_OUTPUT.put_line ('Re-create Table        : HIST_' || v_smlstr)  ;
            BEGIN
                v_command := 'drop table dba_ora.hist_' || v_smlstr ;
                EXECUTE IMMEDIATE v_command ;

               v_command :=
                     'create table dba_ora.hist_'
                  || v_smlstr
                  || ' tablespace tools as SELECT sysdate created, a.* FROM sys.'
                  || v_smlstr
                  || ' a WHERE 1=0 ' ;

               EXECUTE IMMEDIATE v_command ;
            EXCEPTION
               WHEN OTHERS
               THEN
                  v_email_msg :=
                        'DB_MONITOR.upgrade_tables procedure failed to re-create HIST_'
                     || v_smlstr
                     || CHR (10)
                     || SQLERRM ;
--                  DBMS_OUTPUT.put_line (v_email_msg)  ;
                  v_send_email_flag := TRUE ;
            END ;
         END IF ;

         EXIT WHEN v_idxval = 0 ;
      END LOOP ;
   END ;
 
   PROCEDURE show_buffer (p_buffer IN VARCHAR2) 
   IS
       v_maxlen         CONSTANT PLS_INTEGER := 255; -- max buffer length for dbms_output
       v_newline        CONSTANT VARCHAR2(1) := CHR(10);
       v_space           CONSTANT VARCHAR2(1) := ' ';
       v_pos PLS_INTEGER;
       PROCEDURE dumprecurse ( p_buf IN VARCHAR2 ) IS

       PROCEDURE divdump ( p_txt IN VARCHAR2 , p_pos IN PLS_INTEGER) IS

       BEGIN
           dbms_output.put_line(substr(p_txt,1,p_pos-1));
           dumprecurse(substr(p_txt,p_pos+1));
       END divdump;

       BEGIN
           IF length(p_buf) <= v_maxlen 
           THEN
               dbms_output.put_line(p_buf);
           ELSE
               v_pos := INSTR(p_buf,v_newline);
               IF v_pos BETWEEN 1 and v_maxlen THEN
                   divdump(p_buf,v_pos);
               ELSE
                   v_pos := instr(substr(p_buf,1,v_maxlen),v_space,-1); -- search backwards from the end of the max length
                   IF v_pos NOT BETWEEN 1 and v_maxlen THEN
                      v_pos := v_maxlen ;
                   END IF ;
                   divdump(p_buf,v_pos) ;
               END IF ;
           END IF ;
       END ;

   BEGIN
       dumprecurse(p_buffer);
   END show_buffer ;

   PROCEDURE show_user_sql_long ( p_created   IN   VARCHAR2 DEFAULT TO_CHAR (v_created, 'DD-MON-YYYY HH24:MI:SS'))
   IS
      session   dba_ora.hist_gv_$session%ROWTYPE ;
      process   dba_ora.hist_gv_$process%ROWTYPE ;

      CURSOR session_wait_cur
      IS
         SELECT inst_id, SID, created
         FROM   dba_ora.hist_gv_$session
         WHERE  TO_CHAR (created, 'DD-MON-YYYY HH24:MI:SS') = p_created ;

      CURSOR blocking_cursor (p_created IN DATE)
      IS
         SELECT lh.created h_created, lh.inst_id h_inst_id, lh.sid h_sid,
         lw.inst_id w_inst_id, lw.sid w_sid,
         decode ( lh.type, 'MR', 'Media_recovery',
         'RT', 'Redo_thread',
         'UN', 'User_name',
         'TX', 'Transaction',
         'TM', 'Dml',
         'UL', 'PLSQL User_lock',
         'DX', 'Distrted_Transaxion',
         'CF', 'Control_file',
         'IS', 'Instance_state',
         'FS', 'File_set',
         'IR', 'Instance_recovery',
         'ST', 'Diskspace Transaction',
         'IV', 'Libcache_invalidation',
         'LS', 'LogStaartORswitch',
         'RW', 'Row_wait',
         'SQ', 'Sequence_no',
         'TE', 'Extend_table',
         'TT', 'Temp_table',
         'Nothing-' ) W_Lock_Type,
         decode ( lw.request, 0, 'None',
         1, 'NoLock',
         2, 'Row-Share',
         3, 'Row-Exclusive',
         4, 'Share-Table',
         5, 'Share-Row-Exclusive',
         6, 'Exclusive',
         'Nothing-' ) W_Mode_Req
         FROM dba_ora.hist_gv_$lock lw, dba_ora.hist_gv_$lock lh
         WHERE lh.id1=lw.id1
         AND lh.id2=lw.id2
         AND lh.request=0
         AND lw.lmode=0
         and lw.created = lh.created
         and (lw.created = p_created or lh.created = p_created)
         AND (lh.id1,lh.id2) in (
         SELECT id1,id2 FROM dba_ora.hist_gv_$lock WHERE request=0 and created = p_created
         INTERSECT
         SELECT id1,id2 FROM dba_ora.hist_gv_$lock WHERE lmode=0 and created = p_created
         ) order by h_created ;

   BEGIN
      DBMS_OUTPUT.ENABLE (1000000) ;

      FOR session_rec IN session_wait_cur
      LOOP
         SELECT *
         INTO   session
         FROM   dba_ora.hist_gv_$session
         WHERE  SID = session_rec.SID
         AND    inst_id = session_rec.inst_id
         AND    created = session_rec.created ;

         SELECT *
         INTO   process
         FROM   dba_ora.hist_gv_$process
         WHERE  addr = session.paddr AND created = session.created AND inst_id = session.inst_id ;

         DBMS_OUTPUT.put_line ('=====================================================================') ;
         DBMS_OUTPUT.put_line ('Instance    : ' || session.inst_id) ;
         DBMS_OUTPUT.put_line ('SID/Serial  : ' || session.SID || ',' || session.serial#) ;
         DBMS_OUTPUT.put_line (   'Foreground  : ' || 'PID: ' || session.process || ' - ' || session.program) ;
         DBMS_OUTPUT.put_line (   'Shadow      : ' || 'PID: ' || process.spid || ' - ' || process.program) ;
         DBMS_OUTPUT.put_line (   'Terminal    : ' || session.terminal || '/ ' || process.terminal) ;
         DBMS_OUTPUT.put_line (   'OS User     : ' || session.osuser || ' on ' || session.machine) ;
         DBMS_OUTPUT.put_line ('Ora User    : ' || session.username) ; 
         DBMS_OUTPUT.put_line (   'Status Flags: ' || session.status || ' ' || session.server || ' ' || session.TYPE) ;
         DBMS_OUTPUT.put_line (   'Login Time  : ' || TO_CHAR (session.logon_time, 'Dy HH24:MI:SS')) ;
         DBMS_OUTPUT.put_line (   'Last Call   : ' || TO_CHAR ( SYSDATE - (session.last_call_et / 60 / 60 / 24), 'Dy HH24:MI:SS') ||
                              ' - ' || TO_CHAR (session.last_call_et / 60, '999990.0') || ' min') ;
         DBMS_OUTPUT.put_line ('Current SQL statement:') ;

         FOR c1 IN (SELECT   distinct sql_text, piece
                    FROM     dba_ora.hist_gv_$sqltext
                    WHERE    hash_value = session.sql_hash_value
                    AND      inst_id = session.inst_id
                    AND      created = session.created
                    ORDER BY piece)
         LOOP
            DBMS_OUTPUT.put_line (CHR (9) || c1.sql_text) ;
         END LOOP ;

         DBMS_OUTPUT.put_line ('Previous SQL statement:') ;

         FOR c1 IN (SELECT   distinct sql_text, piece
                    FROM     dba_ora.hist_gv_$sqltext
                    WHERE    hash_value = session.prev_hash_value
                    AND      inst_id = session.inst_id
                    AND      created = session.created
                    ORDER BY piece)
         LOOP
            DBMS_OUTPUT.put_line (CHR (9) || c1.sql_text) ;
         END LOOP ;

         DBMS_OUTPUT.put_line ('Session Waits:') ;

         FOR c1 IN (SELECT state, event
                    FROM   dba_ora.hist_gv_$session_wait
                    WHERE  SID = session.SID
                    AND    inst_id = session.inst_id
                    AND    created = session.created)
         LOOP
            DBMS_OUTPUT.put_line (CHR (9) || c1.state || ': ' || c1.event) ;
         END LOOP ;

         DBMS_OUTPUT.put_line ('=====================================================================') ;
         
      END LOOP ;
   END ;

   PROCEDURE user_sql ( p_created   IN   DATE DEFAULT v_created, p_show IN CHAR DEFAULT 'N', p_resend_email IN CHAR DEFAULT 'N' ) 
   IS
      session                dba_ora.hist_gv_$session%ROWTYPE ;
      process                dba_ora.hist_gv_$process%ROWTYPE ;
      v_step_msg             VARCHAR2(500) := NULL ;
      v_user_sql             VARCHAR2(30000) := NULL ;
      v_formatted_sql        VARCHAR2(30000) := NULL ;
      v_first_rec            BOOLEAN := TRUE ;
      v_block                NUMBER          ;
      v_request              NUMBER          ;
      v_session_tag          VARCHAR2(150)   ;
      v_comma                VARCHAR2(2)     ;

      CURSOR session_wait_cur
      IS
         SELECT inst_id, SID, created
         FROM   dba_ora.hist_gv_$session
         WHERE  created = p_created ;

      CURSOR blocking_cursor (p_created IN DATE) 
      IS 
         SELECT lh.created h_created, lh.inst_id h_inst_id, lh.sid h_sid,
         lw.inst_id w_inst_id, lw.sid w_sid,
         decode ( lh.type, 'MR', 'Media_recovery',
         'RT', 'Redo_thread',
         'UN', 'User_name',
         'TX', 'Transaction',
         'TM', 'Dml',
         'UL', 'PLSQL User_lock',
         'DX', 'Distrted_Transaxion',
         'CF', 'Control_file',
         'IS', 'Instance_state',
         'FS', 'File_set',
         'IR', 'Instance_recovery',
         'ST', 'Diskspace Transaction',
         'IV', 'Libcache_invalidation',
         'LS', 'LogStaartORswitch',
         'RW', 'Row_wait',
         'SQ', 'Sequence_no',
         'TE', 'Extend_table',
         'TT', 'Temp_table',
         'Nothing-' ) W_Lock_Type,
         decode ( lw.request, 0, 'None',
         1, 'NoLock',
         2, 'Row-Share',
         3, 'Row-Exclusive',
         4, 'Share-Table',
         5, 'Share-Row-Exclusive',
         6, 'Exclusive',
         'Nothing-' ) W_Mode_Req,
         o.owner || '.' || o.object_name LOCKED_OBJECT, 
         o.object_type
         FROM dba_ora.hist_gv_$lock lw, dba_ora.hist_gv_$lock lh,dba_objects o, dba_ora.hist_gv_$session s
         WHERE lh.id1=lw.id1
         AND lh.id2=lw.id2
         AND lh.request=0
         AND lw.lmode=0
         AND lw.inst_id = s.inst_id
         AND s.sid = lw.sid
         AND s.row_wait_obj# = o.object_id 
         and lw.created = lh.created
         AND lw.created = s.created 
         and (lw.created = p_created or lh.created = p_created) 
         AND (lh.id1,lh.id2) in (
         SELECT id1,id2 FROM dba_ora.hist_gv_$lock WHERE request=0 and created = p_created
         INTERSECT
         SELECT id1,id2 FROM dba_ora.hist_gv_$lock WHERE lmode=0  and created = p_created
         ) order by h_created ;

   BEGIN
      DBMS_OUTPUT.ENABLE (1000000) ;
      dbms_output.put_line('v_created = ' || to_char(p_created,'mm/dd/yyyy hh24:mi:ss') ) ;
      v_blocking_lock_flag := FALSE;

      FOR blocking_rec in blocking_cursor(p_created)
      LOOP
         IF v_first_rec = TRUE THEN
            v_first_rec := FALSE ;
            v_build_user_sql := v_build_user_sql|| CHR(10)|| 'BLOCKING BLOCKING   WAITING  WAITING' ;
            v_build_user_sql := v_build_user_sql|| CHR(10)|| 'INSTANCE SESSION ID INSTANCE SESSION ID OBJECT_TYPE LOCKED_OBJECT';
            v_build_user_sql := v_build_user_sql|| chr(10)|| '-------- ---------- -------- ---------- ----------- ------------------------------- ' ;
         END IF ;
         v_build_user_sql := v_build_user_sql ||chr(10) ||  
                             LPAD(blocking_rec.h_inst_id,8,' ')   || 
                             LPAD(blocking_rec.h_sid,10,' ')       ||
                             LPAD(blocking_rec.w_inst_id,9,' ')   || 
                             LPAD(blocking_rec.w_sid,11,' ')       || 
                             LPAD(blocking_rec.object_type,12,' ') || '  ' ||
                             blocking_rec.locked_object ;
          dbms_output.put_line('Blocking Lock detected..') ;
          v_blocking_lock_flag := TRUE ;

      END LOOP ;

      IF v_blocking_lock_flag = FALSE THEN
        v_build_user_sql := v_waits_heading ;
      END IF ;

      FOR session_rec IN session_wait_cur
      LOOP
         v_user_sql := NULL ;
         v_step_msg := 'Selecting from DBA_ORA.HIST_GV_$SESSION ' ;

         SELECT *
         INTO   session
         FROM   dba_ora.hist_gv_$session s
         WHERE  s.SID = session_rec.SID
         AND    s.inst_id = session_rec.inst_id
         AND    s.created = session_rec.created ;

         v_step_msg := 'Selecting from DBA_ORA.HIST_GV_$PROCESS ' ;
         SELECT *
         INTO   process
         FROM   dba_ora.hist_gv_$process p
         WHERE  p.addr = session.paddr 
         AND p.created = session.created 
         AND p.inst_id = session.inst_id ;
         
         SELECT sum(block), sum(request)
           INTO v_block, v_request
           FROM dba_ora.hist_gv_$lock l
          WHERE l.created = session.created 
            AND l.inst_id = session.inst_id
            AND l.sid     = session.sid ;
         
         v_session_tag := ' ';
         v_comma       := ' ';  
         IF v_block > 0 AND v_blocking_lock_flag = TRUE THEN
            v_session_tag := v_comma || 'BLOCKER';
            v_comma := ', ';
         END IF;
         IF v_request > 0 THEN
            v_session_tag := v_session_tag || v_comma || 'WAITER';
            v_comma := ', ';
         END IF;
         IF session.last_call_et > gv_long_run_time THEN
            v_session_tag := v_session_tag || v_comma || 'LONG RUNNING';
         END IF;
            
         v_step_msg := 'Building variable V_USER_SQL to attach to email ' ;
         v_user_sql := 
         '========================== ' || v_session_tag || '  ==========================' || chr(10) ||
         'Instance    : ' || session.inst_id || CHR(10) ||
         'SID/Serial  : ' || session.SID || ',' || session.serial# || CHR(10) ||
         'Foreground  : ' || 'PID: ' || session.process || ' - ' || session.program || CHR(10) ||
         'Shadow      : ' || 'PID: ' || process.spid || ' - ' || process.program || chr(10) ||
         'Terminal    : ' || session.terminal || '/ ' || process.terminal || chr(10) ||
         'OS User     : ' || session.osuser || ' on ' || session.machine || chr(10) ||
         'Ora User    : ' || session.username || chr(10) ||
         'Status Flags: ' || session.status || ' ' || session.server || ' ' ||session.TYPE || chr(10) ||
--       'Tran Active : ' || NVL (session.taddr, 'NONE') || chr(10) ||
         'Login Time  : ' || TO_CHAR (session.logon_time, 'Dy HH24:MI:SS') || chr(10) ||
         'Last Call   : ' || TO_CHAR (  SYSDATE - (session.last_call_et / 60 / 60 / 24), 'Dy HH24:MI:SS') || ' - ' || TO_CHAR (session.last_call_et / 60, '999990.0') || ' min' || chr(10) ||
--       'Lock/ Latch : ' || NVL (session.lockwait, 'NONE') || '/ ' || NVL (process.latchwait, 'NONE') || chr(10) ||
--       'Latch Spin  : ' || NVL (process.latchspin, 'NONE') || chr(10) ||
         'Current SQL statement:' || chr(10) ;

         v_formatted_sql := CHR(9) ;
         v_step_msg := 'Selecting Current SQL from DBA_ORA.HIST_GV_$SQLTEXT' ;
         BEGIN
             FOR c1 IN (SELECT   distinct sql_text, piece
                        FROM     dba_ora.hist_gv_$sqltext t
                        WHERE    t.hash_value = session.sql_hash_value
                        AND      t.inst_id = session.inst_id
                        AND      t.created = session.created
                        ORDER BY piece)
             LOOP
                 v_formatted_sql := v_formatted_sql || substr(c1.sql_text,1,instr(c1.sql_text,' ',-1)) || chr(10) 
                                    || chr(9) || substr(c1.sql_text,(instr(c1.sql_text,' ',-1)+1)) ;
             END LOOP ;
         EXCEPTION WHEN value_error THEN
             v_formatted_sql := chr(9) || 'The SQL statement could not be displayed since it is more than 30K bytes' || chr(10) ||
                                chr(9) || 'Please contact Performance Focus Group' ;
         END ;
         IF ( LENGTH(v_user_sql) + LENGTH(v_formatted_sql) ) < 30000 THEN
            v_user_sql := v_user_sql || v_formatted_sql ;
         ELSE
            v_formatted_sql := chr(9) || 'The SQL statement could not be displayed since it is more than 30K bytes' || chr(10) ||
                               chr(9) || 'Please contact Performance Focus Group' ;
            v_user_sql := v_user_sql || v_formatted_sql ;
         END IF ;

         v_formatted_sql := CHR(9) ;
         v_user_sql := v_user_sql || chr(10) || 'Previous SQL statement:' || chr(10) ;
         v_step_msg := 'Selecting Previous SQL from DBA_ORA.HIST_GV_$SQLTEXT' ;

         BEGIN
            FOR c1 IN (SELECT   distinct sql_text, piece
                       FROM     dba_ora.hist_gv_$sqltext t
                       WHERE    t.hash_value = session.prev_hash_value
                       AND      t.inst_id = session.inst_id
                       AND      t.created = session.created
                       ORDER BY piece)
            LOOP
               v_formatted_sql := v_formatted_sql || 
                                  substr(c1.sql_text,1,instr(c1.sql_text,' ',-1)) 
                                  || chr(10) || chr(9) ||
                                  substr(c1.sql_text,(instr(c1.sql_text,' ',-1)+1)) ;
            END LOOP ;
         EXCEPTION WHEN value_error THEN
             v_formatted_sql := chr(9) || 'The SQL statement could not be displayed since it is more than 30K bytes' || chr(10) ||
                                chr(9) || 'Please contact Performance Focus Group' ;
         END ;
         IF ( LENGTH(v_user_sql) + LENGTH(v_formatted_sql) ) < 30000 THEN
            v_user_sql := v_user_sql || v_formatted_sql ;
         ELSE
            v_formatted_sql := chr(9) || 'The SQL statement could not be displayed since it is more than 30K bytes' || chr(10) ||
                               chr(9) || 'Please contact Performance Focus Group' ;
            v_user_sql := v_user_sql || v_formatted_sql ;
         END IF ;
         v_user_sql := v_user_sql || chr(10) || 'Session Waits:' || chr(10) ;
         v_step_msg := 'Selecting Session Waits from DBA_ORA.HIST_GV_$SESSION_WAIT' ;

         FOR c1 IN (SELECT state, event, seconds_in_wait
                    FROM   dba_ora.hist_gv_$session_wait
                    WHERE  SID = session.SID
                    AND    inst_id = session.inst_id
                    AND    created = session.created)
         LOOP
            v_user_sql := v_user_sql || CHR (9) || c1.state || ': ' || c1.event || chr(10) ;
            IF c1.state = 'WAITING' AND c1.seconds_in_wait > (gv_wait_time * 60) AND v_wait_event_flag is NULL THEN
              v_wait_event_flag := TRUE ; 
            END IF ;
         END LOOP ;
         v_user_sql := v_user_sql || '=====================================================================' || chr(10) ;
         v_step_msg := 'Assigning Current User to global variable V_BUILD_USER_SQL ' ;
         v_build_user_sql := v_build_user_sql || chr(10) || v_user_sql ;
      END LOOP ;

      IF upper(p_show) = 'Y' THEN
         show_buffer(v_build_user_sql) ;
      END IF ;
 
      IF upper(p_resend_email) = 'Y' THEN
         send_email(p_created) ;
      END IF ;
      
   EXCEPTION
      WHEN value_error THEN
            NULL ;
      WHEN OTHERS
      THEN
         v_email_msg :=
               v_email_msg
            || CHR (10)
            || 'DB_MONITOR.user_sql failed with '
            || CHR (10)
            || SQLERRM
            || CHR (10)
            || 'Step Message  : '
            || v_step_msg ;
         send_email (v_created) ;
   END ;

   PROCEDURE get_current_waits (v_wait_time IN NUMBER DEFAULT 15, v_long_run_time in NUMBER DEFAULT 3600)
   IS
      v_step_msg           VARCHAR2 (200)  := NULL ;
      v_build_query        VARCHAR2 (1000) := NULL ;
      v_hist_count         NUMBER          := 0 ;
      v_duplicate_count    NUMBER          := 0 ;
      v_duplicate_flag     BOOLEAN         := FALSE ;
      v_created            DATE            := SYSDATE ;
      v_first_rec          BOOLEAN         := TRUE ;

      CURSOR waits (v_wait_time IN NUMBER, v_long_run_time in NUMBER)
      IS
         SELECT /*+ RULE */ inst_id, SID, serial#, sql_address, sql_hash_value, prev_sql_addr, prev_hash_value, paddr,
                last_call_et, logon_time
           FROM SYS.gv_$session
          WHERE (inst_id, SID, serial#) in
                  (SELECT /*+ RULE */ s.inst_id, s.sid, s.serial#
                     FROM  SYS.gv_$session_wait sw, SYS.gv_$session s
                    WHERE  sw.inst_id = s.inst_id
                      AND  sw.SID = s.SID
                      AND  s.status = 'ACTIVE'                                       -- Capture only ACTIVE
                      AND  s.username IS NOT NULL                                    -- Ignore Oracle Sessions
                      AND  s.program NOT LIKE 'rman%'                                -- Ignore RMAN sessions
                      AND  sw.event NOT IN                                           -- Ignore IDLE events
                            ( select /*+ RULE */ event from dba_ora.db_monitor_idle_events
                            )
                      AND  ( ( sw.state = 'WAITING' AND sw.seconds_in_wait >= (v_wait_time * 60) )
                             OR
                             ( s.last_call_et > v_long_run_time
                              AND to_char(SYS_EXTRACT_UTC(localtimestamp),'DY') NOT IN ('SAT','SUN')
                              AND to_char(SYS_EXTRACT_UTC(localtimestamp),'HH24') BETWEEN 7 AND 22
                             )
                           )
                  )
             OR (inst_id, SID) IN (SELECT /*+ RULE */ lh.inst_id, lh.SID
                                      FROM gv$lock lh
                                     WHERE (lh.id1, lh.id2) IN
                                             (SELECT /*+ RULE */ lh.id1, lh.id2 FROM gv$lock lh WHERE request = 0
                                              INTERSECT
                                              SELECT /*+ RULE */ lw.id1, lw.id2 FROM gv$lock lw, SYS.gv_$session_wait sw
                                               WHERE  lmode = 0
                                                 AND    sw.inst_id = lw.inst_id
                                                 AND    sw.SID = lw.SID
                                                 AND    sw.state = 'WAITING'
                                                 AND    sw.seconds_in_wait >= (v_wait_time * 60)
                                             )
                                   ) ;

   BEGIN
      gv_wait_time := v_wait_time;
      gv_long_run_time := v_long_run_time;
      v_step_msg :=
            'Error while selecting in one or following Tables '
         || CHR (10)
         || v_table_list ;
     
      v_blocking_lock_flag := FALSE ;
      v_send_email_flag := FALSE ;

      FOR rec IN waits (v_wait_time, v_long_run_time)
      LOOP
--         v_created := rec.created ;
         
         dbms_output.put_line('1') ;

         select count(1) INTO v_duplicate_count
         from dba_ora.hist_gv_$session hw 
         where hw.inst_id = rec.inst_id 
         and hw.sid = rec.sid 
         and hw.serial# = rec.serial# 
         and hw.LOGON_TIME = rec.LOGON_TIME 
         and hw.LAST_CALL_ET > gv_long_run_time 
         and hw.created > (sysdate - 1) ;
         
         dbms_output.put_line('2') ;

         IF v_duplicate_count > 0 
         THEN
            v_duplicate_flag := TRUE ;
            dbms_output.put_line(rec.inst_id || ' ' || rec.sid || ' ' || rec.serial# || ' ' || to_char(v_created,'mm/dd/yyyy hh24:mi:ss')  || ' ' || to_char(rec.logon_time,'mm/dd/yyyy hh24:mi:ss') );
         END IF ;

         v_send_email_flag := TRUE ;
         dbms_output.put_line('3') ;
         v_step_msg := 'Error while inserting into dba_ora.hist_gv_$session' ;
         v_build_query :=
               ' INSERT INTO dba_ora.hist_gv_$session '
            || ' ( SELECT /*+ RULE */ :1, a.* FROM sys.gv_$session a '
            || '   WHERE a.inst_id = :2 '
            || '   AND a.sid = :3 '
            || '   AND a.serial# = :4 ) ' ;

         EXECUTE IMMEDIATE v_build_query
         USING             v_created, rec.inst_id, rec.SID, rec.serial# ;

         IF rec.last_call_et > gv_long_run_time AND v_long_running_flag is NULL THEN
            v_long_running_flag := TRUE ; 
         END IF ;

         v_step_msg :=
                    'Error while inserting into dba_ora.hist_gv_$session_wait' ;
         v_build_query :=
               ' INSERT INTO dba_ora.hist_gv_$session_wait '
            || ' ( SELECT /*+ RULE */ :1, a.* '
            || '   FROM sys.gv_$session_wait a '
            || '   WHERE a.inst_id = :2 '
            || '    and  a.sid     = :3 ) ' ;

         EXECUTE IMMEDIATE v_build_query
         USING            v_created, rec.inst_id, rec.sid ;

--         IF rec.state = 'WAITING' AND rec.seconds_in_wait > (v_wait_time * 60) AND v_wait_event_flag is NULL THEN
--            v_wait_event_flag := TRUE ; 
--         END IF ;

         v_step_msg :=
                   'Error while inserting into dba_ora.hist_gv_$session_event' ;
         v_build_query :=
               ' INSERT INTO dba_ora.hist_gv_$session_event '
            || ' ( SELECT /*+ RULE */ :1, a.* '
            || '   FROM sys.gv_$session_event a '
            || '   WHERE a.inst_id = :2 '
            || '   AND a.sid = :3) ' ;

         EXECUTE IMMEDIATE v_build_query
         USING            v_created, rec.inst_id, rec.SID ;

         v_step_msg := 'Error while inserting into dba_ora.hist_gv_$sqltext' ;
         BEGIN 
            v_build_query :=
                  ' INSERT INTO dba_ora.hist_gv_$sqltext '
               || ' ( SELECT /*+ RULE */ :1, a.* '
               || '   FROM sys.gv_$sqltext a '
               || '   WHERE (a.inst_id = :2 AND a.hash_value = :3) '
               || '      OR (a.inst_id = :4 AND a.hash_value = :5)) ' ;

            EXECUTE IMMEDIATE v_build_query
            USING            v_created, rec.inst_id, rec.sql_hash_value, rec.inst_id, rec.prev_hash_value ;

         EXCEPTION 
         WHEN OTHERS THEN 
             dbms_output.put_line('Exception 1 in get_current_waits') ;
             NULL ;
         END ;

         BEGIN
             v_step_msg := 'Error while inserting into dba_ora.hist_gv_$sql_plan' ;
             v_build_query :=
                   ' INSERT INTO dba_ora.hist_gv_$sql_plan '
                || ' ( SELECT /*+ RULE */ :1, a.* '
                || '   FROM sys.gv_$sql_plan a '
                || '   WHERE a.inst_id = :2 '
                || '   AND a.address = :3) ' ;

             EXECUTE IMMEDIATE v_build_query
             USING            v_created, rec.inst_id, rec.sql_address ;
         EXCEPTION 
         WHEN OTHERS THEN 
             dbms_output.put_line('Exception 2 in get_current_waits') ;
             NULL ;
         END ;

         v_step_msg := 'Error while inserting into dba_ora.hist_gv_$process' ;
         v_build_query :=
               ' INSERT INTO dba_ora.hist_gv_$process '
            || ' ( SELECT /*+ RULE */ :1, a.* '
            || ' FROM sys.gv_$process a '
            || ' WHERE a.inst_id = :2 '
            || ' AND a.addr = :3) ' ;

         EXECUTE IMMEDIATE v_build_query
         USING            v_created, rec.inst_id, rec.paddr ;
        
         v_step_msg := 'Error while inserting into dba_ora.hist_gv_$lock' ;
         v_build_query := ' INSERT INTO dba_ora.hist_gv_$lock '
                       || ' (SELECT /*+ RULE */ :1, l.* '
                       || '  FROM sys.gv_$lock l '
                       || ' WHERE l.inst_id = :2 '
                       || ' AND l.sid = :3) ' ;
 
         EXECUTE IMMEDIATE v_build_query
         USING            v_created, rec.inst_id, rec.sid ;
         
         dbms_output.put_line('Number of rows inserted in gv$lock : ' || sql%rowcount) ;

         IF v_first_rec = TRUE THEN
            dbms_output.put_line('v_first_rec = TRUE' ) ;
            v_step_msg := 'Error while inserting into dba_ora.hist_dba_jobs_running' ;
            v_build_query := ' INSERT INTO dba_ora.hist_dba_jobs_running '
                          || ' ( SELECT /*+ RULE */ :1, a.* '
                          || ' FROM dba_jobs_running a ) ' ;

/*                          || ' SELECT ' ||
                          || '  s.inst_id, ' || 
                          || '   jr.job, ' || 
                          || '   s.username, ' || 
                          || '   s.sid, ' || 
                          || '   s.serial#, ' || 
                          || '   p.spid, ' || 
                          || '   s.lockwait, ' || 
                          || '   s.logon_time ' || 
                          || 'from ' || 
                          || '   (select v.inst_id, v.sid, v.id2 job, j.field1 instance from sys.job$ j, gv$lock v ' || 
                          || '    where v.type = 'JQ' and j.job (+)= v.id2 )  jr, ' || 
                          || '   gv$session s, ' || 
                          || '   gv$process p ' || 
                          || 'where jr.inst_id = s.inst_id ' || 
                          || 'and   s.inst_id = p.inst_id ' || 
                          || 'and   jr.sid = s.sid ' || 
                          || 'and   s.paddr = p.addr ' ||  
*/


            EXECUTE IMMEDIATE v_build_query
            USING            v_created ;
   
            v_first_rec := FALSE ;
            v_waits_heading := CHR (10)
                 || '              Long Running/Waiting Sessions Summary at '
                 || TO_CHAR (v_created, 'DD-MON-YYYY HH24:MI:SS')
                 || CHR (10)
                 || CHR (10)
                 || ' Inst     Session'
                 || CHR (10)
                 || '  ID        ID       SERIAL#       LOGON DATE TIME         TIME ACTIVE (Min)'
                 || CHR (10)
                 || '-----  ----------    -------    ----------------------    ------------------' ;

         END IF ;
         dbms_output.put_line('4') ;

         v_waits_heading :=
               v_waits_heading
            || CHR (10)
            || LPAD (rec.inst_id, 5, ' ')
            || LPAD (rec.SID, 12, ' ')
            || LPAD (rec.serial#, 11, ' ')
            || LPAD (to_char(rec.logon_time,'DD-MON-YYYY HH24:MI:SS'), 26, ' ') 
            || LPAD (ROUND (rec.last_call_et / 60), 22, ' ');

      END LOOP ;

      COMMIT ;

 
      v_step_msg := 'Error while checking if data older than 30 days exist' ;
      v_build_query := ' SELECT COUNT (1) ' ||
                       ' FROM   dba_ora.hist_gv_$session ' ||
                       ' WHERE  ROUND (SYSDATE - created) > 30 ' ;

      EXECUTE IMMEDIATE v_build_query into v_hist_count ;
      IF v_hist_count > 0
      THEN
         purge_old_data ;
      END IF ;

      IF ( v_send_email_flag = TRUE ) AND ( v_duplicate_flag = FALSE )
      THEN
         dbms_output.put_line('v_send_email_flag=TRUE and (v_blocking_lock_flag=TRUE or v_duplicate_flag=FALSE)') ;
         user_sql(v_created) ;
         send_email (v_created) ;
      ELSE 
--       This block of code is just for tracing
         IF v_send_email_flag = FALSE AND v_blocking_lock_flag = TRUE THEN
            dbms_output.put_line('e=FALSE blocking=TRUE') ;
         ELSE
            dbms_output.put_line('d=TRUE d_count='|| v_duplicate_count) ;
         END IF ;
      END IF ;
   EXCEPTION
      WHEN OTHERS
      THEN
         dbms_output.put_line('exception others in get_current_waits') ;
         dbms_output.put_line('Step Message : '|| v_step_msg ) ;
         v_email_msg := v_email_msg || CHR (10) || 'DB_MONITOR.get_current_waits failed with ' || CHR (10) || SQLERRM
                        || CHR (10) || 'Step Message  : ' || v_step_msg ; send_email (v_created) ;
   END ;

   PROCEDURE send_email (p_created IN DATE) 
   IS
      v_connection        UTL_SMTP.connection ;
      v_hostname          v$instance.host_name%TYPE       := NULL ;
      v_instance_name     v$instance.instance_name%TYPE   := NULL ;
      v_database_name     v$database.NAME%TYPE            := NULL ;
      v_email_ids         VARCHAR2(200)                   := NULL ;
      v_header            VARCHAR2(1000)                  := NULL ;
      v_all_rcpt          VARCHAR2(1000)                  := NULL ;
      v_special_msg       VARCHAR2(2000)                  := NULL ;
      v_long_running_msg  VARCHAR2(2000)                  := NULL ;
      v_wait_event_msg    VARCHAR2(2000)                  := NULL ;
      v_recipient         VARCHAR2(50)                    := 'IT_DbS-Performance-Group@gsk.com' ;

   BEGIN
      SELECT instance_name, host_name
      INTO   v_instance_name, v_hostname
      FROM   v$instance ;

      SELECT NAME
      INTO   v_database_name
      FROM   v$database ;

      v_connection := UTL_SMTP.open_connection (v_hostname, 25) ;
      UTL_SMTP.helo (v_connection, 'gsk.com') ;
      UTL_SMTP.mail (v_connection, 'oracle@' || v_hostname) ;
      
      FOR session_wait_rec in ( select distinct upper(s.username) username,
                                       upper(s.program) program,
                                       upper(s.osuser) osuser,
                                       upper(p.terminal) terminal
                                from dba_ora.hist_gv_$session s,dba_ora.hist_gv_$process p
                                where s.inst_id = p.inst_id
                                and   s.created = p.created
                                and   s.created = p_created ) 
      LOOP
         FOR mail_rcpt_rec in ( select distinct group_email_id from dba_ora.db_monitor_alerting
                                     where decode(username,NULL,'T',decode(username,session_wait_rec.username,'T','F') ) = 'T'
                                       and decode(terminal,NULL,'T',decode(terminal,session_wait_rec.terminal,'T','F') ) = 'T'
                                       and decode(program ,NULL,'T',decode(program ,session_wait_rec.program ,'T','F') ) = 'T'
                                       and decode(osuser  ,NULL,'T',decode(osuser  ,session_wait_rec.osuser  ,'T','F') ) = 'T' )
         LOOP
             dbms_output.put_line('Username :' ||session_wait_rec.username||
                                  ' Program : '||session_wait_rec.program|| 
                                  'id : ' || mail_rcpt_rec.group_email_id) ;
             utl_smtp.rcpt(v_connection, mail_rcpt_rec.group_email_id ) ;
             v_all_rcpt := v_all_rcpt || mail_rcpt_rec.group_email_id || ',' ; 
         END LOOP ;
      END LOOP ;
      IF v_all_rcpt IS NULL THEN
         utl_smtp.rcpt(v_connection, v_recipient ) ;
         dbms_output.put_line('EMAIL sent to ' || v_recipient) ;
      ELSE
         v_all_rcpt := substr(v_all_rcpt,1,(length(v_all_rcpt)-1)) ;
         dbms_output.put_line('EMAIL sent to ' || v_all_rcpt) ;
      END IF ;
      
      INSERT INTO db_monitor_alerting_log (created,email_addr) VALUES (p_created,decode(v_all_rcpt,NULL,v_recipient,v_all_rcpt)) ;

      COMMIT ;

      UTL_SMTP.open_data (v_connection) ;

      v_header := 'From: oracle@' || v_hostname || UTL_TCP.crlf || 
                  'Subject: DB_MONITOR Wait Events in '||v_instance_name||' on '||v_hostname || UTL_TCP.crlf ;

      IF v_long_running_flag = TRUE THEN
         v_special_msg := 'Automated monitoring for Database Services has detected the SQL below is executing longer than 60 minutes or has encountered resource locks. You are being notified because you are setup as a contact for the Oracle user executing this SQL. Please investigate the problem SQL and take appropriate actions to address it. ' || chr(10) || chr(10) ||
'SQL transactions that take longer than 60 minutes should not be executed during core business hours (M-F 8am - 10pm UK time) due to the possible impact on other users and databases in the shared services environment. ' || chr(10) || chr(10) ||
'You may contact the database performance group at IT_DbS-Performance-Group if you have questions. ' ;
         v_header := 'From: oracle@' || v_hostname || UTL_TCP.crlf || 
                     'Subject: DB_MONITOR Wait Events (long running) in '||v_instance_name || ' on ' || v_hostname || UTL_TCP.crlf ;
      END IF ;

      IF v_wait_event_flag = TRUE THEN
         v_special_msg := 'Automated monitoring for Database Services has detected the SQL below is waiting for resource or has encountered resource locks. You are being notified because you are setup as a contact for the Oracle user executing this SQL. Please investigate the problem SQL and take appropriate actions to address it. ' || chr(10) || chr(10) ||
'If this event is not cleared or actioned immediately, you will receive email every 10 minutes. ' || chr(10) || chr(10) ||
'You may contact the database performance group at IT_DbS-Performance-Group if you have questions. ' ;
         v_header := 'From: oracle@' || v_hostname || UTL_TCP.crlf || 
                     'Subject: DB_MONITOR Wait Events (resource wait) in '||v_instance_name||' on '||v_hostname || UTL_TCP.crlf ;
      END IF ;

      IF v_blocking_lock_flag = TRUE THEN
         v_special_msg := 'Automated monitoring for Database Services has detected blocking lock(s). You are being notified because you are setup as a contact for the Oracle user executing this SQL. Please investigate the problem SQL and take appropriate actions to address it. ' || chr(10) || chr(10) ||
'If this event is not cleared or actioned immediately, you will receive email every 10 minutes. ' || chr(10) || chr(10) ||
'You may contact the database performance group at IT_DbS-Performance-Group if you have questions. ' ;
         v_header := 'From: oracle@' || v_hostname || UTL_TCP.crlf || 
                     'Subject: DB_MONITOR Wait Events (blocking lock) in '||v_instance_name||' on '||v_hostname || UTL_TCP.crlf ;
      END IF ;

      IF v_all_rcpt IS NULL THEN
         v_header := v_header || 'To: ' || v_recipient || UTL_TCP.crlf ;
      ELSE
         v_header := v_header || 'To: ' || v_all_rcpt || UTL_TCP.crlf ;
      END IF ;

      UTL_SMTP.write_data (v_connection, v_header) ;
      UTL_SMTP.write_data (v_connection, UTL_TCP.crlf || v_special_msg || chr(10) || chr(10) || v_email_msg || v_build_user_sql ) ;
      UTL_SMTP.close_data (v_connection) ;
      UTL_SMTP.quit (v_connection) ;
   EXCEPTION
      WHEN UTL_SMTP.transient_error OR UTL_SMTP.permanent_error
      THEN
         COMMIT ;
         BEGIN
            UTL_SMTP.quit (v_connection) ;
         EXCEPTION
            WHEN UTL_SMTP.transient_error OR UTL_SMTP.permanent_error
            THEN
               NULL ;
                -- When the SMTP server is down or unavailable, we don't have
                -- a connection to the server. The quit call will raise an
                -- exception that we can ignore.
         END ;
         raise_application_error (-20000,
                            'DBA_ORA.DB_MONITOR - Failed to send mail due to the following error: ' || SQLERRM) ;
      WHEN OTHERS THEN
           COMMIT ;
   END ;

   PROCEDURE purge_old_data (dtk IN NUMBER DEFAULT 30)
   IS
      v_bigstr         VARCHAR2 (2000) := v_table_list ;
      v_smlstr         VARCHAR2 (2000) := NULL ;
      v_idxval         NUMBER          := 0 ;
      v_command        VARCHAR (2000)  := NULL ;
      v_no_of_tables   NUMBER          := 0 ;
      v_step_msg       VARCHAR2 (1000) := NULL ;
   BEGIN
      LOOP
         v_idxval := INSTR (v_bigstr, ',') ;

         IF v_idxval = 0
         THEN
            v_smlstr := v_bigstr ;
         ELSE
            v_smlstr := SUBSTR (v_bigstr, 1, v_idxval - 1) ;
            v_bigstr := SUBSTR (v_bigstr, v_idxval + 1) ;
         END IF ;

         SELECT COUNT (1)
         INTO   v_no_of_tables
         FROM   user_tables
         WHERE  table_name = 'HIST_' || v_smlstr ;

         v_step_msg := 'Deleting rows from DBA_ORA.HIST_' || v_smlstr ;

--         dbms_output.put_line ('Deleting rows more than ' || dtk || ' old FROM HIST_' || v_smlstr)  ;
         IF v_no_of_tables = 1
         THEN
            BEGIN
               v_command :=
                     'DELETE FROM dba_ora.hist_'
                  || v_smlstr
                  || ' WHERE round(sysdate-created ) > '
                  || dtk ;

               EXECUTE IMMEDIATE v_command ;
            EXCEPTION
               WHEN OTHERS
               THEN
                  v_email_msg :=
                        'DB_MONITOR.purge_old_data procedure failed to delete '
                     || v_smlstr
                     || CHR (10)
                     || SQLERRM ;
                  v_step_msg := 'Step Message  : ' || v_step_msg ;
                  v_email_msg := v_email_msg || CHR (10) || v_step_msg ;
--                  DBMS_OUTPUT.put_line (v_email_msg)  ;
            END ;
         END IF ;

         EXIT WHEN v_idxval = 0 ;
      END LOOP ;

      COMMIT ;
   END ;
BEGIN
   DBMS_OUTPUT.ENABLE (1000000) ;
   create_tables ;
END db_monitor; 
/
