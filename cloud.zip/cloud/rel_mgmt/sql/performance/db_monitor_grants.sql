-- This SQL should be executed as SYS
grant select on sys.GV_$SQLAREA to dba_ora ;
grant select on sys.GV_$SESSION to dba_ora ;
grant select on sys.GV_$SESSION_WAIT to dba_ora ;
grant select on sys.GV_$SQL_PLAN to dba_ora ;
grant select on sys.GV_$SESSION_EVENT to dba_ora ;
grant select on sys.GV_$PROCESS to dba_ora ;
grant select on sys.GV_$LOCK to dba_ora ;
grant select on sys.GV_$SQLTEXT to dba_ora ;
grant select on sys.V_$INSTANCE  to dba_ora ;
grant select on sys.V_$DATABASE  to dba_ora ;
grant select on dba_tables  to dba_ora ;
grant select on dba_objects  to dba_ora ;
grant select on dba_jobs_running to dba_ora ;
