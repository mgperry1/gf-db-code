-- This script must be executed as DBA_ORA
declare
 jobno number;
begin
  for c1 in (
          select
           job
          from user_jobs
          where lower(what) like '%dba_ora.db_monitor.get_current_waits%'
            )
   loop
      DBMS_JOB.remove(c1.job);
   end loop;
  DBMS_JOB.submit (job            => jobno,
                   what           => 'dba_ora.db_monitor.get_current_waits;',
                   next_date      => SYSDATE,
                   INTERVAL       => 'SYSDATE+10/1440 ',
                   no_parse       => TRUE
                  );
  commit;
end;
/
