connect dba_ora/&&1&&2@&&3
alter session set global_names=false;
delete from ahs_sdba.discovery_test@report_upload.world
where 
database_name = upper('&&2')
and hostname = upper('&&3')
and TEST_NAME = upper('DEFAULT_USER_EXEC')
/
commit;
insert into ahs_sdba.discovery_test@report_upload.world
(
PROCESS
,TEST_NAME
,HOSTNAME
,GLOBAL_NAME
,DATABASE_NAME
,COMP_INV_ID
,TEST_VALUE
,TEST_RESULT
,TEST_STATUS
)
select
'DISCOVERY'
,'TZ_PARMS'
,H.HOSTNAME
,G.DATABASE_NAME
,D.DATABASE_NAME
,'&&5' comp_inv_id
,t.TEST_VALUE
,t.TEST_RESULT
,t.TEST_STATUS
from
(select nvl(SUBSTR(GLOBAL_NAME,1,instr(GLOBAL_NAME,'.') - 1 ),GLOBAL_NAME) DATABASE_NAME from GLOBAL_NAME G) G
--,(select hostname from hostname_view) H
,(select upper('&&4') hostname from dual) H
,(select upper('&&3') database_name from dual) D
,(select
t.TEST_VALUE
,t.TEST_RESULT
,t.TEST_STATUS
from (select 'GRANTS' TEST_VALUE, 'GRANT EXECUTE ON DEFAULT_USER TO '||GRANTEE||' GRANTABLE '||GRANTABLE TEST_RESULT, 'PASSED' TEST_STATUS  from dba_tab_privs where table_name = 'DEFAULT_USER') t
) t
/
commit;
