--rem caller should spool pset.sql;
connect dba_ora/&&1&&2@&&3
alter user sys identified by &&1;
commit;
--rem caller should spool pset.sql;

PL/SQL procedure successfully completed.

