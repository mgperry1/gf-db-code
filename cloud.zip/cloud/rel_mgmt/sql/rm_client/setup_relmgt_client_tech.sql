-- 
-- Step 1 is to create the viewlet table:
--
--
connect sys/&&1&&2@&&3 as sysdba
@/oracle/nfs/share/Oracle_software/rel_mgmt/payload/grant_sys_sql.sql
/
GRANT SELECT_CATALOG_ROLE TO DBA_ORA WITH ADMIN OPTION
/
GRANT select on dba_users TO DBA_ORA 
/
GRANT select on dba_profiles TO DBA_ORA 
/
GRANT select on v_$instance TO DBA_ORA 
/
GRANT select on v_$session TO DBA_ORA 
/
GRANT select on sys.user$ TO DBA_ORA 
/
GRANT select on sys.aud$ TO DBA_ORA 
/
GRANT create database link TO DBA_ORA 
/
alter user dba_ora identified by &&1&&2 account unlock
/
@/oracle/nfs/share/Oracle_software/rel_mgmt/sql/rm_client/rel_mgmt_sys_grants
connect dba_ora/&&1&&2@&&3
@/oracle/nfs/share/Oracle_software/rel_mgmt/sql/rm_client/java_run_cmd
create directory portal_tmp as '/oracle/nfs/backup/portal/tmp'
/
create directory portal_sql as '/oracle/nfs/share/Oracle_software/portal/sql'
/
create directory portal_bin as '/oracle/nfs/share/Oracle_software/portal/bin'
/
create directory portal_data as '/oracle/nfs/backup/portal/data'
/
create directory portal_log as '/oracle/nfs/backup/portal/log'
/
create directory portal_root as '/oracle/nfs/backup/portal'
/
set serveroutput on size 1000000
set pages 3000
drop TABLE  VIEWLET 
/
CREATE TABLE  VIEWLET 
   (	VIEWLET_ID NUMBER, 
	VIEWLET_NAME VARCHAR2(30), 
	VIEWLET_SQL VARCHAR2(4000), 
	CREATED_BY VARCHAR2(255), 
	CREATED_ON DATE, 
	MODIFIED_BY VARCHAR2(255), 
	MODIFIED_ON DATE, 
	VIEWLET_STMT_TYPE VARCHAR2(30), 
	VERSION VARCHAR2(30), 
	DB_VERSION VARCHAR2(30), 
	CODE_PACKAGE VARCHAR2(30), 
	STATEMENT_SEQUENCE NUMBER,
	RESULT_COLUMNS NUMBER,
	RESULT_SET NUMBER,
PARM1 varchar2(4000),
PARM2 varchar2(4000),
PARM3 varchar2(4000),
PARM4 varchar2(4000),
PARM5 varchar2(4000)
) tablespace tools
/
CREATE TABLE  VIEWLET 
   (	VIEWLET_ID NUMBER, 
	VIEWLET_NAME VARCHAR2(30), 
	VIEWLET_SQL VARCHAR2(4000), 
	CREATED_BY VARCHAR2(255), 
	CREATED_ON DATE, 
	MODIFIED_BY VARCHAR2(255), 
	MODIFIED_ON DATE, 
	VIEWLET_STMT_TYPE VARCHAR2(30), 
	VERSION VARCHAR2(30), 
	DB_VERSION VARCHAR2(30), 
	CODE_PACKAGE VARCHAR2(30), 
	STATEMENT_SEQUENCE NUMBER,
	RESULT_COLUMNS NUMBER,
	RESULT_SET NUMBER,
PARM1 varchar2(4000),
PARM2 varchar2(4000),
PARM3 varchar2(4000),
PARM4 varchar2(4000),
PARM5 varchar2(4000)
) tablespace users
/
CREATE TABLE  VIEWLET 
   (	VIEWLET_ID NUMBER, 
	VIEWLET_NAME VARCHAR2(30), 
	VIEWLET_SQL VARCHAR2(4000), 
	CREATED_BY VARCHAR2(255), 
	CREATED_ON DATE, 
	MODIFIED_BY VARCHAR2(255), 
	MODIFIED_ON DATE, 
	VIEWLET_STMT_TYPE VARCHAR2(30), 
	VERSION VARCHAR2(30), 
	DB_VERSION VARCHAR2(30), 
	CODE_PACKAGE VARCHAR2(30), 
	STATEMENT_SEQUENCE NUMBER,
	RESULT_COLUMNS NUMBER,
	RESULT_SET NUMBER,
PARM1 varchar2(4000),
PARM2 varchar2(4000),
PARM3 varchar2(4000),
PARM4 varchar2(4000),
PARM5 varchar2(4000)
) 
/
--  Step 2 is to create the relmgt_client Package
@/oracle/nfs/share/Oracle_software/rel_mgmt/sql/rm_client/relmgt_client
--  Step   Create Initial report_upload.world link
alter session set global_names=false;

drop database link report_upload.world ;
Create database link report_upload.world connect to ahs_sdba_user identified by fri3ndly using '(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=10.140.100.72)(PORT=1521))(ADDRESS=(PROTOCOL=TCP)(HOST=10.140.100.60)(PORT=1521)))(CONNECT_DATA=(SERVICE_NAME=USPRD700.WORLD)))';
--  Step   Create Initial record load into viewlet table
truncate TABLE VIEWLET 
/
--  Step   Alter viewlet AND Load the table
@/oracle/nfs/share/Oracle_software/rel_mgmt/sql/rm_client/alt_viewlet
@/oracle/nfs/share/Oracle_software/rel_mgmt/sql/rm_client/relmgt_client
--  Step   Create hostname_view used by REPORT_HUB
declare
 qt varchar2(30) := '''';
 l_sql varchar2(4000);
 hostname varchar2(255);
begin
  for c1 in (
          select
           upper(machine) hostname
          from v$session
          where sid = 1
         )
   loop
      hostname := c1.hostname;
      if hostname like '%RAC%' then
        hostname := substr(hostname,1,instr(hostname,'RAC') + 2)||'001';
      end if;
      l_sql := 'create or replace view hostname_view as select '||qt||hostname||qt||' hostname from dual ';
      execute immediate l_sql;
   end loop;
  commit;
end;
/
--  Step   Fix hostname if a RAC system
@/oracle/nfs/share/Oracle_software/rel_mgmt/sql/rm_client/fix_host_view
set serveroutput on size 1000000
