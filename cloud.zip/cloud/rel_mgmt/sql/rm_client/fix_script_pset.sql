set pages 3000 heading off  serveroutput on size 1000000
set lines 700 trimspool on 
@c700
spool pset.sql
exec control_process_mgr.fix_script('PSET','WORKER');
spool off
spool pset_driver.sql
exec control_process_mgr.fix_script('PSET','DRIVER');
spool off
@pset_driver.sql

