set feedback on
connect ahs_audit_upload/security_ahs@usprd900A
CREATE SYNONYM &&1  FOR AHS_SDBA.&&1@AUDIT_UPLOAD.WORLD ;
connect ahs_sdba/reporting@usprd316
create public synonym &&1 for ahs_sdba.&&1;
grant insert, update,delete,select on &&1 to ahs_audit_upload;
