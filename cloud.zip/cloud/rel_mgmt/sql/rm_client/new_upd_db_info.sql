connect dba_ora/&&1&&2@&&3
select 'Sid:&&2 TNS:&&3' Connect_to from dual;
merge into database_information di using
(
select
'&&5' COMP_INV_ID
,'&&2' DATABASE_NAME
,'&&4' SERVER
from dual
) s
on (di.COMP_INV_ID = s.COMP_INV_ID)
when matched then update
set di.database_name = s.DATABASE_NAME
,di.global_name =  s.DATABASE_NAME
,di.CHAMELEON_SID =  s.DATABASE_NAME
,di.related_server =  s.SERVER
,di.INSTANCE_HOST_NAME =  s.SERVER
when not matched then insert (
di.comp_inv_id 
,di.database_name 
,di.global_name
,di.CHAMELEON_SID
,di.related_server
,di.INSTANCE_HOST_NAME
) values (
s.comp_inv_id 
,s.database_name 
,s.database_name 
,s.database_name 
,s.server
,s.server
)
;
commit;
exec relmgmt_client.EXEC_PROGRAM('LOAD_DB_INFO');
exec relmgmt_client.EXEC_PROGRAM('TBLESPACE_STATS');
exec relmgmt_client.EXEC_PROGRAM('FILE_STAT');
exec relmgmt_client.EXEC_PROGRAM('USER_STG_UPLOAD_NEW');
commit;
