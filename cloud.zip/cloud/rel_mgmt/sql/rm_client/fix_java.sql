-- 
-- Step 1 is to create the viewlet table:
--
--
connect dba_ora/&&1&&2@&&3
@/oracle/nfs/share/Oracle_software/rel_mgmt/sql/rm_client/java_run_cmd
@/oracle/nfs/share/Oracle_software/rel_mgmt/sql/rm_client/run_java_test
