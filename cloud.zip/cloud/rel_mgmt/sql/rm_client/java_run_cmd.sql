grant javauserpriv to dba_ora;
grant javasyspriv to dba_ora;
begin
 dbms_java.grant_permission
      ('DBA_ORA',
       'java.io.FilePermission',
       '/usr/bin/*',
         'execute');
    
 dbms_java.grant_permission
        ('DBA_ORA',
        'java.lang.RuntimePermission',
        '*',
        'writeFileDescriptor' );

 dbms_java.grant_permission
      ('DBA_ORA',
       'java.io.FilePermission',
       '/bin/*',
         'execute');
    
 dbms_java.grant_permission
      ('DBA_ORA',
       'java.io.FilePermission',
       '/usr/central/bin/*',
         'execute');
    
 dbms_java.grant_permission
      ('DBA_ORA',
       'java.io.FilePermission',
       '/usr/local/bin/*',
         'execute');

 dbms_java.grant_permission
      ('DBA_ORA',
       'java.io.FilePermission',
       '/oracle/nfs/share/Oracle_software/portal/bin/*',
         'execute');
    
 dbms_java.grant_permission
        ('DBA_ORA',
        'java.lang.RuntimePermission',
        '*',
        '/oracle/nfs/backup' );
 dbms_java.grant_permission
        ('DBA_ORA',
        'java.lang.RuntimePermission',
        '*',
        'writeFileDescriptor' );
end;
/
create or replace and compile
 java source named "Util"
  as
  import java.io.*;
  import java.lang.*;
  
  public class Util extends Object
  {
  
    public static int RunThis(String args,
                              String[] CmdOutput)
     {
    Runtime rt = Runtime.getRuntime();
     int        rc = -1;
     String  coutput = " ";
     String  ot = " " ;

     try
     {
        Process p = rt.exec(args);
        CmdOutput[0] = " ";
   
        int bufSize = 4096;
        BufferedInputStream bis =
         new BufferedInputStream(p.getInputStream(), bufSize);
        int len;
        byte buffer[] = new byte[bufSize];
        coutput = " ";
   
        // Echo back what the program spit out
        while ((len = bis.read(buffer, 0, bufSize)) != -1)
           System.out.write(buffer, 0, len);
             ot = new String(buffer) ;
             coutput = coutput + ot.trim() ;

           rc = p.waitFor();
     }
     catch (Exception e)
     {
        e.printStackTrace();
        rc = -1;
     }
     finally
     {
        //System.out.println("Before Assignment ");
        //System.out.println(coutput);
        CmdOutput[0] = coutput;
        return rc;
     }
     }
   }
/
show errors
create or replace
  function RUN_CMD( p_cmd  in varchar2,
                    p_output out varchar2 ) return number
  as
  language java
  name 'Util.RunThis(java.lang.String,
                     java.lang.String[]) return integer';
/
show errors
create or replace procedure RC(p_cmd in varchar2,
                               p_output out varchar2)
  as
    x number;
begin
    x := run_cmd(p_cmd,p_output);
end;
/
