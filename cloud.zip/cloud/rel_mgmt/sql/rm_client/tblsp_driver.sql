--rem caller should spool tblsp_driver.sql;
@setup_remote_relmgt_client.sql kic38box UKPRD425 UKPRD425
@rminv.sql kic38box UKPRD425 UKPRD425
@setup_remote_relmgt_client.sql kic38box USPRD48 USPRD48
@rminv.sql kic38box USPRD48 USPRD48
@setup_remote_relmgt_client.sql kic38box USPRD483 USPRD483
@rminv.sql kic38box USPRD483 USPRD483
@setup_remote_relmgt_client.sql kic38box USDEV679 USDEV679
@rminv.sql kic38box USDEV679 USDEV679
@setup_remote_relmgt_client.sql kic38box UKTST750 UKTST750
@rminv.sql kic38box UKTST750 UKTST750
@setup_remote_relmgt_client.sql kic38box USDEV676 USDEV676
@rminv.sql kic38box USDEV676 USDEV676
@setup_remote_relmgt_client.sql kic38box USTST679 USTST679
@rminv.sql kic38box USTST679 USTST679
@setup_remote_relmgt_client.sql kic38box USPRD316 USPRD316
@rminv.sql kic38box USPRD316 USPRD316
@setup_remote_relmgt_client.sql kic38box UKTRN222 UKTRN222
@rminv.sql kic38box UKTRN222 UKTRN222
@setup_remote_relmgt_client.sql kic38box USDEV213 USDEV213
@rminv.sql kic38box USDEV213 USDEV213
@setup_remote_relmgt_client.sql kic38box USTST678 USTST678
@rminv.sql kic38box USTST678 USTST678
@setup_remote_relmgt_client.sql kic38box USTST676 USTST676
@rminv.sql kic38box USTST676 USTST676
@setup_remote_relmgt_client.sql kic38box USDEV678 USDEV678
@rminv.sql kic38box USDEV678 USDEV678
@setup_remote_relmgt_client.sql kic38box UKTST489 UKTST489
@rminv.sql kic38box UKTST489 UKTST489
@setup_remote_relmgt_client.sql kic38box UKHTF425 UKHTF425
@rminv.sql kic38box UKHTF425 UKHTF425
--rem caller should spool tblsp_driver.sql;

PL/SQL procedure successfully completed.

