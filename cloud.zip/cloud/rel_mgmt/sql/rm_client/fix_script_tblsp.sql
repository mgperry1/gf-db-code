set pages 3000 heading off  serveroutput on size 1000000
set lines 700 trimspool on 
@c700
spool rminv.sql
exec control_process_mgr.fix_script('FIXTBLSP','WORKER');
spool off
spool tblsp_driver.sql
exec control_process_mgr.fix_script('FIXTBLSP','DRIVER');
spool off
--rem @tblsp_driver.sql
