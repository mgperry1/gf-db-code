-- Step 1 is to create the viewlet table:
--
--
connect sys/&&1&&2@&&3 as sysdba
select 'Sid:&&2 TNS:&&3' Connect_to from dual;
--Create dbh_read
@/oracle/nfs/share/Oracle_software/rel_mgmt/sql/rm_client/cr_dbh_read.sql
--Do sys grants for dbh_read
@/oracle/nfs/share/Oracle_software/rel_mgmt/sql/rm_client/cr_dbh_read_sysgrts.sql
connect dbh_read/&&1@&&3
--Create viewlet table
@/oracle/nfs/share/Oracle_software/rel_mgmt/sql/rm_client/cr_dbh_read_viewlet.sql
--Create database_information_table
@/oracle/nfs/share/Oracle_software/rel_mgmt/sql/rm_client/cr_dbh_read_dbinfo.sql
--Create relmgt_client
@/oracle/nfs/share/Oracle_software/rel_mgmt/sql/rm_client/relmgt_client.sql
