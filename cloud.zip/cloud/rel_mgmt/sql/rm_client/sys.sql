connect sys/bon45dea&&2@&&1 as sysdba
set pages 3000
commit;
select * from dba_ora.database_information;
select * from v$version;
alter session set global_names=FALSE;
