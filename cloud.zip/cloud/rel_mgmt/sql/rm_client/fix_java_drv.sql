@/oracle/nfs/share/Oracle_software/rel_mgmt/sql/rm_client/fix_java eri34z00 USTST730 USTST730
@/oracle/nfs/share/Oracle_software/rel_mgmt/sql/rm_client/fix_java eri34z00 USTST732 USTST732
@/oracle/nfs/share/Oracle_software/rel_mgmt/sql/rm_client/fix_java eri34z00 USDEV731 USDEV731
@/oracle/nfs/share/Oracle_software/rel_mgmt/sql/rm_client/fix_java eri34z00 USDEV733 USDEV733
@/oracle/nfs/share/Oracle_software/rel_mgmt/sql/rm_client/fix_java eri34z00 USTST731 USTST731
@/oracle/nfs/share/Oracle_software/rel_mgmt/sql/rm_client/fix_java eri34z00 USDEV734 USDEV734
@/oracle/nfs/share/Oracle_software/rel_mgmt/sql/rm_client/fix_java eri34z00 USDEV732 USDEV732
