--  For RAC datbases need to get the HOSTNAME from Chameleon becuase its just
-- too complicated to come up with an algoryth to figure out what the hostname
-- should report .. see RTP...RAC5 etc
declare
 qt varchar2(30) := '''';
 l_sql varchar2(4000);
 hostname varchar2(255);
 g_name varchar2(255);
begin
  for c1 in (
          select
           min(upper(related_server)) hostname
          from ahs_sdba.ahs_database@report_upload.world 
          where
          DATABASE_NAME = (select upper(nvl(SUBSTR(GLOBAL_NAME,1,instr(GLOBAL_NAME,'.') - 1 ),GLOBAL_NAME))  DATABASE_NAME from GLOBAL_NAME G)
          and DATABASE_CLASS in ('Primary','RAC Database','Failover Cluster')
         )
   loop
      hostname := c1.hostname;
      l_sql := 'create or replace view hostname_view as select '||qt||hostname||qt||' hostname from dual ';
      execute immediate l_sql;
   end loop;
  commit;
end;
/
