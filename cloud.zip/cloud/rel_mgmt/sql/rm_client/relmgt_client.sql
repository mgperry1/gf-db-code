set define ~
--create or replace package RELMGMT_CLIENT AUTHID CURRENT_USER  is
create or replace package RELMGMT_CLIENT is
--------------------------------------------------------------
 -- GLobal Package Vars used in PL-SQL scripts to pass-info
 -- between PL-SQL blocks in viewlet scripts
 --------------------------------------------------------------
 g_c_d1 varchar2(4000);
 g_c_d2 varchar2(4000);
 g_c_d3 varchar2(4000);
 g_d_d1 date;
 g_d_d2 date;
 g_d_d3 date;
 --------------------------------------------------------------
 -- EXEC_STMT procedure 
    procedure EXEC_STMT (
       P_SQL in varchar2 ,
       DEBUG in varchar2 default 'Y'
     );

 -- EXEC_HOST procedure 
    procedure EXEC_HOST (
       P_SQL in varchar2 ,
       P_EXEC_OUT in varchar2 default 'N',
       DEBUG in varchar2 default 'Y'
     );

 -- EXEC_FILE procedure 
    procedure EXEC_FILE (
       P_SQL in varchar2 ,
       P_EXEC_OUT in varchar2 default 'N',
       DEBUG in varchar2 default 'Y'
     );

 -- EXEC_PROGRAM procedure 
    procedure EXEC_PROGRAM (
       P_CODE_PACKAGE in varchar2  ,
       P_CODE_PACKAGE_VER in varchar2 default 'MAX'  ,
       DEBUG in varchar2 default 'Y'
     );

    procedure print (
       P_OUT_STR in varchar2 default 'TEST',
       P_HTML_OUT in varchar2 default 'N',
       DEBUG in varchar2 default 'Y'
     ) ;

    procedure sync_viewlet ;

function parse_cols ( P_SQL in VARCHAR2,
                      COL1 in  VARCHAR2,
                      COL2 in  VARCHAR2,
                      COL3 in  VARCHAR2,
                      COL4 in  VARCHAR2,
                      COL5 in  VARCHAR2
   ) return varchar2;

end RELMGMT_CLIENT;
/
show errors;
create or replace package body RELMGMT_CLIENT  is
  qt varchar2(30) := '''';
  sarbox_link_acct varchar2(30) := 'dba_ora';
  crlf VARCHAR2( 2 ):= CHR( 13 ) || CHR( 10 );
  master_count number;
  client_count number;
 --------------------------------------------------------------
 -- EXEC_PROGRAM procedure 
 --------------------------------------------------------------
    procedure EXEC_PROGRAM (
       P_CODE_PACKAGE in varchar2  ,
       P_CODE_PACKAGE_VER in varchar2 default 'MAX'  ,
       DEBUG in varchar2 default 'Y'
     ) is
       L_SQL VARCHAR2(32000);
       I_SQL VARCHAR2(32000);
       L_DB_NAME VARCHAR2(255);
       L_COMP_INV_ID VARCHAR2(255);
       L_VIEWLET_SQL VARCHAR2(32000);
       L_CODE_PACKAGE_VER  VARCHAR2(30);
     begin
      -- Make sure global_names is disabled
      exec_stmt('alter session set global_names=false ' );
      if P_CODE_PACKAGE_VER = 'MAX' then
        select max(VERSION) into L_CODE_PACKAGE_VER from viewlet
          where CODE_PACKAGE = P_CODE_PACKAGE;
      Else
       L_CODE_PACKAGE_VER := P_CODE_PACKAGE_VER;
      End if; 

   If debug = 'Y' then
    select database_name,comp_inv_id into l_db_name, l_comp_inv_id
    from database_information;
     print('----------------------');
     print('- DB Info:'||l_db_name||'-'||l_comp_inv_id);
     print('----------------------');

   end if;
    if master_count is null or master_count != client_count then
     print('Checking viewlet sync');
     sync_viewlet;
    End if;

   If debug = 'Y' then
     print('--- PARMS -------');
     print(' CODE PACKAGE : '||P_CODE_PACKAGE);
     print(' CODE Ver : '||L_CODE_PACKAGE_VER);
     print('----------------');
  End if;

         for c1 in (
          Select
           VIEWLET_NAME,
           VIEWLET_SQL,
           PARM1,
           PARM2,
           PARM3,
           PARM4,
           PARM5,
           STATEMENT_SEQUENCE,
           VIEWLET_STMT_TYPE,
           CODE_PACKAGE
          From VIEWLET
          Where
           CODE_PACKAGE = P_CODE_PACKAGE
           and VERSION = L_CODE_PACKAGE_VER
           order by STATEMENT_SEQUENCE
 )
 loop
   null;
   If debug = 'Y' then
     print('----------------');
     print(c1.CODE_PACKAGE||' - '||c1.VIEWLET_NAME||' - '||c1.STATEMENT_SEQUENCE);
     print('----------------');
   End if;
   --
   -- Get ready TO Execute the Code
   --
   --l_sql := c1.VIEWLET_SQL;
   l_sql := parse_cols(c1.VIEWLET_SQL,c1.PARM1,c1.PARM2,c1.PARM3,c1.PARM4,c1.PARM5);
   l_sql := replace(l_sql,chr(13),' ');
   --If debug = 'Y' then
   --  print(l_sql);
   --end if;
   if c1.VIEWLET_STMT_TYPE = 'EXEC_PROGRAM' then
    exec_program(l_sql);
   elsif c1.VIEWLET_STMT_TYPE = 'EXEC_HOST' then
    exec_host(l_sql);
   elsif c1.VIEWLET_STMT_TYPE = 'EXEC_HOST_OUTPUT' then
    exec_host(l_sql,'Y');
   elsif c1.VIEWLET_STMT_TYPE = 'EXEC_FILE' then
    exec_file(l_sql);
   elsif c1.VIEWLET_STMT_TYPE = 'EXEC_ALERT' then
    i_sql := 'begin sarbox_utility.EXEC_ALERT(:p1) end;';
    execute immediate i_sql using in c1.viewlet_sql;
   else
     exec_stmt(l_sql);
   END if;
   commit;
  end loop;
end;

 --------------------------------------------------------------
 -- EXEC_STMT procedure 
 --------------------------------------------------------------
    procedure EXEC_STMT (
       P_SQL in varchar2 ,
       DEBUG in varchar2 default 'Y'
     ) is
     L_SQL VARCHAR2(32000);
    begin
       -- 
       -- Run the script Lines SQL
       -- 
       execute immediate P_SQL;

       EXCEPTION
        WHEN OTHERS THEN
              print('-----Begin Error Report ------------------ ');
           print('Sqlcode: '||sqlcode);
           print('SqlErrm: '||sqlerrm);
           If debug = 'Y' then
              print('P_SQL : '||P_SQL);
           end if;
              print('-----End Error Report ------------------ ');
     end;


 --------------------------------------------------------------
 -- EXEC_HOST procedure 
 --------------------------------------------------------------
    procedure EXEC_HOST (
       P_SQL in varchar2 ,
       P_EXEC_OUT in varchar2 default 'N',
       DEBUG in varchar2 default 'Y'
     ) is
     L_SQL VARCHAR2(32000);
     L_CMD VARCHAR2(4000);
     L_OUTPUT VARCHAR2(32000);
     qt varchar2(30) := '''';
    begin
       L_SQL := 'begin rc(:P_CMD, :P_OUTPUT); end;';
       -- 
       -- 
       execute immediate L_SQL using in P_SQL, out L_OUTPUT;
       if P_EXEC_OUT = 'Y' then

         EXEC_STMT(L_OUTPUT);

       End if;

       EXCEPTION
        WHEN OTHERS THEN
              print('-----Begin Error Report ------------------ ');
           print('Sqlcode: '||sqlcode);
           print('SqlErrm: '||sqlerrm);
           If debug = 'Y' then
              print('L_SQL : '||L_SQL);
           end if;
              print('-----End Error Report ------------------ ');
     end;

 --------------------------------------------------------------
 -- EXEC_FILE procedure 
 --------------------------------------------------------------
    procedure EXEC_FILE (
       P_SQL in varchar2 ,
       P_EXEC_OUT in varchar2 default 'N',
       DEBUG in varchar2 default 'Y'
     ) is
     L_SQL VARCHAR2(32000);
     qt varchar2(30) := '''';
     line_in  varchar2(4000) ;
     dir_in   varchar2(4000) ;
     file_in   varchar2(4000) ;
     --l_file    UTL_FILE.file_type;
 BEGIN
       --
       -- Parse the direcory and file name assuming seperated by Comma
       --
       dir_in := substr(P_SQL,1,instr(P_SQL,',') - 1);
       file_in := substr(P_SQL,instr(P_SQL,',') + 1);


       L_SQL := ' ';

  BEGIN

   --l_file := UTL_FILE.fopen (dir_in, file_in, 'R');

   --IF UTL_FILE.IS_OPEN(l_file) THEN 
   --   LOOP
   --    begin
   --      UTL_FILE.get_line (l_file, line_in);
   --      L_SQL := L_SQL || line_in;
   --    exception
   --    when no_data_found then exit;
   --    end;
   --   END LOOP;
   --Else
   -- RAISE_APPLICATION_ERROR(-20198,'Unable to Open file in:'||dir_in||' file:'||file_in); 
 --  End if;

  -- EXEC_STMT(L_SQL);

   --IF UTL_FILE.IS_OPEN(l_file) THEN 
   --  UTL_FILE.fclose (l_file);
   --END if;
   null;

EXCEPTION
--WHEN UTL_FILE.INVALID_PATH THEN 
--RAISE_APPLICATION_ERROR(-20100,'Invalid Path'); 

--WHEN UTL_FILE.INVALID_MODE THEN 
--RAISE_APPLICATION_ERROR(-20101,'Invalid Mode'); 

--WHEN UTL_FILE.INVALID_FILEHANDLE THEN 
--RAISE_APPLICATION_ERROR(-20102,'Invalid Filehandle'); 

--WHEN UTL_FILE.INVALID_OPERATION THEN 
--RAISE_APPLICATION_ERROR(-20103,'Invalid Operation -- May signal a file locked by the OS'); 

--WHEN UTL_FILE.READ_ERROR THEN 
--RAISE_APPLICATION_ERROR(-20104,'Read Error'); 

--WHEN UTL_FILE.WRITE_ERROR THEN 
--RAISE_APPLICATION_ERROR(-20105,'Write Error'); 

--WHEN UTL_FILE.INTERNAL_ERROR THEN 
--RAISE_APPLICATION_ERROR(-20106,'Internal Error'); 

--WHEN NO_DATA_FOUND THEN 
--R--AISE_APPLICATION_ERROR(-20107,'No Data Found'); 

WHEN VALUE_ERROR THEN 
RAISE_APPLICATION_ERROR(-20108,'Value Error'); 
end;

EXCEPTION
WHEN OTHERS THEN 
--   IF UTL_FILE.IS_OPEN(l_file) THEN 
--      UTL_FILE.fclose (l_file);
 --  End if;
      print('-----Begin Error Report ------------------ ');
      print('Sqlcode: '||sqlcode);
      print('SqlErrm: '||sqlerrm);
      If debug = 'Y' then
         print('L_SQL : '||L_SQL);
      end if;
      print('-----End Error Report ------------------ ');
 end;

 --------------------------------------------------------------
 -- print procedure 
 --------------------------------------------------------------
    procedure PRINT (
       P_OUT_STR in varchar2 default 'TEST',
       P_HTML_OUT in varchar2 default 'N',
       DEBUG in varchar2 default 'Y'
     ) is
     L_STR_LEN NUMBER ;
     L_COUNT NUMBER ;
     L_OUT_STR VARCHAR2(32000);
  BEGIN
       L_STR_LEN := LENGTH(P_OUT_STR);
       L_OUT_STR := P_OUT_STR;
       WHILE L_STR_LEN > 0 LOOP
         dbms_output.put_line(substr(L_OUT_STR,1,254));
         L_OUT_STR := substr(L_OUT_STR,255,L_STR_LEN);
         L_STR_LEN := L_STR_LEN - 254;
       END LOOP;
       --if P_HTML_OUT = 'Y' then
       --  htp.p(L_OUT_STR);
       --End if;
       EXCEPTION
       WHEN OTHERS THEN
         dbms_output.put_line('In Print Procedure: '||substr(sqlerrm,1,200));

     end;

  procedure sync_viewlet 
  as
   l_sql varchar2(4000);
  Begin
   null;
       Begin

   l_sql := 'alter table VIEWLET add (PARM1 varchar2(4000), PARM2 varchar2(4000), PARM3 varchar2(4000), PARM4 varchar2(4000), PARM5 varchar2(4000))';

       -- execute immediate L_SQL;

       EXCEPTION
        WHEN OTHERS THEN
              print('-----Begin Error Report ------------------ ');
           print('Sqlcode: '||sqlcode);
           print('SqlErrm: '||sqlerrm);
              print('L_SQL : '||L_SQL);
              print('-----End Error Report ------------------ ');
       End;
  
     l_sql := 'select count(*) from  VIEWLET';
     execute immediate L_SQL into client_count ;
     if client_count is null then
        client_count := 0;
     end if;
     print('Client Viewlet Recs : '||client_count);

     l_sql := 'select count(*) from  VIEWLET@REPORT_UPLOAD.WORLD';
     execute immediate L_SQL into master_count ;
     if master_count is null then
        master_count := 0;
     end if;

     print('Master Viewlet Recs : '||master_count);

 if master_count != client_count and user != 'AHS_SDBA' then


   l_sql := 'delete from  VIEWLET';

  execute immediate L_SQL;

   l_sql := 'insert into VIEWLET(
VIEWLET_ID ,
VIEWLET_NAME ,
VIEWLET_SQL ,
VIEWLET_STMT_TYPE ,
VERSION ,
DB_VERSION ,
CODE_PACKAGE ,
STATEMENT_SEQUENCE,
RESULT_COLUMNS ,
RESULT_SET,
PARM1,
PARM2,
PARM3,
PARM4,
PARM5
)
select
VIEWLET_ID ,
VIEWLET_NAME ,
VIEWLET_SQL ,
VIEWLET_STMT_TYPE ,
VERSION ,
DB_VERSION ,
CODE_PACKAGE ,
STATEMENT_SEQUENCE,
RESULT_COLUMNS ,
RESULT_SET,
PARM1,
PARM2,
PARM3,
PARM4,
PARM5
from VIEWLET@REPORT_UPLOAD.WORLD ';

 execute immediate L_SQL;
 commit;

End if;

       EXCEPTION
        WHEN OTHERS THEN
              print('-----Begin Error Report ------------------ ');
           print('Sqlcode: '||sqlcode);
           print('SqlErrm: '||sqlerrm);
              print('L_SQL : '||L_SQL);
              print('-----End Error Report ------------------ ');

  End ;

function parse_cols ( P_SQL  VARCHAR2,
                      COL1  VARCHAR2,
                      COL2  VARCHAR2,
                      COL3  VARCHAR2,
                      COL4  VARCHAR2,
                      COL5  VARCHAR2
) return varchar2
as
L_MESSAGE varchar2(32000);
BEGIN
   L_MESSAGE := P_SQL;
 if col1 is not null then
   L_MESSAGE := replace(L_MESSAGE,'&1',COL1);
 end if;
 if col2 is not null then
   L_MESSAGE := replace(L_MESSAGE,'&2',COL2);
 end if;
 if col3 is not null then
   L_MESSAGE := replace(L_MESSAGE,'&3',COL3);
 end if;
 if col4 is not null then
   L_MESSAGE := replace(L_MESSAGE,'&4',COL4);
 end if;
 if col5 is not null then
   L_MESSAGE := replace(L_MESSAGE,'&5',COL5);
 end if;
 return  L_MESSAGE;

END;

end RELMGMT_CLIENT;
/
show errors;
set define &
