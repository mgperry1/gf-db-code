set feedback off heading off pages 400 lines 100 autotrim on
spool run_upd_db_info.sql
select
'@new_upd_db_info '||p.parm_value||' '||a.sid||' '||a.database_name||' '||a.related_server||' '||a.db_comp_inv_id
from
--(select comp_inv_id
--from
--scorecard_pop
--minus
--select COMP_INV_ID from database_check_in where process = 'RM_INVENTORY' and check_in >= sysdate - 1
--) mi
(
select comp_inv_id, database_name
from ahs_sdba.gw_database_catalogue
where comp_inv_id in
(select comp_inv_id from ahs_sdba.gw_database_catalogue d
where d.service_group_cost_center like 'EIS CIAS%' 
and d.database_vendor = 'ORACLE' 
and d.database_class not in ('RAC Instance','Standby') 
and d.database_version not like '7.%' and database_version not like '8.0%'
and d.life_cycle_status not in ('Decommissioned','Void','Out of Service')
minus
select  comp_inv_id from database_info_registry group by comp_inv_id 
)
) mi
,ahs_databases a
,ahs_parameter p
where
a.db_comp_inv_id = mi.comp_inv_id
and p.parm_name = 'SEED'
and a.db_ver not in ('OLD')
order by a.database_name
/
spool off
set feedback on heading on pages 300
