update database_information
set database_name = upper('&&1')
,global_name = upper('&&1')
,CHAMELEON_SID = upper('&&1')
;
