--rem caller should spool rminv.sql;
--connect dba_ora/&&1&&2@&&3
@dba &&1 &&2
set serveroutput on size 1000000
exec relmgmt_client.sync_viewlet;
commit;
exec relmgmt_client.EXEC_PROGRAM('RM_INVENTORY');
exec relmgmt_client.EXEC_PROGRAM('RM_WEEKLY');
--rem caller should spool rminv.sql;
