--  Connect to GSAP DB and create DBH_READ account
--  and supporting structures
-- parm1:password for SYS account
-- parm2:Connect string of the DB
-- parm3:password for DBH_READ
connect sys/&&1@&&2 as sysdba
select 'Sid:&&2 TNS:&&2' Connect_to from dual;
--Create dbh_read
@cr_dbh_read.sql &&3
--Do sys grants for dbh_read
@cr_dbh_read_sysgrts.sql
--Connect to the DB as the dbh_read account
connect dbh_read/&&3@&&2
--Create viewlet table - Stores the SQL we use to collect data
@cr_dbh_read_viewlet.sql
--Create database_information_table - Identifies the DB thats passing us data
@cr_dbh_read_dbinfo.sql
--Create relmgt_client -  Package thatExecs the SQL stmts in SQL Store table
@relmgt_client.sql
-- Run the first data pull
@dbh_read_inv.sql &&3 &2
