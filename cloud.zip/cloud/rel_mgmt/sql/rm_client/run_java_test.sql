alter session set  global_names=false;
set serveroutput on size 1000000
commit;
Declare
 l_out varchar2(4000);
Begin
 rc('ls',l_out);
  dbms_output.put_line(substr(l_out,1,254));
insert into discovery_test@report_upload.world
(
PROCESS
,TEST_NAME
,HOSTNAME
,GLOBAL_NAME
,DATABASE_NAME
,COMP_INV_ID
,TEST_VALUE
,TEST_RESULT
,TEST_STATUS
,RECORD_SOURCE
)
select
'DISCOVERY'
,'RUNCMDSTATUS'
,related_server
,D.GLOBAL_NAME
,D.DATABASE_NAME
,d.comp_inv_id
, 'RUN_CMD_STATUS'
, 'VALID'
, 'PASS'
,'PAYLOAD'
from
database_information d;
Exception 
When others then 
insert into discovery_test@report_upload.world
(
PROCESS
,TEST_NAME
,HOSTNAME
,GLOBAL_NAME
,DATABASE_NAME
,COMP_INV_ID
,TEST_VALUE
,TEST_RESULT
,TEST_STATUS
,RECORD_SOURCE
)
select
'DISCOVERY'
,'RUNCMDSTATUS'
,related_server
,D.GLOBAL_NAME
,D.DATABASE_NAME
,d.comp_inv_id
, 'RUN_CMD_STATUS'
, 'INVALID'
,'FAIL' 
,'PAYLOAD'
from
database_information d;
End;
/
commit;
