set serveroutput on size 1000000
connect DBH_READ/&&1@&&2
exec relmgmt_client.sync_viewlet;
commit;
exec relmgmt_client.EXEC_PROGRAM('DBH_READ_INV');
