-- 
--
connect dba_ora/&&1&&2
--connect dba_ora/${V_SEED}${v_sid_name}
alter database rename global_name to &&2..world;
select '&&2' new_global_name from dual;
--select '${v_sid_name}' new_global_name from dual;
@/oracle/nfs/share/Oracle_software/rel_mgmt/sql/fix_host_view
