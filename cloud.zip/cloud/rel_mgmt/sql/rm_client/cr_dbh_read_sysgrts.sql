rem DB_INFO
grant select on v_$instance to DBH_READ;
grant select on v_$database to DBH_READ;
grant select on NLS_DATABASE_PARAMETERS to DBH_READ;
grant select on dba_tablespaces to DBH_READ;
rem LIC USage
grant select on database_feature_usage to DBH_READ;
grant select on dba_feature_usage_statistics to DBH_READ;
grant select on v_$version to DBH_READ;
grant select on v_$license to DBH_READ;
grant select on v_$parameter to DBH_READ;

