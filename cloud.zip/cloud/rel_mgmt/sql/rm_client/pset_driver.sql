--rem caller should spool pset_driver.sql;
@pset kic38box UKPRD425 UKPRD425
@pset kic38box UKPRD682 UKPRD682
@pset kic38box UKDEV455 UKDEV455
@pset kic38box USPRD48 USPRD48
@pset kic38box USPRD483 USPRD483
@pset kic38box UKTST606 UKTST606
@pset kic38box UKTST750 UKTST750
@pset kic38box UKPRD663 UKPRD663
@pset kic38box USPRD316 USPRD316
@pset kic38box USDEV50 USDEV50
@pset kic38box UKTRN222 UKTRN222
@pset kic38box UKDEV606 UKDEV606
@pset kic38box USDEV213 USDEV213
@pset kic38box UKHTF420 UKHTF420
@pset kic38box USTST678 USTST678
@pset kic38box UKTST513 UKTST513
@pset kic38box USDEV678 USDEV678
@pset kic38box UKDEV630 UKDEV630
@pset kic38box USDEV679 USDEV679
@pset kic38box USVAL628 USVAL628
@pset kic38box UKUAT630 UKUAT630
@pset kic38box USDEV676 USDEV676
@pset kic38box USTST679 USTST679
@pset kic38box UKTST672 UKTST672
@pset kic38box UKDEV752 UKDEV752
@pset kic38box UKTST489 UKTST489
@pset kic38box UKHTF425 UKHTF425
@pset kic38box UKTST630 UKTST630
@pset kic38box USTST676 USTST676
--rem caller should spool pset_driver.sql;

PL/SQL procedure successfully completed.

