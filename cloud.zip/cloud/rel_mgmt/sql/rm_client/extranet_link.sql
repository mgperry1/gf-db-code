drop database link REPORT_UPLOAD.WORLD;
create database link REPORT_UPLOAD.WORLD connect to AHS_AUDIT_UPLOAD  identified by lock_1t_d0wn using '(description=(address=(protocol=tcp)(host=166.71.124.50)(Port=1521))(connect_data=(sid=USPRD900A)))';
