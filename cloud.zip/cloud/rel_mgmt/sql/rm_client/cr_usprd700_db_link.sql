drop database link report_upload.world ;
Create database link report_upload.world connect to ahs_sdba_user identified by fri3ndly using 'USPRD700.WORLD';
