-- 
-- Step 1 is to create the viewlet table:
--
--
--connect sys/&&1&&2@&&3
GRANT SELECT_CATALOG_ROLE TO DBA_ORA WITH ADMIN OPTION
/
GRANT select on dba_users TO DBA_ORA 
/
GRANT select on dba_profiles TO DBA_ORA 
/
GRANT select on v_$instance TO DBA_ORA 
/
GRANT select on v_$process TO DBA_ORA 
/
GRANT select on v_$session TO DBA_ORA 
/
GRANT select on v_$spparameter TO DBA_ORA 
/
GRANT select on v_$parameter TO DBA_ORA 
/
GRANT select on v_$datafile TO DBA_ORA 
/
GRANT select on v_$filestat TO DBA_ORA 
/
GRANT select on sys.user$ TO DBA_ORA 
/
GRANT select on sys.aud$ TO DBA_ORA 
/
GRANT create database link TO DBA_ORA 
/
GRANT create table TO DBA_ORA 
/
GRANT create any directory TO DBA_ORA 
/
GRANT select on DBA_ROLE_PRIVS TO DBA_ORA 
/
GRANT select on DBA_SYS_PRIVS TO DBA_ORA 
/
GRANT select on DBA_SEGMENTS TO DBA_ORA 
/
GRANT select on DBA_TAB_COLUMNS TO DBA_ORA 
/
GRANT select on DBA_TABLES TO DBA_ORA 
/
GRANT select on DBA_OBJECTS TO DBA_ORA 
/
GRANT select on dba_data_files TO DBA_ORA 
/
GRANT select on dba_jobs TO DBA_ORA 
/
GRANT select on dba_tab_privs TO DBA_ORA 
/
GRANT select on DBA_PART_TABLES TO DBA_ORA 
/
GRANT select on DBA_PART_INDEXES TO DBA_ORA 
/
GRANT select on DBA_TAB_PARTITIONS TO DBA_ORA 
/
GRANT select on DBA_IND_PARTITIONS TO DBA_ORA 
/
GRANT select on DBA_DEPENDENCIES TO DBA_ORA 
/
GRANT select on DBA_TABLES TO DBA_ORA 
/
GRANT select on DBA_TS_QUOTAS TO DBA_ORA 
/
GRANT select on dba_tablespaces TO DBA_ORA 
/
GRANT alter user TO DBA_ORA 
/
GRANT alter system TO DBA_ORA 
/
GRANT select on v_$archived_log TO DBA_ORA 
/
GRANT select on REGISTRY$HISTORY to DBA_ORA
/
GRANT select on v_$lock to DBA_ORA;
GRANT select on dba_jobs to DBA_ORA;
GRANT execute on sys.dbms_system to DBA_ORA;
grant select on NLS_DATABASE_PARAMETERS to dba_ora;
grant select on v_$segment_statistics  to dba_ora;
