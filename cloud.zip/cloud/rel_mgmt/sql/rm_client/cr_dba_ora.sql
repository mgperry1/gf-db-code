create user dba_ora identified by &&1&&2 default tablespace users
temporary tablespace temp;
grant dba to dba_ora;
grant create table to dba_ora;
grant create database link to dba_ora;
