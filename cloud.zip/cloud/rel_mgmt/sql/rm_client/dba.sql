connect ahs_sdba_user/fri3ndly@ahs_upload
set pages 3000 lines 300 trimspool on echo off heading off verify off
set serveroutput on size 1000000
spool /tmp/c_it.sql
select GET_CONN_STR('dba_ora','&&2','&&1') from dual;
spool off
@/tmp/c_it.sql
select COMP_INV_ID||' - '|| DATABASE_NAME DB_NAME  from database_information;
alter session set global_names=FALSE;
!rm /tmp/c_it.sql
