spool /oracle/dba/dba_ora/scripts/rel_mgmt/logs/run_approved_sql/host_shell.11348.224521.txt
connect dba_ora/pb16g0neUSTST783@USTST783
set serveroutput on size 1000000
alter session set  global_names=false;
declare
  x varchar2(4000);
  i number;
l_str_len NUMBER;
l_out_str VARCHAR2(32000);
begin
  i := run_cmd('/oracle/nfs/share/Oracle_software/portal/bin/zt_task/rm_stub_shell_cmd.ksh 50988 /oracle/nfs/share/Oracle_software/portal/bin/zt_task/zt_list_dump_files.ksh 50988 C421767 USTST783 USTST783',x);
end;
/
spool off
