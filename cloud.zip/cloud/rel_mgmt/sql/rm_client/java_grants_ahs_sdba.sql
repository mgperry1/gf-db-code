set serveroutput on size 1000000
grant javauserpriv to ahs_sdba;
grant javasyspriv to ahs_sdba;
begin
 dbms_java.grant_permission
      ('AHS_SDBA',
       'java.io.FilePermission',
       '/usr/bin/*',
         'execute');
    
 dbms_java.grant_permission
        ('AHS_SDBA',
        'java.lang.RuntimePermission',
        '*',
        'writeFileDescriptor' );

 dbms_java.grant_permission
      ('AHS_SDBA',
       'java.io.FilePermission',
       '/bin/*',
         'execute');
    
 dbms_java.grant_permission
      ('AHS_SDBA',
       'java.io.FilePermission',
       '/usr/central/bin/*',
         'execute');
    
 dbms_java.grant_permission
      ('AHS_SDBA',
       'java.io.FilePermission',
       '/usr/local/bin/*',
         'execute');

 dbms_java.grant_permission
      ('AHS_SDBA',
       'java.io.FilePermission',
       '/oracle/nfs/share/Oracle_software/portal/bin/*',
         'execute');

 dbms_java.grant_permission
      ('AHS_SDBA',
       'java.io.FilePermission',
       '/oracle/dba/dba_ora/scripts/portal/bin/*',
         'execute');
    
 dbms_java.grant_permission
      ('AHS_SDBA',
       'java.io.FilePermission',
       '/oracle/dba/dba_ora/scripts/portal/bin/*',
         'read , write');
    
    
 dbms_java.grant_permission
        ('AHS_SDBA',
        'java.lang.RuntimePermission',
        '*',
        '/oracle/nfs/backup' );

 dbms_java.grant_permission
        ('AHS_SDBA',
        'java.lang.RuntimePermission',
        '*',
        'writeFileDescriptor' );

 dbms_java.grant_permission
      ('AHS_SDBA',
       'java.io.FilePermission',
       '/oracle/nfs/share/Oracle_software/portal/bin/zt_task/*',
         'execute');

 dbms_java.grant_permission
        ('AHS_SDBA',
        'java.lang.RuntimePermission',
        '/oracle/dba/dba_ora/scripts/rel_mgmt/*',
        'writeFileDescriptor' );

 dbms_java.grant_permission
        ('AHS_SDBA',
        'java.lang.RuntimePermission',
        '/oracle/dba/dba_ora/scripts/portal/*',
        'writeFileDescriptor' );

 dbms_java.grant_permission
        ('AHS_SDBA',
        'java.lang.RuntimePermission',
        '/var/opt/oracle/*',
        'readFileDescriptor' );

end;
/
