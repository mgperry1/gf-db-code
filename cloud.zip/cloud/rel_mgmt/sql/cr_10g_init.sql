col parameter format a500
col parameter format a500
select sid || '.' || name || '=' || value
  from V$SPPARAMETER
 where ISSPECIFIED = 'TRUE'
   and sid <> '*'
union
select '*.sga_target=' || to_char(max(sga_value))
  from (select to_number(value) sga_value
          from V$PARAMETER
         where name = 'sga_max_size'
       UNION
        select to_number(use_larger_value) sga_value
          from dba_ora.SPFILE_PARAMETERS_10G@rm_temp.WORLD
         where name = 'sga_target'
       UNION
        select 314572800 + sum(to_number(
               (case when a.type = 2 then chr(39) end) ||
                case when rp.gsk_value is not null
                  then rp.gsk_value
                  else (case when rp.use_9i_value_flg is not null
                          then (case when a.type = 2
                                  then replace(a.value,', ',chr(39) || ',' || chr(39))
                                  else a.value
                                end)
                          else (case when to_number(a.value) >= to_number(rp.use_larger_value)
                                  then a.value
                                  else (case when to_number(rp.use_larger_value) > to_number(rp.default_value)
                                          then rp.use_larger_value
                                        end)
                                end)
                        end)
                end
               || (case when a.type = 2 then chr(39) end))) sga_value
           from v$parameter a,
                dba_ora.SPFILE_PARAMETERS_10G@rm_temp.WORLD rp
           where a.name (+) = rp.name
             and rp.name in ('java_pool_size','large_pool_size','shared_pool_size','streams_pool_size','db_16k_cache_size',
                             'db_2k_cache_size','db_32k_cache_size','db_4k_cache_size','db_8k_cache_size','db_cache_size')
             and rp.use_10g_value_flg is null
             and a.ISDEFAULT (+) = 'FALSE'
             and a.name not in (select sp.name from V$SPPARAMETER sp where sp.ISSPECIFIED = 'TRUE' and sp.sid <> '*')
             and (rp.gsk_value is not null
                  or (rp.use_9i_value_flg is not null and (a.name = 'os_authent_prefix' or a.value is not null))
                  or to_number(a.value) >= to_number(rp.use_larger_value)
                  or rp.use_larger_value > rp.default_value))
union
select '*.' || a.name || '=' ||
      (case when a.type = 2 then chr(39) end) ||
       case when rp.gsk_value is not null
         then rp.gsk_value
         else (case when rp.use_9i_value_flg is not null
                 then (case when a.type = 2
                         then replace(a.value,', ',chr(39) || ',' || chr(39))
                         else a.value
                       end)
                 else (case when a.type = 3 
                         then (case when to_number(a.value) >= to_number(rp.use_larger_value)
                                 then a.value
                                 else (case when to_number(rp.use_larger_value) > to_number(rp.default_value)
                                         then rp.use_larger_value
                                       end)
                               end)
                         else (case when a.value >= rp.use_larger_value
                                 then a.value
                                 else (case when rp.use_larger_value > rp.default_value
                                         then rp.use_larger_value
                                       end)
                               end)
                       end)
               end)
       end
      || (case when a.type = 2 then chr(39) end) parameter
  from v$parameter a,
       dba_ora.SPFILE_PARAMETERS_10G@rm_temp rp
  where a.name (+) = rp.name
    and rp.use_10g_value_flg is null
    and a.ISDEFAULT = 'FALSE'
    and a.name <> 'sga_max_size'
    and a.name not in (select sp.name from V$SPPARAMETER sp where sp.ISSPECIFIED = 'TRUE' and sp.sid <> '*')
    and (rp.gsk_value is not null
         or rp.use_9i_value_flg is not null
         or a.value >= rp.use_larger_value
         or rp.use_larger_value > rp.default_value)
;
