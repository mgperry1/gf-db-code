--* Name: rm_online_ts.sql
--*
--* Purpose: Call this SQL to ONLINE any Tablespaces that
--*           are currently OFFLINE.
--*
DECLARE
v_name dba_tablespaces.tablespace_name%TYPE;
TYPE TableSpaceCurTyp IS REF CURSOR;
c_cursor1 TableSpaceCurTyp;
sql_stmt VARCHAR2(300);
BEGIN
sql_stmt := 'SELECT tablespace_name '      ||
'FROM   dba_tablespaces '                  ||
'WHERE STATUS = ' || '''OFFLINE''';
OPEN c_cursor1 for sql_stmt;
LOOP
FETCH c_cursor1 into v_name;
EXIT WHEN c_cursor1%NOTFOUND;
EXECUTE IMMEDIATE 'ALTER TABLESPACE ' || v_name || ' ONLINE' ;
END LOOP;
END;
/
EXIT SQL.SQLCODE
