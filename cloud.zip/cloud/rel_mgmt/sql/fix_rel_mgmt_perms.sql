@/oracle/nfs/share/Oracle_software/rel_mgmt/sql/rel_mgmt_sys_grants_remote.sql &&1 &&2 &&3
connect dba_ora/&&1&&2@&&3
set serveroutput on size 1000000
exec RELMGMT_CLIENT.SYNC_VIEWLET;
commit;
exec RELMGMT_CLIENT.EXEC_PROGRAM('RM_INVENTORY');
