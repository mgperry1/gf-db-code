connect / as sysdba
set feedback on echo on verify on
spool /oracle/dba/dba_ora/scripts/rel_mgmt/backup/apply_timezone_fix_&&2
--
select '&&2' new_global_name, to_char(sysdate,'DD-MON HH24:MI:SS') from dual;
-- What was the Java Pool Size before we set it for Java System install
show parameters java_pool_size
alter system set java_pool_size=100M scope=spfile;
-- Shutdown the databse Abort to kill all connections then wait for 30
-- and Do a Clean sttartup an  Shutdown and Startup
shutdown abort;
!sleep 30
connect / as sysdba
startup restrict;
!sleep 10
shutdown immediate;
!sleep 10
connect / as sysdba
startup restrict;
select '&&2' new_global_name, to_char(sysdate,'DD-MON HH24:MI:SS') from dual;
select 'Start Create or Replace Java' messg, to_char(sysdate,'DD-MON HH24:MI:SS') from dual;
-- Run Create or replace Java
create or replace java system;
connect / as sysdba
select 'End Create or Replace Java' messg, to_char(sysdate,'DD-MON HH24:MI:SS') from dual;
-- Run Create or replace Java
alter system disable restricted session;

