connect / as sysdba

spool /oracle/dba/dba_ora/scripts/rel_mgmt/backup/startup_database_&&2
--
startup
select '&&2' new_global_name from dual;
select '${v_sid_name}' new_global_name from dual;
