connect sys/&&1&&2@&&3 as sysdba
@/oracle/nfs/share/Oracle_software/rel_mgmt/sql/rel_mgmt_sys_grants
connect dba_ora/&&1&&2@&&3
alter session set global_names=false;
Create database link report_upload.world connect to ahs_sdba identified by reporting using '(description=(address=(protocol=tcp)(host=rtpsduxrman001.glaxo.com)(Port=1521))(connect_data=(sid=USPRD316)))';
delete from ahs_sdba.discovery_test@report_upload.world
where 
database_name = upper('&&2')
and hostname = upper('&&3')
and TEST_NAME = upper('TZ_PARMS')
/
drop table discovery_parms 
/
create table discovery_parms as
select
*
from
(select
'REMOTE_LOGIN_PASSWORDFILE' TEST_VALUE
,value TEST_RESULT
,case 
when value = 'EXCLUSIVE' then
'PASSED'
else
'FAILED'
end TEST_STATUS
from sys.v_$parameter s
WHERE 
s.name = 'remote_login_passwordfile'
union all
select
'AUDIT_TRAIL' TEST_VALUE
,value TEST_RESULT
,case 
when value in ('TRUE','DB') then
'PASSED'
else
'FAILED'
end TEST_STATUS
from sys.v_$parameter s
WHERE 
s.name = 'audit_trail'
) t
/
commit;
insert into ahs_sdba.discovery_test@report_upload.world
(
PROCESS
,TEST_NAME
,HOSTNAME
,GLOBAL_NAME
,DATABASE_NAME
,COMP_INV_ID
,TEST_VALUE
,TEST_RESULT
,TEST_STATUS
,upload_date
)
select
'DISCOVERY'
,'TZ_PARMS'
,H.HOSTNAME
,G.DATABASE_NAME
,D.DATABASE_NAME
,'&&5' comp_inv_id
,t.TEST_VALUE
,t.TEST_RESULT
,t.TEST_STATUS
,sysdate
from
(select nvl(SUBSTR(GLOBAL_NAME,1,instr(GLOBAL_NAME,'.') - 1 ),GLOBAL_NAME) DATABASE_NAME from GLOBAL_NAME G) G
--,(select hostname from hostname_view) H
,(select upper('&&4') hostname from dual) H
,(select upper('&&3') database_name from dual) D
,(select
t.TEST_VALUE
,t.TEST_RESULT
,t.TEST_STATUS
from discovery_parms t
) t
/
commit;
