connect sys/&&1&&2@&&3 as sysdba
@/oracle/nfs/share/Oracle_software/rel_mgmt/sql/rel_mgmt_sys_grants
connect dba_ora/&&1&&2@&&3
alter session set global_names=false;
Create database link report_upload.world connect to ahs_sdba identified by reporting using '(description=(address=(protocol=tcp)(host=rtpsduxrman001.glaxo.com)(Port=1521))(connect_data=(sid=USPRD316)))';
delete from ahs_sdba.database_registry_history@report_upload.world
where 
database_name = upper('&&2')
or database_name = upper('&&3')
or script_database_name = upper('&&2')
or script_database_name = upper('&&3')
/
insert into ahs_sdba.database_registry_history@report_upload.world
(
HOSTNAME
,DATABASE_NAME
,ACTION_TIME
,ACTION
,NAMESPACE
,VERSION
,ID
,COMMENTS
,SCRIPT_HOSTNAME
,SCRIPT_DATABASE_NAME
,SCRIPT_COMP_INV_ID
)
select
H.HOSTNAME
,G.DATABASE_NAME
,p.ACTION_TIME
,p.ACTION
,p.NAMESPACE
,p.VERSION
,p.ID
,p.COMMENTS
,upper('&&4')
,upper('&&3')
,upper('&&5')
from
(select nvl(SUBSTR(GLOBAL_NAME,1,instr(GLOBAL_NAME,'.') - 1 ),GLOBAL_NAME) DATABASE_NAME from GLOBAL_NAME G) G
,sys.REGISTRY$HISTORY p
--,(select hostname from hostname_view) H
,(select upper('&&4') hostname from dual) H
/
commit;
