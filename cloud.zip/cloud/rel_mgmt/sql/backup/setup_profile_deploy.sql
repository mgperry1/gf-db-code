set pages 3000
connect sys/&&1&&2@&&3 as sysdba
alter session set global_names=false;
Create database link report_upload.world connect to ahs_sdba identified by reporting using '(description=(address=(protocol=tcp)(host=rtpsduxrman001.glaxo.com)(Port=1521))(connect_data=(sid=USPRD316)))';
drop table local_sed
/
--
-- Create a local copy of the SED table with just the users for this instance
-- Include OPS$ users too
--
create table local_sed as
select
d.USERNAME
from dba_users d
,sed_view@report_upload.world s
where
replace(d.username,'OPS$') = s.GSKMUDID
/
--
-- Generate SQL to Set SED Users to Default Profile
-- Assuming they are in a Profile that can be moved
--
select 'alter user '||d.username||' profile DEFAULT ; '
from dba_users d
,local_sed l
,(
select
profile
from dba_profiles p
group by profile
minus
select
 profile
from
 dba_profiles p
where
p.RESOURCE_NAME in ('COMPOSITE_LIMIT','SESSIONS_PER_USER','CPU_PER_SESSION'
,'CPU_PER_CALL','LOGICAL_READS_PER_SESSION','LOGICAL_READS_PER_CALL','IDLE_TIME'
, 'CONNECT_TIME'
,'PRIVATE_SGA')
 and p.limit not in ('UNLIMITED','DEFAULT')
group by profile
) good_profile
where
d.username = l.username
and d.profile = good_profile.profile
/
--
-- Generate SQL to Set Non-SED Users to DBS_APPLICATION Profile
-- if the user has a diff profile then dont move it
--
select 'alter user '||d.username||' profile DBS_APPLICATION ; '
from 
(select
username
from dba_users d
where
d.profile = 'DEFAULT'
minus
select
username
from
local_sed l ) d
/
--
-- Generate SQL to Set SAP Users to DBS_APPLICATION Profile
--
select 'alter user '||d.username||' profile DBS_APPLICATION ; '
from dba_users d
,PRIVS_TEMPLATE@report_upload.world l
where
d.username = l.GRANTEE
and l.record_type = 'SAP_ACCOUNT'
/
--
-- Generate SQL to Set SAP Users to DBS_SUPPORT Profile
--
select 'alter user '||d.username||' profile DBS_SUPPORT ; '
from dba_users d
,PRIVS_TEMPLATE@report_upload.world l
where
d.username = l.GRANTEE
and l.record_type = 'SUPPORT_ACCOUNT'
/
--
-- Generate SQL to Set SAP Users to DBS_EXCEPT Profile
--
select 'alter user '||d.username||' profile DBS_EXCEPT ; '
from dba_users d
,PRIVS_TEMPLATE@report_upload.world l
where
d.username = l.GRANTEE
and l.record_type = 'PASSWORD_EXCEPTION'
/
drop database link report_upload.world 
/
