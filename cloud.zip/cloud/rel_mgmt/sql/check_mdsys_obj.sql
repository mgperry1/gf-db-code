set lines 3000
col owner for a12
col object_name for a40
col object_type for a20
col status for a15
select
OWNER
,OBJECT_NAME
,OBJECT_TYPE
,STATUS
from dba_objects
where
owner = 'MDSYS'
and object_name in (
'SDO_DROP_USER',
'SDO_TOPO_DROP_FTBL',
'SDO_ST_SYN_CREATE',
'SAMCLUST_IMP_T',
'SAMCLUST_IMP_T',
'SDO_SAM',
'SDO_SAM',
'SPCLUSTERS',
'SDO_GEOR_DROP_USER',
'SDO_GEOR_TRUNC_TABLE',
'SDO_NETWORK_DROP_USER'
)
;

