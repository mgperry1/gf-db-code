-- 
--
connect / as sysdba
set feedback on echo on verify on
spool /oracle/dba/dba_ora/scripts/rel_mgmt/backup/test_sql_script_&&2
show user
--
select '&&2' passed_in_sid, to_char(sysdate,'DD-MON HH24:MI:SS') from dual;
select * from global_name;
spool off
