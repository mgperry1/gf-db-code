
SET VERIFY OFF
SET TERMOUT OFF
SET TRIMOUT ON

DEF dba_ora_pwd=&1
DEF SPOOLFILE=&2

SPOOL &SPOOLFILE
PROMPT ****************************************************
PROMPT db_tools_inst.sql
PROMPT ****************************************************

PROMPT ****************************************************
PROMPT sys_grants.sql
PROMPT ****************************************************
@@sys_grants.sql
PROMPT ****************************************************
PROMPT db_maint_privs.sql
PROMPT ****************************************************
@@db_maint_privs
PROMPT ****************************************************
PROMPT connecting as dba_ora
PROMPT ****************************************************
CONNECT dba_ora/&dba_ora_pwd

PROMPT ****************************************************
PROMPT db_ora_tables.sql
PROMPT ****************************************************
@@dba_ora_tables.sql
PROMPT ****************************************************
PROMPT db_tools_seq.sql
PROMPT ****************************************************
@@db_tools_log_seq.sql
PROMPT ****************************************************
PROMPT db_load_tools_hdr.sql
PROMPT ****************************************************
@@db_load_tools_hdr.sql
PROMPT ****************************************************
PROMPT db_load_tools_body.sql
PROMPT ****************************************************
@@db_load_tools_body.sql
PROMPT ****************************************************
PROMPT db_tools_grnts.sql
PROMPT ****************************************************
@@db_tools_grnts.sql

PROMPT ****************************************************
PROMPT connecting as sys
CONNECT sys / as sysdba
PROMPT ****************************************************

PROMPT Moving Data
DECLARE
      CURSOR cur_get 
      IS
         SELECT object_name
         FROM all_objects
         WHERE owner = 'GW_MAINT_PROCS'
         AND object_name IN ('GW_TOOLS_OBJECTS', 'GW_TOOLS_ACCESS')
         ORDER BY object_name;
      var_sql VARCHAR2(32000);
      var_object_name all_objects.object_name%TYPE;
BEGIN
    OPEN cur_get;
    LOOP
        FETCH cur_get 
            INTO var_object_name;
    EXIT WHEN cur_get%NOTFOUND;
        IF var_object_name = 'GW_TOOLS_ACCESS' THEN
            var_sql := 'INSERT INTO dba_ora.db_tools_access '||
	               '(requestor_schema '||
	               ',object_owner_schema '||
	               ',time_stamp) '||
                   'SELECT '||
	               'requestor_schema '||
	               ',object_owner_schema '||
	               ',time_stamp '||
                   'FROM '||
	               'gw_maint_procs.gw_tools_access';
        ELSIF var_object_name = 'GW_TOOLS_OBJECTS' THEN
            var_sql := 'INSERT INTO dba_ora.db_tools_objects '||
	                '('||
	                'user_id'||
	                ',time_stamp'||
	                ',owner	'||
	                ',object_type'||
	                ',object_name'||
	                ',related_owner'||
	                ',related_object_name'||
	                ',sql_stmt'||
	                ',related_object_info)'||
                'SELECT '||
	                'user_id'||
	                ',time_stamp'||
	                ',owner	'||
	                ',object_type'||
	                ',object_name'||
	                ',related_owner'||
	                ',related_object_name'||
	                ',sql_stmt'||
	                ',related_object_info'||
                   'FROM gw_maint_procs.gw_tools_objects';
         ELSE
             var_sql := NULL;
         END IF;
         IF var_sql IS NOT NULL THEN
             BEGIN
                 EXECUTE IMMEDIATE var_sql;
                 COMMIT;
                 DBMS_OUTPUT.put_line (SUBSTR('Inserted '||SQL%ROWCOUNT||' Into ' ||
                                              var_object_name, 1, 200));
             EXCEPTION
                 WHEN OTHERS THEN
                     DBMS_OUTPUT.put_line (SUBSTR(SQLERRM, 1, 200));
             END;
         END IF;
     END LOOP;
     CLOSE cur_get;
END;
/
PROMPT ****************************************************
PROMPT creating Role
PROMPT ****************************************************
@@db_tool_access_role.sql
PROMPT ****************************************************
PROMPT Redirecting tools
PROMPT ****************************************************
@@db_tool_synonyms.sql
PROMPT ****************************************************
PROMPT Doing Grants and  Revoking Grants
PROMPT ****************************************************
@@build_grnts.sql
PROMPT ****************************************************
PROMPT Exiting
PROMPT ****************************************************
SPOOL OFF
EXIT


