declare
 l_mudid varchar2(30);
 l_email varchar2(500);
 l_Display varchar2(500);
 l_message varchar2(30000);
 l_subject varchar2(1000);
 l_parm1 varchar2(1000);
 qt varchar2(30) := '''';
 crlf VARCHAR2( 2 ):= CHR( 13 ) || CHR( 10 );
Begin
 l_mudid := upper(nvl('${V_REQ_MUDID}','MGP17171'));
 l_parm1 := upper(nvl('${V_FILE_ID}','400'));
 l_subject := upper(nvl('${V_SUBJECT}','Automated Mail'));

 select DISPLAYNAME,EMAIL_ADDR into l_Display,l_email from sed_view where GSKMUDID = l_mudid;

 l_message := 'Hi '||l_Display||','||crlf||
       'The RDA Report for ${v_sid_name} Completed.'||crlf||
       'Use the following to to download the '||
       ahs_display.show_link('MAIL_FILE_LINK',l_parm1,'RDA zip file')||crlf||
       'Thanks';

 sarbox_utility.mail(to_list => l_email, subj => l_subject, body => l_message , html_body => l_message);
             
end; 
/
