echo "connect ${V_USERPASSCON}"
echo "set pages 3000 heading off feedback off serveroutput on size 1000000 "
echo "spool ${V_L_SQL_DIR}/chg_pwd_${v_db_name}_$$.sql"
echo "select 'alter user '||username||' identified by values '''||derived_value|| ''';' "
echo "from database_user_maint_v7 "
echo "where db_comp_inv_id like '${v_comp_inv_id}'; "
echo "connect dba_ora/${NEWSTUB}${v_db_sid}@${v_db_name} "
echo "alter session set  global_names=false; "
echo "@${V_L_SQL_DIR}/chg_pwd_${v_db_name}.sql"

alter session set global_names=false;
declare
 l_sql varchar2(1000);
 cur integer;
 l_global_name varchar2(255);
begin
 select  
end; 
/
