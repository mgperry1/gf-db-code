#!/usr/bin/ksh

######################################################################
# Filename    : sdba_functions.sh
# Version     : 4.0
# Summary     : Sets the SDBA functions
# Calls       : No other scripts
# Parameters  : None
#
# NOTES:
# To enable trace execute the following command before running any 
# functions: 
#   export DEBUGMODE=True
#
# For the usage of each function, execute: "<function> help"
#
# Date      Author   Version 
# --------- -------- ------- 
# 16-Oct-02 ASBlack  1.0     
# - First issued version.
#
# 13-Jan-02 ASBlack  2.0     
# - Ensure that sdba_oraenv doesn't permanently change ORAENV_ASK. 
# - Added sdba_mdf, sdba_PATHadd, sdba_cal, and sdba_admin.
#
# 20-Feb-03 ASBlack  3.0     
# - Added sdba_time_diff, sdba_ipcs and sdba_sqldba.  
# - Edited sdba_db_status to use sdba_sqldba and be 9i compatible.  
# - Amended rm ${TMP}.* to only work if ${TMP} is set.
# - Amended so that the functions could run in the Bourne shell
#   This required each functions variables to be given a unique name
#   since the "typeset" cannot be used to define local variables in 
#   the Bourne shell.
#
# 28-Jan-04 ASBlack  4.0
# - Amended PRG=`basename $0` to be PRG=<name of script> since this
#   does not work correctly for functions (basename $0 brings back 
#   "-ksh")
# - Amended sdba_db_status to NOT check for the name in v$database as
#   against the name in the init.ora file as they may not always be 
#   the same case.  This was an additional check.  Instead, code has 
#   been added to ensure that the database environment is correctly 
#   changed via sdba_oraenv, and then check for "X" out of dual.
# - Amended sdba_ipcs to determine the audit_file_dest if it has been 
#   set, rather than just assume that it will be the default of 
#   $ORACLE_HOME/rdbms/audit (which is not the case with, for example,
#   database UKDEV263).
# - Amended sdba_oraenv to set ORACLE_HOME for the ORACLE_SID passed
#   and to add $ORACLE_HOME/bin to the PATH.  This ensures that script
#   oraenv can be found, and it in turn can find script dbhome.
# - Amended sdba_admin and sdba_alert to 
#     grep -i "^background_dump_dest" since it occasionally is in 
#   uppercase or there is a hashed out entry above it
# - Amended sdba_stub to use ~dba_ora/scripts/dat directory
# - Amended sdba_mail to use ~dba_ora/scripts/dat directory
#
######################################################################


#=====================================================================
# Function a - all variables to be prefixed with a_ 
sdba_mail()
#=====================================================================
{
[ ${DEBUGMODE:=False} = True ] && set -xv

if [ $# -eq 1 ]; then if [ "${1}" = "help" ]; then cat <<END
#--------------------------------------------------------------------
# Function    : sdba_mail
# Summary     : Sends an email 
# Parameters  : Optional
#             :   \$1=MESSAGE     (Defaults to "No message")
#--------------------------------------------------------------------
END
return 0
fi; fi

#-- Initialise variables
a_DISTLIST=/oracle/dba/dba_ora/scripts/dat/sdba_distribution.dat
a_MESSAGE=""
a_RECIPIENTS=""
a_SUBJECT=""

#-- Get the message from the command line
if [ $# -ne 0 ]; then a_MESSAGE=$@; fi

#-- Strip out any colons from the a_MESSAGE as this will prevent it printing
a_MESSAGE=`echo ${a_MESSAGE} |sed -e 's/://g'`

#-- Check that the distribution list file exists and is readable
if [ ! -r ${a_DISTLIST} ]; then
  echo "sdba_mail: ERROR: File ${a_DISTLIST} does not exist or is not readable" >&2
  return 20
fi

#-- Get recipients from the distribution list
a_RECIPIENTS=`cat ${a_DISTLIST}`

#-- Check that there are recipients
if [ -z "${a_RECIPIENTS}" ]; then
  echo "sdba_mail: ERROR: No recipients in distlist ${a_DISTLIST}"
  return 30
fi

#-- Create the subject heading (add hostname and only print first 50 letters of message)
a_SUBJECT="`hostname`: `echo ${a_MESSAGE} |awk '{print substr($0,1,50)}'`"

#-- Send email
sdba_datemsg "Sending email ..."
cat <<+++END+++ | mail ${a_RECIPIENTS}
TO: ${a_RECIPIENTS}
SUBJECT: ${a_SUBJECT}
${a_MESSAGE}
+++END+++
}


#=====================================================================
# Function b - all variables to be prefixed with b_ 
sdba_stub()
#=====================================================================
{
[ ${DEBUGMODE:=False} = True ] && set -xv

if [ $# -eq 1 ]; then if [ "${1}" = "help" ]; then cat <<END
#--------------------------------------------------------------------
# Function    : sdba_stub
# Summary     : Echo the sdba stub
# Parameters  : Optional
#             :   \$1=USERNAME     (Defaults to system)
#--------------------------------------------------------------------
END
return 0
fi; fi

#-- Get variables
if [ $# -ge 1 ]; then 
  b_USERNAME=`echo ${1} |tr [A-Z] [a-z]`
else
  b_USERNAME=system
fi

b_STUBFILE=/oracle/dba/dba_ora/scripts/dat/sdba_stub.${b_USERNAME}

#-- Check that the stubfile exists and is readable
if [ ! -r ${b_STUBFILE} ]; then 
  echo "sdba_stub: ERROR: File ${b_STUBFILE} does not exist or is not readable" >&2
  return 10
fi

#-- Echo the stub
egrep -v "^$|^#" ${b_STUBFILE} |head -1 |awk '{print $1}'
}


#=====================================================================
# Function c - all variables to be prefixed with c_ 
sdba_datemsg()
#=====================================================================
{
[ ${DEBUGMODE:=False} = True ] && set -xv

if [ $# -eq 1 ]; then if [ "${1}" = "help" ]; then cat <<END
#--------------------------------------------------------------------
# Function    : sdba_datemsg
# Summary     : Date/time stamps the message given
# Parameters  : <message>=all parameters passed
# 
# EXAMPLE(S)
# 1) sdba_datemsg This is a test message
# 2) sdba_datemsg The current directory is \`pwd\`
#--------------------------------------------------------------------
END
return 0
fi; fi

c_MSG=${@:-""}
echo
date +"%Y/%m/%d %H:%M:%S ${c_MSG}"
}


#=====================================================================
# Function d - all variables to be prefixed with d_ 
sdba_sids()
#=====================================================================
{
[ ${DEBUGMODE:=False} = True ] && set -xv

if [ $# -eq 1 ]; then if [ "${1}" = "help" ]; then cat <<END
#--------------------------------------------------------------------
# Function    : sdba_sids
# Summary     : Lists oracle sids in the oratab file
# Parameters  : None
#--------------------------------------------------------------------
END
return 0
fi; fi

egrep -iv "^#|^$|^dummy:|\*" /etc/oratab /var/opt/oracle/oratab 2>/dev/null \
  |awk -F":" '{print $2}' \
  |sort -u 
}



#=====================================================================
# Function e - all variables to be prefixed with e_ 
sdba_oraenv()
#=====================================================================
{
[ ${DEBUGMODE:=False} = True ] && set -xv

if [ $# -eq 1 ]; then if [ "${1}" = "help" ]; then cat <<END
#--------------------------------------------------------------------
# Function    : sdba_oraenv
# Summary     : Sets the Oracle environment
# Parameters  : \$1=ORACLE_SID
#--------------------------------------------------------------------
END
return 0
fi; fi

#-- Check that one ORACLE_SID is passed
if [ $# -ne 1 ]; then
  echo "sdba_oraenv: ERROR: One ORACLE_SID not passed" >&2
  return 10
fi

#-- Set intermediate SID variable
e_SID=${1}

#-- Ensure that the ORACLE_SID is a valid one
if [ `sdba_sids |grep -c "^${e_SID}$"` -ne 1 ]; then
  echo "sdba_oraenv: ERROR: ORACLE_SID not valid" >&2
  return 20
fi

#-- Add ORACLE_HOME/bin for this SID to the PATH
#-- so that we can run oraenv and it can find dbhome
e_ORACLE_HOME=`cat /etc/oratab /var/opt/oracle/oratab 2>/dev/null |grep "^${e_SID}:" |head -1 |awk -F":" '{print $2}'`
sdba_PATHadd ${e_ORACLE_HOME}/bin

#-- Set the environment
ORACLE_SID=${e_SID} ; export ORACLE_SID
e_PREV_ORAENV_ASK=${ORAENV_ASK:-YES}
ORAENV_ASK=NO ; export ORAENV_ASK
. oraenv >/dev/null 2>&1
ORAENV_ASK=${e_PREV_ORAENV_ASK}

#-- Reset ORACLE_SID for a RAC environment
RAC="NO"
THIS_HOST=`hostname`
#if [ $# -eq 1 ]; then SID=${1}; fi
#sdba_oraenv ${SID}
if [ -f  ${ORACLE_HOME}/bin/srvctl ]; then
  if [ -f ${ORACLE_HOME}/bin/lsnodes -o -f ${ORACLE_HOME}/bin/olsnodes ]; then
    RAC="YES"
  fi
fi
if [ "${RAC}" = "YES" ]; then
  ORACLE_SID=`${ORACLE_HOME}/bin/srvctl config database -d ${e_SID} |grep ${THIS_HOST} |cut -f 2 -d " "`
  export $ORACLE_SID
fi

#-- Only required for sun but set it anyway
LD_LIBRARY_PATH=$ORACLE_HOME/lib:/usr/openwin/lib:/usr/dt/lib
export LD_LIBRARY_PATH

#-- Oracle Bug 2410612 workaround
ORA_OCI_NO_OPTIMIZED_FETCH=1
export ORA_OCI_NO_OPTIMIZED_FETCH
}


#=====================================================================
# Function f - all variables to be prefixed with f_ 
sdba_db_status()
#=====================================================================
{
[ ${DEBUGMODE:=False} = True ] && set -xv

if [ $# -eq 1 ]; then if [ "${1}" = "help" ]; then cat <<END
#--------------------------------------------------------------------
# Function    : sdba_db_status
# Summary     : Determines if we can connect to a database
# Parameters  : The function will get the status of all SIDs passed 
#             : as parameters.
#             : If no parameters are passed then the function will 
#             : get the status of all the databases on this node. 
#
# OUTPUT(S) 
# \$ORACLE_SID      OPEN          (if it CAN    connect)
# \$ORACLE_SID      SHUT          (if it CANNOT connect)
# \$ORACLE_SID      INVALID_SID   (if an invalid sid has been specified)
#--------------------------------------------------------------------
END
return 0
fi; fi

#-- Set variables
f_TMP=/tmp/sdba_db_status.$$
f_SIDLIST=""

#-- Get the list of SIDs to check
if [ $# -eq 0 ]; then
  f_SIDLIST=`sdba_sids`
else
  f_SIDLIST=$@
fi

#-- Check each SID
(
for f_SID in ${f_SIDLIST}
do

  #-- Check that the ORACLE_SID is a valid one
  if [ `sdba_sids |grep -c "^${f_SID}$"` -ne 1 ]; then

    echo "${f_SID} INVALID_SID" 
 
  else

    #-- Set ORACLE_SID and the Oracle environment
    sdba_oraenv ${f_SID}
    if [ $? -ne 0 ]; then 
      echo "sdba_db_status: ERROR: Could not set the ORACLE_SID and environment" >&2
      return 20
    fi

    #-- Try and get the name from the database
    echo 'select * from dual;' > ${f_TMP}.sql 
    sdba_sqldba sql=${f_TMP}.sql > ${f_TMP}.out

    #-- Check if we've got X from dual
    #   For some bizarre reason the output must be redirected to
    #   a file and then the grep applied to the file  (???)
    if [ `grep -c "^X$" ${f_TMP}.out` -eq 1 ]; then
      echo "${f_SID} OPEN" 
    else
      echo "${f_SID} SHUT" 
    fi
  fi
done
) | awk '{printf "%-20s %-s\n",$1,$2}'

#-- Tidy up
if [ ! -s "${f_TMP}" ]; then \rm ${f_TMP}.* 2>/dev/null; fi
}


#=====================================================================
# Function g - all variables to be prefixed with g_ 
sdba_alertlog()
#=====================================================================
{
[ ${DEBUGMODE:=False} = True ] && set -xv

if [ $# -eq 1 ]; then if [ "${1}" = "help" ]; then cat <<END
#--------------------------------------------------------------------
# Function    : sdba_alertlog
# Summary     : Prints the alert log with date-time stamps 
# Parameters  : Optional
#             :   sid=<ORACLE_SID>
#             :   log=<alert log to be processed>
#
# EXAMPLE(S)
# 1) sdba_alertlog
# Processes the current alert log for the current ORACLE_SID
#
# 2) sdba_alertlog sid=SOMESID
# Processes the current alert log for SOMESID
#
# 3) sdba_alertlog log=/tmp/alertlog.old
# Processes the alert log /tmp/alertlog.old (regardless of the current 
# ORACLE_SID).  Can handle gzip'd or compressed alertlogs.
#--------------------------------------------------------------------
END
return 0
fi; fi

#-- Set local variables
sid=""
log=""
g_PARAMETERS=""
g_CMD=""
g_ORACLE_HOME=""

#-- Get and evaluate command line parameters
if [ $# -ne 0 ]; then g_PARAMETERS=$@; eval $@; fi

#-- Echo start time and command
sdba_datemsg "Start  sdba_alertlog ${g_PARAMETERS}"

#-- Set the SID
g_SID=${sid:-$ORACLE_SID}

#-- Determine the location of the alert log if not specified
g_LOG=${log}
if [ -z "${g_LOG}" ]; then

  #-- Set the environment to determine the ORACLE_HOME
  sdba_oraenv ${g_SID}
  
  #-- Determine where the initora file is and check it exists and is readable
  INITORA=${ORACLE_HOME}/dbs/init${g_SID}.ora
  if [ ! -r ${INITORA} ]; then
    echo "sdba_alertlog: ERROR: init.ora file ${INITORA} does not exist or is not readable"
    return 30
  fi

  #-- Determine what background_dump_dest is set to in the init.ora file
  #   (It defaults to ?/rdbms/log within the database if it's not in the init.ora file)
  IFILE=`awk '$1=="ifile" {print $3}' ${INITORA}`
  BACKGROUND_DUMP_DEST=`grep -i "^background_dump_dest" ${INITORA} ${IFILE} |head -1 |awk -F"=" '{print $2}' |sed -e 's/[      ]//g'` 
  if [ -z "${BACKGROUND_DUMP_DEST}" ]; then
    BACKGROUND_DUMP_DEST=${ORACLE_HOME}/rdbms/log
  fi

  #-- Ensure that $ORACLE_HOME is expanded out 
  #   This fixes a strange bug when running remotely, and 
  #   background_dump_dest contains string: $ORACLE_HOME
  eval BACKGROUND_DUMP_DEST=`echo ${BACKGROUND_DUMP_DEST} |sed -e "s+\$ORACLE_HOME+${ORACLE_HOME}+"`

  #-- Determine where the alertlog file is 
  g_LOG=${BACKGROUND_DUMP_DEST}/alert_${g_SID}.log

fi

#-- Check the log exists and is readable
if [ ! -r "${g_LOG}" ]; then
  echo "sdba_alertlog: ERROR: Log ${g_LOG} does not exist or is not readable"
  return 40
fi

#-- List alertlog for reference
sdba_datemsg "Processing alertlog ${g_LOG}"
ls -l ${g_LOG} 
echo

#-- Get the command to send the alertlog to stdout
if   [ `echo ${g_LOG} |grep -c ".gz$"` -eq 1 ]; then
  g_CMD="gzip -dc ${g_LOG}"
elif [ `echo ${g_LOG} |grep -c ".Z$"` -eq 1 ]; then
  g_CMD="zcat ${g_LOG}"
else
  g_CMD="cat ${g_LOG}"
fi

#-- Print out the alert log with time stamps at the start of each record
#-- Note that date's in the alert log have the format:
#--   Fri Aug 16 12:52:55 2002
echo ${g_CMD} |ksh \
  |awk '{

if($1=="Mon" || $1=="Tue" || $1=="Wed" || $1=="Thu" || $1=="Fri" || $1=="Sat" || $1=="Sun")
 {
  DAY=$1
  TIME=$4
  YEAR=$5
  
  DATE=$3
  if(length(DATE)==1){DATE="0"DATE}

  if($2=="Jan"){MONTH="01"}
  if($2=="Feb"){MONTH="02"}
  if($2=="Mar"){MONTH="03"}
  if($2=="Apr"){MONTH="04"}
  if($2=="May"){MONTH="05"}
  if($2=="Jun"){MONTH="06"}
  if($2=="Jul"){MONTH="07"}
  if($2=="Aug"){MONTH="08"}
  if($2=="Sep"){MONTH="09"}
  if($2=="Oct"){MONTH="10"}
  if($2=="Nov"){MONTH="11"}
  if($2=="Dec"){MONTH="12"}

 }
else
 { 
  print YEAR"/"MONTH"/"DATE" "DAY" "TIME" "$0 
 }
}'
}

#=====================================================================
# Function h - all variables to be prefixed with h_ 
sdba_mdf()
#=====================================================================
{
[ ${DEBUGMODE:=False} = True ] && set -xv

if [ $# -eq 1 ]; then if [ "${1}" = "help" ]; then cat <<END
#--------------------------------------------------------------------
# Function    : sdba_mdf
# Summary     : Displays disk usage in Megabytes
# Parameters  : Optional
#             :   Specific filesystems (and/or wildcards) to be
#             :   listed
#
# EXAMPLE(S)
# 1) sdba_mdf
# Displays the disk usage of all filesystems
#
# 2) sdba_mdf /oracle/*
# Displays the disk usage of all /oracle/* filesystems
#--------------------------------------------------------------------
END
return 0
fi; fi

#-- Get parameters if there are any
h_PARAMETERS=""
if [ $# -ne 0 ]; then h_PARAMETERS=$@; fi

#-- Get command to run
if [ `uname` = "HP-UX" ]; then 
  h_CMD="bdf ${h_PARAMETERS}"
else 
  h_CMD="df -k ${h_PARAMETERS}"
fi

#-- Print field headings
echo "Filesystem Mbytes used avail %used Mounted_on" \
  |awk '{printf "%-19s %6s %7s %7s %6s %-20s\n",$1 ,$2 ,$3, $4, $5, $6}'

#-- Display disk usage and ensure that lines that are chopped are
#-- put back together.
echo ${h_CMD} \
  |ksh \
  |awk 'NR==1{next} {if(NF>1)print;else{f=$1;getline;print f $0}}' \
  |awk '{printf "%-19s %6.0f %7.0f %7.0f %6s %-20s\n",$1 ,$2/1024, $3/1024, $4/1024, $5, $6}' \
  |sort +5
}


#=====================================================================
# Function i - all variables to be prefixed with i_ 
sdba_PATHadd()
#=====================================================================
{
[ ${DEBUGMODE:=False} = True ] && set -xv

if [ $# -eq 1 ]; then if [ "${1}" = "help" ]; then cat <<END
#--------------------------------------------------------------------
# Function    : sdba_PATHadd
# Summary     : Add directory(s) to the PATH only if they are not there
# Parameters  : Mandatory
#             :   List of directory(s) to add
#
# EXAMPLE(S)
# 1) sdba_PATHadd /tmp /tmp/test
# Adds /tmp and /tmp/test to the PATH
#--------------------------------------------------------------------
END
return 0
fi; fi

i_NEWPATH=${PATH}
if [ $# -ne 0 ]; then
  for i_DIR in $@
  do
    if [ `echo ":"${i_NEWPATH}":" |grep -c ":${i_DIR}:"` -eq 0 ]; then
      i_NEWPATH=${i_NEWPATH}:${i_DIR}
    fi
  done
fi
PATH=${i_NEWPATH}
}


#=====================================================================
# Function j - all variables to be prefixed with j_ 
sdba_cal()
#=====================================================================
{
[ ${DEBUGMODE:=False} = True ] && set -xv

if [ $# -eq 1 ]; then if [ "${1}" = "help" ]; then cat <<END
#--------------------------------------------------------------------
# Function    : sdba_cal
# Summary     : Prints out a more usable calander than cal does.
# Parameters  : Optional (default will be current month)
#             :   \$1=MM   (Month)
#             :   \$2=YYYY (Year)
#
# EXAMPLE(S)
# 1) sdba_cal
# Displays the current month
#
# 2) sdba_cal 10 2002
# Displays October 2002
#--------------------------------------------------------------------
END
return 0
fi; fi

if   [ $# -eq 0 ]; then 
  j_M=`date +"%m"`
  j_Y=`date +"%Y"`
elif [ $# -eq 1 ]; then
  j_M=${1}
  j_Y=`date +"%Y"`
else
  j_M=${1}
  j_Y=${2}
fi

cal ${j_M} ${j_Y} \
  |grep -v "^$" \
  |awk '{if(NR>2) 
           { 
             SUN=substr($0, 1,2)
             MON=substr($0, 4,2)
             TUE=substr($0, 7,2)
             WED=substr($0,10,2)
             THU=substr($0,13,2)
             FRI=substr($0,16,2)
             SAT=substr($0,19,2)
             print SUN,"Sun"
             print MON,"Mon"
             print TUE,"Tue"
             print WED,"Wed"
             print THU,"Thu"
             print FRI,"Fri"
             print SAT,"Sat"
            }
       }' \
  |sed -e "s/^/${j_Y} ${j_M} /" \
  |awk '{if(NF==4){print $0}}' \
  |sed -e 's/  / 0/'
}

#=====================================================================
# Function k - all variables to be prefixed with k_ 
sdba_admin()
#=====================================================================
{
[ ${DEBUGMODE:=False} = True ] && set -xv

if [ $# -eq 1 ]; then if [ "${1}" = "help" ]; then cat <<END
#--------------------------------------------------------------------
# Function    : sdba_admin
# Summary     : Change to the admin directory for the current ORACLE_SID
# Parameters  : None
#--------------------------------------------------------------------
END
return 0
fi; fi

#-- Check that the ORACLE_SID is set
if [ -z "${ORACLE_SID}" ]; then
  echo "ERROR: ORACLE_SID not set"
  exit 10
fi
echo ORACLE_SID = ${ORACLE_SID}

#-- Determine the ORACLE_HOME
k_ORACLE_HOME=`grep "^${ORACLE_SID}:" /etc/oratab /var/opt/oracle/oratab 2>/dev/null |head -1 |awk -F":" '{print $3}'`
echo ORACLE_HOME = ${k_ORACLE_HOME}
  
#-- Determine where the init.ora file is
k_INITORA=${ORACLE_HOME}/dbs/init${ORACLE_SID}.ora
echo INITORA = ${k_INITORA}

#-- Determine if there is an ifile
k_IFILE=`grep -i "^ifile" ${k_INITORA} |head -1 |awk -F"=" '{print $2}'`
echo IFILE = ${k_IFILE}

#-- Determine where the background dump destination is
k_BACKGROUND_DUMP_DEST=`grep -i "^background_dump_dest" ${k_INITORA} ${k_IFILE} |head -1 |awk -F"=" '{print $2}' |sed -e 's/[       ][      ]*//g'`
echo BACKGROUND_DUMP_DEST = ${k_BACKGROUND_DUMP_DEST}

#-- Get the admin directory (the parent of the BACKGROUND_DUMP_DEST one)
k_ADMINDIR=`echo ${k_BACKGROUND_DUMP_DEST} |sed -e 's+/bdump++'`
echo ADMINDIR = ${k_ADMINDIR}

#-- Change directory to this admin directory
echo Changing to ${k_ADMINDIR} ...
cd ${k_ADMINDIR}
}

#=====================================================================
# Function m - all variables to be prefixed with m_ 
sdba_ipcs()
#=====================================================================
{
[ ${DEBUGMODE:=False} = True ] && set -xv

if [ $# -eq 1 ]; then if [ "${1}" = "help" ]; then cat <<END
#--------------------------------------------------------------------
# Function    : sdba_ipcs
# Summary     : Match shared memory segments to instances
#             : by cross-referencing the creating pid with the correct 
#             : audit file
# Parameters  : None
#--------------------------------------------------------------------
END
return 0
fi; fi


#--------------------------------------------------------------------
# Sample output from ipcs -mbpa:
#--------------------------------------------------------------------

# T      ID     KEY        MODE        OWNER     GROUP   CREATOR    CGROUP NATTCH  SEGSZ  CPID  LPID   ATIME    DTIME    CTIME 
# Shared Memory:
# m       0 0x41200626 --rw-rw-rw-      root      root      root      root      0    348   695   695 10:05:00 10:05:00 10:04:53
# m       1 0x4e0c0002 --rw-rw-rw-      root      root      root      root      1  31040   695   695 10:04:57 10:05:00 10:04:53
# m       2 0x4124068a --rw-rw-rw-      root      root      root      root      1   8192   695   707 10:04:57 10:04:53 10:04:53
# m   25091 0x0cda16f8 --rw-r-----    oracle       dba    oracle       dba      7 114786304 21574 26405 16:01:26 16:01:27 16:38:40
# m   24068 0x402636a8 --rw-r-----    oracle       dba    oracle       dba      7 34177024 29428 26326 16:01:22 16:01:22 12:46:02
# m   41989 0x318f8ef4 --rw-r-----    oracle  oinstall    oracle  oinstall      7 33222656 18174 26237 16:01:18 16:01:18 11:08:06
# m   15366 0x7238e95a --rw-r-----    oracle  oinstall    oracle  oinstall      7 27725824 18135 26125 16:01:13 16:01:13 11:05:21
# m   15879 0x7f1bdda8 --rw-r-----    oracle       dba    oracle       dba      5 29605888   146 14038  9:33:26  9:33:27 11:25:53

#--------------------------------------------------------------------


#--------------------------------------------------------------------
# Sample startup audit file:
#--------------------------------------------------------------------
# Notes:
# 1) The name of the file contains CPID 18135
# 2) A line contains "Instance name: DBA734"
# 3) A line contains "ACTION : 'startup'"
# 4) A line contains a time of 11:05:21 (same as the ipcs -mbpa record above)
#--------------------------------------------------------------------

# Audit file /opt/oracle/app/product/7.3.4/rdbms/audit/ora_18135.aud
# Oracle7 Server Release 7.3.4.5.0 - Production
# With the distributed, parallel query and Spatial Data options
# PL/SQL Release 2.3.4.5.0 - Production
# ORACLE_HOME = /opt/oracle/app/product/7.3.4
# System name:    HP-UX
# Node name:      ukdbulv1
# Release:        B.11.00
# Version:        A
# Machine:        9000/861
# Instance name: DBA734
# Redo thread mounted by this instance: 1
# Oracle process number: 0
# Unix process pid: 18135, image: oracleDBA734
# 
# Wed Feb 12 11:03:33 2003
# ACTION : 'connect internal' OSPRIV : DBA
# CLIENT USER: oracle
# CLIENT TERMINAL: pts/tb
# 
# Wed Feb 12 11:05:10 2003
# ACTION : 'shutdown'
# 
# Wed Feb 12 11:05:21 2003
# ACTION : 'startup' AUDIT_TRAIL : none
# 
# Wed Feb 12 11:05:21 2003
# ACTION : 'startup' OS_AUTHENT_PREFIX : OPS$"
# 
# Wed Feb 12 11:05:22 2003
# ACTION : 'connect internal' OSPRIV : DBA
# CLIENT USER: oracle
# CLIENT TERMINAL: pts/tb

#--------------------------------------------------------------------

#-- Set variables
m_PRG=sdba_ipcs
m_TMP=/tmp/${m_PRG}.$$

#-- List oracle owned ipcs shared memory records to an intermediate file
ipcs -mpba |grep oracle > ${m_TMP}.ipcs

#-- List audit_file_dest's to an intermediate file
for m_SID in `sdba_sids`
do
  m_ORA_HOME=`grep "^${m_SID}:" /etc/oratab /var/opt/oracle/oratab 2>/dev/null |awk -F":" '{print $3}'` 
  m_AUDIT_FILE_DEST=`grep "^audit_file_dest" ${m_ORA_HOME}/dbs/init${m_SID}.ora |tail -1 |sed -e 's/=/ /' |awk '{print $2}'`

  #-- The default audit_file_dest is $ORACLE_HOME/rdbms/audit
  if [ -z "${m_AUDIT_FILE_DEST}" ]; then 
    echo ${m_ORA_HOME}/rdbms/audit
  else
    echo ${m_AUDIT_FILE_DEST}
  fi
done > ${m_TMP}.audit_file_dests

#-- Print header
(
echo "ORACLE_SID T ID KEY MODE OWNER GROUP NATTCH SEGSZ CPID LPID ATIME DTIME CTIME"
) |awk '{printf "%-12s %1s %-5s %-10s %-11s %-7s %-8s %6s %10s %5s %5s %8s %8s %8s\n",$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14}'
echo "AUDIT FILE LISTING"

#-- Loop through each Creating Process ID (CPID) in the ipcs records and 
#-- try and determine which database it corresponds to
cat ${m_TMP}.ipcs |while read m_T m_ID m_KEY m_MODE m_OWNER m_GROUP m_CREATOR m_CGROUP m_NATTCH m_SEGSZ m_CPID m_LPID m_ATIME m_DTIME m_CTIME
do

  #-- List all audit files in each audit_file_dest created with this CPID
  cat ${m_TMP}.audit_file_dests | while read m_AUDIT_FILE_DEST
  do
    ls ${m_AUDIT_FILE_DEST}/ora_${m_CPID}.aud \
       ${m_AUDIT_FILE_DEST}/ora_${m_CPID}.aud.gz \
       ${m_AUDIT_FILE_DEST}/ora_${m_CPID}.aud.Z \
       2>/dev/null 
  done |sort -u > ${m_TMP}.audfiles

  #-- If any audit files exist for this CPID ...
  if [ -s ${m_TMP}.audfiles ]; then

    #-- Process each in turn and determine if it is a 
    #-- startup audit file for the CTIME in question ...

    for m_AUDFILE in `cat ${m_TMP}.audfiles`
    do

      #-- Determine if the audit file is gzipped, compressed or not
      if   [ `echo ${m_AUDFILE} |grep -c ".gz$"` -eq 1 ]; then
        m_CMD="gzip -dc ${m_AUDFILE}"
      elif [ `echo ${m_AUDFILE} |grep -c ".Z$"` -eq 1 ]; then
        m_CMD="zcat ${m_AUDFILE}"
      else
        m_CMD="cat ${m_AUDFILE}"
      fi
  
      #-- Check that the audit file is for a startup
      if [  `echo ${m_CMD} |ksh |grep -ic "ACTION : 'startup'"` -ne 0 ]; then

        #-- Determine the time of startup from the log 
        m_STARTUPTIME=""
        m_STARTTIME=`sdba_alertlog log=${m_AUDFILE} |grep -i "ACTION : 'startup'" |tail -1 |awk '{print $3}'`

        #-- Check the number of seconds between the startup time and the CTIME is 5 secs or less
        if [ `sdba_time_diff ${m_STARTTIME} ${m_CTIME} |awk '{print $4}'` -le 5 ]; then

          #-- Get the instance name
          m_SID=`echo ${m_CMD} |ksh |grep "Instance name: " |awk '{print $3}' |tail -1`
       
          #-- Print the record
          echo
          (
          echo "${m_SID} ${m_T} ${m_ID} ${m_KEY} ${m_MODE} ${m_OWNER} ${m_GROUP} \c"
          echo "${m_NATTCH} ${m_SEGSZ} ${m_CPID} ${m_LPID} ${m_ATIME} ${m_DTIME} ${m_CTIME}"
          ) |awk '{printf "%-12s %1s %-5s %-10s %-11s %-7s %-8s %6s %10s %5s %5s %8s %8s %8s\n",$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14}'

          #-- List the audit file
          ls -l ${m_AUDFILE}

        fi
         
      fi

    done

  fi

done

#-- Tidy up
if [ ! -s "${m_TMP}" ]; then \rm ${m_TMP}.* 2>/dev/null; fi
}

#=====================================================================
# Function n - all variables to be prefixed with n_ 
sdba_sqldba()
#=====================================================================
{
[ ${DEBUGMODE:=False} = True ] && set -xv

if [ $# -eq 1 ]; then if [ "${1}" = "help" ]; then cat <<END
#--------------------------------------------------------------------
# Function    : sdba_sqldba
# Summary     : Execute SQL with DBA priviledges
#             :  - either svrmgrl and connect internal
#             :  - or sqlplus and connect / as sysdba
# Parameters  : sql=<file containing the SQL to be run>
#--------------------------------------------------------------------
END
return 0
fi; fi

#-- Set variables
n_PRG=sdba_sqldba
n_TMP=/tmp/${n_PRG}.$$

#-- Get the SQL to be run
if [ $# -eq 0 ]; then echo "${n_PRG}: ERROR: sql parameter not supplied"; return 10; fi

sql=""
eval $@
n_SQL=${sql}
if [ -z "${n_SQL}" ]; then echo "${n_PRG}: ERROR: sql parameter not supplied"; return 20; fi
if [ ! -f ${n_SQL} ]; then echo "${n_PRG}: ERROR: ${n_SQL} does not exist or is not readable"; return 30; fi

#-- Determine the method of running the SQL
if   [ -x ${ORACLE_HOME}/bin/svrmgrl ]; then
  n_RUNSQLCMD="${ORACLE_HOME}/bin/svrmgrl command=@${n_TMP}.sql"
  n_CONNECTCMD="connect internal"

elif [ -x ${ORACLE_HOME}/bin/sqlplus ]; then
  n_RUNSQLCMD="${ORACLE_HOME}/bin/sqlplus /nolog @${n_TMP}.sql"
  n_CONNECTCMD="connect / as sysdba"

else
  echo "${n_PRG}: ERROR: Cannot find svrmgrl or sqlplus"
  return 40
fi

#-- Add exit and connect string to the SQL
(
echo ${n_CONNECTCMD}
cat ${n_SQL}
echo exit
) > ${n_TMP}.sql

#-- Execute the SQL
${n_RUNSQLCMD}

#-- Tidy up
if [ ! -s "${n_TMP}" ]; then \rm ${n_TMP}.* 2>/dev/null; fi
}

#=====================================================================
# Function p - all variables to be prefixed with p_ 
sdba_time_diff()       
#=====================================================================
{
[ ${DEBUGMODE:=False} = True ] && set -xv

if [ $# -eq 1 ]; then if [ "${1}" = "help" ]; then cat <<END
#--------------------------------------------------------------------
# Function    : sdba_time_diff
# Summary     : Calculate time difference
# Parameters  : \$1=<start  time (HH:MM:SS)>
#             : \$2=<finish time (HH:MM:SS)>
#--------------------------------------------------------------------
END
return 0
fi; fi

#-- Get command line parameters
p_ARG1=$1
p_ARG2=$2

#-- Check format of the command line parameters
for p_PARAM in ${p_ARG1} ${p_ARG2} 
do
  if [ `echo ${p_PARAM} |grep -c "^[0-9][0-9]*:[0-5][0-9]:[0-5][0-9]$"` -eq 0 ]; then
    echo "${p_PARAM} is not valid time (HH:MM:SS)"
    return 1
  fi
done

#-- Parse hours, minutes and seconds from command line parameters
p_HH_A=`echo "${p_ARG1}" | awk -F":" '{print $1}'`
p_MM_A=`echo "${p_ARG1}" | awk -F":" '{print $2}'`
p_SS_A=`echo "${p_ARG1}" | awk -F":" '{print $3}'`
p_HH_B=`echo "${p_ARG2}" | awk -F":" '{print $1}'`
p_MM_B=`echo "${p_ARG2}" | awk -F":" '{print $2}'`
p_SS_B=`echo "${p_ARG2}" | awk -F":" '{print $3}'`

#-- Determine which time is greater and set intermediate parameters accordingly
if [ ${p_HH_A}${p_MM_A}${p_SS_A} -le ${p_HH_B}${p_MM_B}${p_SS_B} ]; then
  p_SIGN="+" 
  p_HH1=${p_HH_A}
  p_MM1=${p_MM_A}
  p_SS1=${p_SS_A}
  p_HH2=${p_HH_B}
  p_MM2=${p_MM_B}
  p_SS2=${p_SS_B}
else
  p_SIGN="-"
  p_HH1=${p_HH_B}
  p_MM1=${p_MM_B}
  p_SS1=${p_SS_B}
  p_HH2=${p_HH_A}
  p_MM2=${p_MM_A}
  p_SS2=${p_SS_A}
fi

#-- Process seconds
p_SS3=`expr ${p_SS2} - ${p_SS1}`
if [ ${p_SS3} -lt 0 ]; then
  p_SS3=`expr ${p_SS3} + 60`
  p_MM1=`expr ${p_MM1} + 1`
fi

#-- Process minutes
p_MM3=`expr ${p_MM2} - ${p_MM1}`
if [ ${p_MM3} -lt 0 ]; then
  p_MM3=`expr ${p_MM3} + 60` 
  p_HH1=`expr ${p_HH1} + 1`
fi

#-- Process hours
p_HH3=`expr ${p_HH2} - ${p_HH1}`

#-- Get time in HH:MM:SS
p_HHMMSS=`
(
for p_PARAM in ${p_HH3} ${p_MM3} ${p_SS3}
do
  if [ ${p_PARAM} -lt 10 ]; then
    echo "0${p_PARAM}:\c"
  else
    echo "${p_PARAM}:\c"
  fi
done
echo 
) |sed -e 's/:$//'
`
#-- Get time in seconds
p_SECS=`expr ${p_HH3} \* 3600 + ${p_MM3} \* 60 + ${p_SS3}`

#-- Print output
echo "${p_SIGN} ${p_HHMMSS}  [ ${p_SECS} secs]"
}

function dbs_rm {
#--------------------------------------------------------------------
# Function    : dbs_rm
# Summary     : To "safe delete" files or directories or a list of files or 
#                  directories particularly when deleting large number of 
#                  files and directories using wild cards.
# Parameters  : \$1=<file name>|<directory name> [<file name>|<directory name>]
#--------------------------------------------------------------------
 
#  Begin dbs_rm function
#

#  Process parameter(s)
#
if (( ! $# )); then

   #  No filename parameter specified.
   #
   echo "\nYou didn't specify which file(s) to delete"
   return 1 

else

   #  Assign parameter variable.
   #
   v_parms="$@"

   # Count number of files to be deleted
   #
   echo "\n Counting files....\c"

   ((v_file_num=$(find ${v_parms} \( ! -type d \) -prune -local 2>/dev/null | wc -l)))

   ((v_find_rc=$?))

   if (( ${v_find_rc} > 1 )); then

      echo "\nError counting files."

      return ${v_find_rc}
 
   fi

   echo "\n Counting directories...\c"

   ((v_dir_num=$(find ${v_parms} -type d -prune -local 2>/dev/null | wc -l)))

   ((v_find_rc=$?))

   if (( ${v_find_rc} > 1 )); then

      echo "\nError counting directories."

      return ${v_find_rc}
 
   fi

   ((v_total_num=${v_dir_num} + ${v_file_num}))

   echo "\n Counting Complete.\n"

fi

#  Check if there are files that match parameter(s)
#
if (( ${v_total_num} == 0 )); then

   echo "\nNo files matched your criteria: ${v_parms}"

   return 2

# If we're deleting less than 10 files/directories, confirm for each file.
#
elif (( ${v_total_num} < 10 )); then

   echo "\n  Deleting less than 10 files/directories."

   #  Delete files
   #
   if (( ${v_file_num} > 0 )); then

      echo "\n  File delete: "

      echo "\n  Confirm for each one."

      find ${v_parms} \( ! -type d \) -local -exec \rm -i {} \; 

      ((v_find_rc=$?))

      if (( ${v_find_rc} > 1 )); then

         echo "\nError removing files."

         return ${v_find_rc}
 
      fi

   fi

   #  Delete directories
   #
   if (( ${v_dir_num} > 0 )); then

      echo "\n  Directory delete: \n"

      find ${v_parms} -type d -local -exec \rmdir -ps {} \; 

      ((v_find_rc=$?))

      if (( ${v_find_rc} > 1 )); then

         echo "\nError removing directories."

         return ${v_find_rc}
 
      fi

   fi

# If we're deleting 10+ files/directories, offer to list them all before deleting.
#
else

   echo "\n  You are attempting to delete  ${v_total_num}  files/directories."

   echo "\n  Enter \"y|Y\" to see list and continue ==> \c."

   read v_answer

   if [[ ${v_answer} != [yY]* ]]; then

      echo "\nNo files deleted.\n"

      return 3

   fi

   echo "\n Press spacebar to view list 1 screen at a time."

   echo "\n Type \"q\" or \"Q\" to interrupt listing, but continue with file removal process."

   echo "\n Press Enter to begin listing...\c"

   read 

   echo "\n"

   find ${v_parms} -local 2>/dev/null |more -e

   ((v_find_rc=$?))

   if (( ${v_find_rc} > 1 )); then

      echo "\nError listing files and directories."

      return ${v_find_rc}
 
   fi

   echo "\n  Enter \"y|Y\" to Remove files/directories ===> \c."

   read v_answer

   if [[ ${v_answer} != [yY]* ]]; then

      echo  "\nNo files deleted.\n"

      return 5

   else 

      #  Change ownership in order to make it easier to delete.
      #
      \chmod -R a+w ${v_parms} > /dev/null  2>&1
   
      #  Delete files
      #
      if (( ${v_file_num} > 0 )); then
   
         echo "\n Deleting files... "  
   
         find ${v_parms} \( ! -type d \) -local -prune -exec \rm {} \; 
   
         ((v_find_rc=$?))
   
         if (( ${v_find_rc} > 1 )); then

            echo "\nError deleting files."

            return ${v_find_rc}
 
         else
   
            echo " Files Deleted..."
    
         fi
   
      fi
   
      #  Delete directories
      #
      if (( ${v_dir_num} > 0 )); then
   
         echo "\n Deleting Directories... "  
   
         find ${v_parms} -type d -local -exec \rmdir -ps {} 2> /dev/null \; 
   
         ((v_find_rc=$?))
   
         if (( ${v_find_rc} > 1 )); then

            echo "\nError removing directories."

            return ${v_find_rc}
 
         else
   
            echo " Directories deleted... "  
   
         fi
   
      fi

   fi

fi

echo "\nCompeted removing $*\n"

return 0

}

function racenv {
#--------------------------------------------------------------------
# Function    : racenv
# Summary     : Sets the correct Oracle SID in the RAC environment.
# Parameters  : Optional
#             :   \$1=Database Name.
#             :   No parameter causes function to list Oracle SIDs 
#             :   from oratab and prompt for a valid Database Name.
# Return Code : 0  - If Oracle SID correctly set.  
#             : 1  - If executed in non-RAC environment, but passed a 
#             :      valid Oracle SID
#             : 4  - Invalid Database Name passes as parameter.
#             : $? - Return code from srvctl if return code is 
#                    non-zero. 
#--------------------------------------------------------------------

v_sid=$1

if [[ -z ${v_sid} ]]; then

   v_db_list=$(awk -F":" '/:N/ && !/#/ && !/^\$/ && !/\*/ {print $1}' $ORATAB)

   if [[ -z ${v_db_list} ]]; then
   
      echo "\nError: Unable to generate SID List.\n"

   fi

   echo "\n"

   for v_db in ${v_db_list}
   do
 
     echo "    $v_db"
   
   done

   echo "\n  Enter valid SID from above list ==> \c."

   read v_sid

fi

grep ${v_sid} $ORATAB  > /dev/null

if [[ $? != 0 ]]; then

   echo "\nError: Invalid SID for this server: ${v_sid}\n"

   ((v_rc=4))

else

   export ORAENV_ASK=NO

   ORACLE_SID=${v_sid}

    . oraenv

    export ORAENV_ASK=YES

   # Determine if RAC or standalone server, for RAC set ORACLE_SID to the Instance Name
   #
   if [[ -d /oracle/srvm || -d /oracle/srvm_vol ]]; then

      v_srvctl_line=$(srvctl config database -d ${v_sid})

      if (( $? )); then

         ((v_rc=$?))

         echo "\n Non-zero Return Code from srvctl."
      
      else

         export ORACLE_SID=$(echo ${v_srvctl_line} | awk '/'"$(hostname)"'/{print $2}')

         ((v_rc=0))

      fi

   else

      echo "\n Non RAC environment."

      ((v_rc=1))

   fi

   echo "\n ORACLE_SID = ${ORACLE_SID}\n"


fi

return ${v_rc}

}

#####################################################################
