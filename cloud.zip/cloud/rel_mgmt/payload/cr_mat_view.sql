drop MATERIALIZED VIEW AHS_SDBA.LAST_GOOD_BACKUP_ALL
/
CREATE MATERIALIZED VIEW AHS_SDBA.LAST_GOOD_BACKUP_ALL
PCTFREE 10
PCTUSED 40
INITRANS 1
MAXTRANS 255
STORAGE(INITIAL 104K)
TABLESPACE AHS_SDBA_DATA
NOLOGGING
BUILD IMMEDIATE
REFRESH FORCE
ON DEMAND
with rowid
AS 
select
  backup_HOST
, backup_SID        
, DB_COMP_INV_ID        
, NETBACKUP_MASTER
, BACKUP_SCHEDULE
, BACKUP_DOW
, backup_version
, other_info
, P405_REPORT
, max(nvl(last_good_backup,to_date('08/03/1968','MM/DD/YYYY'))) last_good_backup
, max(last_attempted_backup) last_attempted_backup
, max(last_good_backup_pass) last_good_backup_pass
from
(select
res_f.*
, 
case
when backup_version like 'LEGACY%' then
'LEGACY_BACKUP'
else
'BACKUP_HIST'
end P405_REPORT
from
(
select 
  bh.backup_HOST
, bh.backup_SID        
, bh.DB_COMP_INV_ID        
, bh.NETBACKUP_MASTER
, bh.BACKUP_SCHEDULE
, bh.BACKUP_DOW
, last_good.backup_date last_good_backup
, greatest(bh.LAST_BACKUP_RUN,last_good.backup_date) last_attempted_backup
,bh.backup_type||'- '||nvl(bl.BACKUP_VERSION,'LEGACY') backup_version
, last_good.backup_date last_good_backup_pass
, case
 when rm.HOSTNAME is not null then
  'RM Deployed'
 else
  null
 end other_info
from
 database_backup_schedule bh
,backup_list bl
,(select 
 sid,
 max(backup_date) backup_date
from backup_history bh
where 
 backup_status='SUCCESS'
and sid like '%'
and BACKUP_TYPE in ('OFFLINE','OFFLINE_DOWN','ONLINE','RESTART_ONLINE')
 group by sid
 )last_good
,gw_database g
,rm_active rm
Where
bh.backup_host like '%'
and bh.db_comp_inv_id = g.comp_inv_id
and g.ENVIRONMENT_STATUS like '%'
and bh.backup_sid like '%'
and backup_type = 'RMAN'
and bh.backup_sid = last_good.sid(+)
and bh.backup_sid = bl.sid(+)
and bh.backup_host = rm.hostname(+)
and not exists ( select 1 
from backup_exclude bex 
where  bh.host like bex.host
and  bh.sid like bex.sid 
and ('LGB' like bex.REPORT_NAME
)
 )
union all
select 
  nvl(bh.backup_HOST,nvl(substr(last_good.BACKUP_HOST,1,instr(last_good.BACKUP_HOST,'.') - 1  ),g.related_server)) backup_HOST
, bh.backup_SID        
, bh.DB_COMP_INV_ID        
, bh.NETBACKUP_MASTER
, bh.BACKUP_SCHEDULE
, bh.BACKUP_DOW
, last_good.BACKUP_DATE last_good_backup
, nvl(last_good.BACKUP_DATE,bh.LAST_BACKUP_RUN) last_attempted_backup
, nvl(last_good.BACKUP_TYPE,'LEGACY-COLD') BACKUP_VERSION
, last_good.BACKUP_DATE last_good_backup_pass
, case
 when rm.HOSTNAME is not null then
  'RM Deployed'
 else
  null
 end other_info
from
 database_backup_schedule bh
,
(
select
lg.DB_COMP_INV_ID
,lg.BACKUP_HOST
,lg.BACKUP_SID
,lg.BACKUP_DATE
,lg.BACKUP_TYPE
from
legacy_backup_history  lg
,(select
  db_comp_inv_id
  ,max(backup_date) backup_date
  from legacy_backup_history lg
   where lg.BACKUP_STATUS = 'SUCCESS'
  group by db_comp_inv_id
  )lgm
where
lg.db_comp_inv_id = lgm.db_comp_inv_id
and lg.BACKUP_DATE = lgm.BACKUP_DATE
)last_good
,ahs_database g
,rm_active rm
Where
 bh.db_comp_inv_id = g.db_comp_inv_id
and (bh.backup_type != 'RMAN' or bh.backup_type is null)
and bh.db_comp_inv_id = last_good.db_comp_inv_id(+)
and  bh.host = rm.HOSTNAME(+)
and not exists ( select 1 
from backup_exclude bex 
where  bh.host like bex.host
and  bh.sid like bex.sid 
and ('LGB' like bex.REPORT_NAME
)
 )
) res_f
where 
1 = 1
) res
group by
  backup_HOST
, backup_SID        
, DB_COMP_INV_ID        
, NETBACKUP_MASTER
, BACKUP_SCHEDULE
, BACKUP_DOW
, backup_version
, other_info
, P405_REPORT
/
