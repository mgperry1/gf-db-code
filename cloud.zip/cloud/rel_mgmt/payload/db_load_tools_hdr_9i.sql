PROMPT db_load_tools_hdr.sql
CREATE OR REPLACE PACKAGE DBA_ORA.db_load_tools AS
--**********************************************
--  COIS Application Schema Account Data Maintenance Tools
--**********************************************
  PROCEDURE ANALYZE_OBJECT_PRO (object_type_p IN CHAR,
                                object_owner_p IN VARCHAR2,
                                object_name_p IN VARCHAR2,
                                user_sql_p IN VARCHAR2 DEFAULT NULL,
                                chained_rows_table_p IN VARCHAR2 DEFAULT NULL,
                                chained_rows_owner_p IN VARCHAR2 DEFAULT NULL,
                                partition_type_p IN VARCHAR2 DEFAULT NULL,
                                paritition_name_p IN VARCHAR2 DEFAULT NULL);

  PROCEDURE COALESCE_TABLESPACE_PRO (ts_name_p IN VARCHAR2);

  PROCEDURE CREATE_INDEX_PRO (owner_p IN VARCHAR2,
                              index_name_p IN VARCHAR2,
                              recoverable_p IN BOOLEAN DEFAULT NULL,
                              sorted_p IN BOOLEAN DEFAULT FALSE,
                              parallel_degree_p IN INTEGER DEFAULT NULL,
                              parallel_instances_p IN INTEGER DEFAULT NULL);

  PROCEDURE DBMS_STATS_ANALYZE_PRO (analyze_type_p IN CHAR
                                   ,object_type_p IN CHAR
                                   ,owner_p IN VARCHAR2
                                   ,object_name_p IN VARCHAR2 DEFAULT NULL
                                   ,part_name_p IN VARCHAR2 DEFAULT NULL
                                   ,est_pct_p IN NUMBER DEFAULT NULL
                                   ,blk_samp_p IN BOOLEAN DEFAULT FALSE
                                   ,gran_p IN VARCHAR2 DEFAULT 'DEFAULT'
                                   ,cascade_p IN BOOLEAN DEFAULT FALSE
                                   ,no_invalid_p BOOLEAN DEFAULT FALSE);

  PROCEDURE DIS_ENABLE_ALL_FK_CONS_PRO (dis_enable_p IN CHAR,
                                        owner_p IN VARCHAR2,
                                        table_name_p IN VARCHAR2,
                                        exceptions_table_p IN VARCHAR2 DEFAULT NULL,
                                        exceptions_schema_p IN VARCHAR2 DEFAULT NULL);

  PROCEDURE DIS_ENABLE_CONS_TRIGS_PRO (dis_enable_p IN CHAR,
                                       cons_trigs_p IN CHAR,
                                       owner_p IN VARCHAR2,
                                       table_name_p IN VARCHAR2,
                                       constraint_name_p IN VARCHAR2 DEFAULT NULL,
                                       exceptions_table_p IN VARCHAR2 DEFAULT NULL,
                                       exceptions_schema_p IN VARCHAR2 DEFAULT NULL);

  PROCEDURE DROP_INDEX_PRO (owner_p IN VARCHAR2,
                            index_name_p IN VARCHAR2);

  PROCEDURE MOD_LIST_PART_PRO (modify_type_p IN CHAR
                              ,owner_p IN VARCHAR2
                              ,table_name_p IN VARCHAR2
                              ,part_name_p IN VARCHAR2
                              ,list_value_p IN VARCHAR2);

  PROCEDURE READWRITE_TABLESPACE_PRO (owner_p IN VARCHAR2);

  PROCEDURE REBUILD_INDEX_PRO (owner_p IN VARCHAR2
                              ,index_name_p IN VARCHAR2
                              ,partition_type_p IN VARCHAR2 DEFAULT NULL
                              ,paritition_name_p IN VARCHAR2 DEFAULT NULL);

  PROCEDURE REFRESH_MVIEW_PRO (owner_p IN VARCHAR2,
                               mview_name_p IN VARCHAR2,
                               refresh_method_p IN VARCHAR2 DEFAULT NULL,
                               rollback_seg_p IN VARCHAR2 DEFAULT NULL);

  PROCEDURE SET_UNUSABLE_INDEX_PRO (owner_p IN VARCHAR2
                                   ,index_name_p IN VARCHAR2
                                   ,partition_type_p IN VARCHAR2 DEFAULT NULL
                                   ,paritition_name_p IN VARCHAR2 DEFAULT NULL);

  PROCEDURE TRUNCATE_OBJECT_PRO (object_type_p IN CHAR,
                                 object_owner_p IN VARCHAR2,
                                 object_name_p IN VARCHAR2,
                                 drop_storage_p IN BOOLEAN DEFAULT TRUE);

  PROCEDURE TRUNCATE_PARTITION_PRO (partition_type_p IN VARCHAR2,
                                    object_owner_p IN VARCHAR2,
                                    object_name_p IN VARCHAR2,
                                    partition_name_p IN VARCHAR2,
                                    drop_storage_p IN BOOLEAN DEFAULT TRUE);
END;
/
