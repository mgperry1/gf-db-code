#!/bin/ksh

#=======================================================================#
# File: chg_dba_pwds_nohup.sh						#	
# Date: 10-Nov-2005							#	
# Auth: Neil A Stewart							#	
# Desc: Updates all Database Services DBA database account passwords	#
#	(sys, system, dba_ora, dba_oracle, csmig) for all DBSS managed	# 
#	databases. Run in nohup mode.					#	
# Revisions:								#	
# ------------------------------------------------------------------------------------------------------------- #
# Who           When            What										#	
# ------------------------------------------------------------------------------------------------------------- #
# Neil Stewart  10-Nov-2005     First draft of script adapted from /oracle/share/scripts/change_passwords/	#
#				retired/change_passwords_uk.ksh							#
# Neil Stewart	05-Dec-2005	Amended GenDBList() (sql select to generate chameleon.lst from Chameleon)  	#
# Neil Stewart	26-Jan-2006	Added 'account unlock' to the end of the alter_user.sql statement.		# 
# Neil Stewart	17-Feb-2006	Amended GenAlterUser() to differentiate between oracle v7 databases (as		# 
#				'account unlock' option not valid in v7).					#
# Neil Stewart	07-Mar-2006	Amended sql select in GenDBList() 						#
# Neil Stewart	22-May-2006	Amended sql select in GenDBList() (to restrict using new Chameleon db classes)	#
# Neil Stewart	07-Aug-2006	Amended sql select in GenDBList() (added "and l.relationship_type='Depends On'" #
# Neil Stewart	11-Dec-2006	Added CSMIG to GenAlterUser().							#
# Neil Stewart 	11-Dec-2006	removed oldstub() and newstub() functions and replaced with files to allow	# 
#				to be run on nohup.								#
# Neil Stewart	07-Feb-2007	Amended GenDBList() to select components with a 'Development' life_cycle_status	#
#===============================================================================================================#

#=======================================================================#
# Defined functions 
#=======================================================================#

SetEnvs()
{
export ORACLE_SID=uktst900;
export ORAENV_ASK=NO;
. oraenv 
export DIR=/oracle/share/nas/scripts/passwds
export LOG=${DIR}/logs/chg_dba_pwds_`date +%d%b%y`.log
}

GenDBList()
{
print "The following databases will be updated:" >> ${LOG}
sqlplus -s ahs_sdba/reporting@usprd316 <<EOF >> ${LOG} 2>&1
whenever sqlerror exit 0
set echo off feed off pages 900 head off serverout off term off verify off
set lines 200
col device_name format a30
col database_name format a20
col sid format a15
col database_version format a12
col database_class format a16
col life_cycle_status format a18
spool ${DIR}/Chameleon.list
select distinct h.device_name, d.database_name, substr(d.sid,0,8) SID, d.database_version, d.database_class, d.life_cycle_status
from ahs_sdba.gw_database d
    ,ahs_sdba.gw_related_component_list l
    ,ahs_sdba.gw_hardware h
where d.comp_inv_id = l.componenta
and l.componentb_type ='Hardware'
and l.componentb = h.comp_inv_id
and d.database_vendor = 'ORACLE'
and d.life_cycle_status in ('Production','Development')
and l.relationship_type='Depends On'
and d.country in ('GBR','ESP','USA')
and d.database_class in ('Primary','RAC Database','Failover Cluster')
and d.service_group_cost_center in (
        'SCS AH SDBA UK CORPORATE',
        'SCS AH SDBA UK GMS',
        'SCS AH SDBA RD',
        'SCS AH SDBA US CORPORATE',
        'SCS AH SDBA US GMS',
        'SCS AH SDBA PHARMA',
        'SCS AH DBS  DATABASE SERVICES',
        'SCS AH DBS DBSS',
        'SCS AH SDBA   SYSTEMS DATABASE ADMINISTRATION',
        'SCS AH SDBA GMS + CORPORATE'
        )
and h.device_name = 'UKWSV79'
order by 2,1
;
spool off
exit
EOF

cat ${DIR}/Chameleon.list | grep "[A-Z]" | cut -c1- > ${DIR}/chameleon.lst
/bin/rm ${DIR}/Chameleon.list
}

GenAlterUser()
{
sqlplus -s system/${OLDSTUB}${SID}@${DATABASE} <<EOF >> /dev/null 2>&1
whenever sqlerror exit 0
spool ${DIR}/${DATABASE}\-dba_users.lst
select lower(username) from dba_users where username in ('SYS','SYSTEM','DBA_ORA','DBA_ORACLE','CSMIG');
spool off
exit
EOF

if [ -f ${DIR}/${DATABASE}\-dba_users.lst ]
then 
awk '/sys/||/dba/ {print}' ${DIR}/${DATABASE}\-dba_users.lst |
 while read USERNAME
 do
  if [[ ${VERSION} = 7* ]]
  then
  print "alter user ${USERNAME} identified by ${NEWSTUB}${SID};" >> ${DIR}/${DATABASE}\-alter_user.sql
  elif [[ ${VERSION} != 7* ]]
  then
  print "alter user ${USERNAME} identified by ${NEWSTUB}${SID} account unlock;" >> ${DIR}/${DATABASE}\-alter_user.sql
  fi
 done
else
print "${DATABASE}-dba_users.lst is missing - cannot generate alter_user.sql, passwords not changed." >> ${LOG}
fi

if [ -f ${DIR}/${DATABASE}\-dba_users.lst ]
then
/bin/rm ${DIR}/${DATABASE}\-dba_users.lst
fi
}

UpdatePass()
{
if [ -f ${DIR}/${DATABASE}\-alter_user.sql ]
then
print "Updating passwords for ${DATABASE} (${VERSION})" 
sqlplus -s system/${OLDSTUB}${SID}@${DATABASE} <<EOF >> ${LOG} 2>&1
whenever sqlerror exit 0
@${DIR}/${DATABASE}\-alter_user.sql
exit
EOF
/bin/rm ${DIR}/${DATABASE}\-alter_user.sql
else
print "${DATABASE}-alter_user.sql not found: ${DATABASE} DBA account passwords not changed"
fi
}

#=======================================================================#
# Script Body 
#=======================================================================#

SetEnvs
print "Password change script started at "`date` >> ${LOG}

cat ${DIR}/.oldstub | read OLDSTUB
cat ${DIR}/.newstub | read NEWSTUB

print "Generating list of databases from DBS Portal" 
GenDBList

print "Updating the DBA account passwords in the following databases:"

cat ${DIR}/chameleon.lst | while read HOSTNAME DATABASE SID VERSION
do
GenAlterUser
UpdatePass
done

/bin/rm ${DIR}/chameleon.lst
print "Password change script ended at "`date` >> ${LOG}

#=======================================================================#
# END
#=======================================================================#
