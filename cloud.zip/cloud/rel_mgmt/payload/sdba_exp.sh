#!/bin/ksh
#
#  Name:    
#    sdba_exp.sh - Runs Oracle export utility.
#
#  Format:  
#    sdba_exp.sh [-i instance] [-f | -o owner] [-d directory] 
#                [-b directory] [-k number] [-s statistics type] 
#                [-r] [-c] [-p] [-g] [-t] [-x]
#
#  Purpose: 
#    Oracle export script wrapper.
#
#  Options:   
#    -i [Database SID]                   Required. (e.g. usprd100).
#    -f [] Export entire file (FULL).    EXP default=N.
#    -o [Owner]                          "-f" or "-o" option required.
#    -d [Export file directory]          Optional. Default: 
#                                "/oracle/exports/oradata/${instance}".
#    -g [] grants=N.                     EXP default=Y. Optional.
#    -p [] compress=N.                   EXP default=Y. Optional.
#    -n [] constraints=N                 EXP default=Y. Optional.
#    -c [] consistent=Y.                 EXP default=N. Optional.
#    -r [] rows=N.                       EXP default=Y. Optional.
#    -t [] triggers=N.                   EXP default=Y. Optional.
#    -x [] indexes=N.                    EXP default=Y. Optional.
#    -s [COMPUTE|NONE] statistics.       EXP default=ESTIMATE. Optional.
#    -k [Number of days to retain exports and logs in export]
#       Value range 0 - 14.                             Optional.
#    -b [Location for backup copy of export]            Optional.
#
#     All exports "direct=Y".
#
#  Display abort message on interrupt.
#
trap 'echo "^G^G sdba_exp.sh Aborted!"; exit' 1 2 3 15

ARGS=false             # Option variable.
bk_copy_dir=""         # Location where export is copied for back up.
compress="Y"           # Exp Compress variable.
comp_pgm=""            # UNIX Compression program used, either gzip or compress.
comp_suffix=""         # Value is based on compression program used.
consistent="N"         # Exp Consistent variable.
constraints="Y"        # Exp Constraints variable.
e_msg=""               # Error message.
exp_date=`date +%Y%m%d%H%M`
                       # Export Start Time.
exp_dir=""             # Directory location for exports.
exp_file=""            # Fully qualified export name.
exp_log=""             # Fully qualified export log name.
exp_name=""            # Base export name.
export_type=""         # Export Type.
grants="Y"             # Exp Grants variable
indexes="y"            # Exp Index variable
instance=""            # Instance name.
keep=""                # Number of days exports and logs are retained.  
local_mc=`hostname`    # Local machine name.
owner=""               # Schema owner to be exported.
os_type=`uname -s`     # Get operating system type.
pipe=""                # pipe name.
rows="Y"               # Exp Rows variable.
statistics="ESTIMATE"  # Exp Statistics variable.
triggers="Y"           # Exp Triggers variable.

# Function error_out
#  This functions handles detected errors based on exit code parameter 
#  and then exits. 
#
function error_out {

  exit_code=$1

  case ${exit_code} in

#      Command line error, don't submit ESM alert, just output error message.
#
       4)
         echo "${e_msg} \n"
         ;;

#      Export utility error, submit ESM Alert.
#
       8)
         ~dba_ora/scripts/bin/esm_submit -c "Yellow" -n "${instance}_${local_mc}" -s "Export Error on ${instance}_${local_mc}" -l "${e_msg}" -d "${exp_date}" -p "03PTLA0099"
         ;;

  esac

exit ${exit_code}

}

# Process command line options 
#
while getopts ":i:d:b:k:o:s:frcpgntx" ARGS; do

  case ${ARGS} in
       i)
         instance=${OPTARG}

#        Check to see if instance is in the oratab file.
#
         if [[ -r /etc/oratab ]]; then
            grep ${instance} /etc/oratab > /dev/null
         elif [[ -r /var/opt/oracle/oratab ]]; then
            grep ${instance} /var/opt/oracle/oratab > /dev/null
         else 
            e_msg="Error -i: Oracle oratab file missing.\n"
            error_out 4
         fi

         if [[ $? != 0 ]]; then
            e_msg="Error -i: Invalid instance name for this server: ${instance}\n"
            error_out 4
         fi
         ;;

       f)
         if [[ ${export_type} = "owner" ]]; then
            e_msg="Error: Cannot specify both owner (-o) and full (-f) export. Exiting.\n"
            error_out 4
         else
            export_type=full
         fi
         ;;

       o)
         if [[ ${export_type} = "full" ]]; then
            e_msg="Error: Cannot specify both owner (-o) and full (-f) export. Exiting.\n"
            error_out 4
         else
            export_type=owner
            owner=${OPTARG}
         fi
         ;;

       d)
         exp_dir=${OPTARG}
         if [[ ! -d ${exp_dir} || ! -x ${exp_dir} ]]; then
            e_msg="Error -d: Invalid or no execute permission on export directory: ${exp_dir}\n"
            error_out 4
         fi
         ;;

       b)
         bk_copy_dir=${OPTARG}
         if [[ ! -d ${bk_copy_dir} || ! -x ${bk_copy_dir} ]]; then
            e_msg="Error -c: Invalid or no execute permission on export backup directory: ${bk_copy_dir}\n"
            error_out 4
         fi
         ;;

       k)
         if [[ ${OPTARG} -lt 0 || ${OPTARG} -gt 14 ]]; then
            e_msg="Error -r: Retention time for keeping exports must be a number >= 0 and <=14. ${OPTARG} \n"
            error_out 4
         else
            keep=${OPTARG}
         fi
         ;;

       s)
         case ${OPTARG} in

              "NONE"|"none")
                statistics=${OPTARG}
                ;;

              "COMPUTE"|"compute")
                statistics=${OPTARG}
                ;;
          
              *)
                e_msg="Error -s: Statitics must be either NONE or COMPUTE. ${OPTARG} \n"
                error_out 4
         esac
         ;;

       r)
         rows="N"
         ;;

       c)
         consistent="Y"
         ;;

       n)
         constraints="N"
         ;;

       p)
         compress="N"
         ;;

       g)
         grants="N"
         ;;

       t)
         triggers="N"
         ;;

       x)
         indexes="N"
         ;;

       *)
         e_msg="Usage: ${0}: -i instance name [-f | -o owner] -d directory [-b directory] [-k number] [-s NONE|COMPUTE] [-r] [-c] [-p] [-g] [-t] [-x]\n"
         error_out 4
         ;;

  esac

done

# Set the UNIX PATH 
#
 PATH=~dba_ora/scripts/bin:~dba_ora/bin:/usr/local/bin:/usr/contrib/bin:$PATH 
 export PATH

#  Check that required parameters are set.
#
if [[ -z "${instance}" ]]; then
   e_msg="Error -i: Instance needs to be specified for export. Exiting.\n"
   error_out 4
elif [[ -z "${export_type}" ]]; then
   e_msg="Error: Export type, -f or -o, needs to be specified for export. Exiting.\n"
   error_out 4
else

   if [[ -z "${exp_dir}" ]]; then
      exp_dir="/oracle/exports/oradata/${instance}"
   else

#     Set to default value.
#
      exp_dir="${exp_dir}/${instance}"
   fi

   if [[ ! -d ${exp_dir} || ! -x ${exp_dir} ]]; then
      e_msg="Error -d: Invalid or no execute permission on export directory: ${exp_dir}\n"
      error_out 4

   fi

fi

if [[ ! -z "${owner}" ]]; then

   if [[ ${owner} = -* ]]; then
      e_msg="Error -o: Invalid owner name: ${owner}\n"
      error_out 4
   fi

fi

#  If export back up directory is specified, set the directory to standard.
#    If the directory is invalid, that will be caught during the copy command.
#
 if [[ ! -z "${bk_copy_dir}" ]]; then

    bk_copy_dir="${bk_copy_dir}/${local_mc}/${instance}"
 fi

#  Set compression program to be used.
#   If gzip is available then use gzip, else use compress.
#
 gzip -h  1> /dev/null 2> /dev/null

 if [[ $? = 0 ]]; then

    comp_pgm=`which gzip`
    comp_suffix="gz"

 else

    comp_pgm=`which compress`
    comp_suffix="Z"

 fi

#  If retention parameter is set, then delete old exports, old logs, and if
#    "-b " option specified, old backup exports.
#
 if [[ ! -z "${keep}" ]]; then

    ls -t ${exp_dir}/*.Z ${exp_dir}/*.gz 2> /dev/null | awk 'NR>='"${keep}"'' |xargs rm  2> /dev/null
    ls -t ${exp_dir}/*.log | awk 'NR>='"${keep}"'' |xargs rm  2> /dev/null

    if [[ ! -z "${bk_copy_dir}" ]]; then

       ls -t ${bk_copy_dir}/*.Z ${bk_copy_dir}/*.gz 2> /dev/null | awk 'NR>='"${keep}"'' |xargs rm  2> /dev/null

    fi

 fi

# Set up Oracle environment
#
 ORAENV_ASK=NO; export ORAENV_ASK
 ORACLE_SID=${instance}; export ORACLE_SID

 . oraenv

 ORAENV_ASK=YES; export ORAENV_ASK

 PATH=$PATH:$ORACLE_HOME/bin 
 export PATH

# Get and Set NLS_LANG and database software version.
#
nls_parms=`$ORACLE_HOME/bin/sqlplus -s / 2> /dev/null<<EOF
SET pages 0
SET heading off
SET feedback off
SET echo off
SELECT a.value    || '_' || b.value || '.' || c.value || ',' || d.value
  FROM nls_database_parameters a
      ,nls_database_parameters b
      ,nls_database_parameters c
      ,nls_database_parameters d
 WHERE a.parameter = 'NLS_LANGUAGE'
   AND b.parameter = 'NLS_TERRITORY'
   AND c.parameter = 'NLS_CHARACTERSET'
   AND d.parameter = 'NLS_RDBMS_VERSION';
EXIT
EOF`

NLS_LANG=`echo ${nls_parms} | cut -f 1 -d ,`
export NLS_LANG

oracle_version=`echo ${nls_parms} | cut -f 2 -d , | tr -d '.'`

# Set set export file and export log names.
#
 if [[ ${export_type} = "owner" ]]; then
    exp_name=${instance}_${owner}
 else
    exp_name=${instance}_${export_type}
 fi

 if [[ ${rows} = "N" ]]; then
    exp_name=${exp_name}_norows_${exp_date}
 else
    exp_name=${exp_name}_${exp_date}
 fi

 exp_log=${exp_dir}/${exp_name}.log
 exp_file=${exp_dir}/${exp_name}.exp.${comp_suffix}

#  Create pipe if it doesn't already exist
#
 pipe=/tmp/${instance}_exp_pipe_${exp_date}

 if [[ ! -p ${pipe} ]]; then
    /etc/mknod ${pipe} p 
 fi

#  Pipe export file to compress command and take a quick nap.
#
 ${comp_pgm} -c <${pipe} > ${exp_file} &
 sleep 5

#  Run export utility.
#
 case ${export_type} in

      full)

        if [[ ${oracle_version} < '81000' ]]; then

           exp / file=${pipe} log=${exp_log} full=y direct=n rows=${rows} consistent=${consistent} indexes=${indexes} compress=${compress} grants=${grants} constraints=${constraints} statistics=${statistics}

        else

           exp / file=${pipe} log=${exp_log} full=y direct=n rows=${rows} consistent=${consistent} indexes=${indexes} compress=${compress} grants=${grants} constraints=${constraints} triggers=${triggers} statistics=${statistics}

        fi
        ;;
    
      owner)

        if [[ ${oracle_version} < '8.1.0.0.0' ]]; then

           exp / file=${pipe} log=${exp_log} owner=${owner} direct=n rows=${rows} consistent=${consistent} indexes=${indexes} compress=${compress} grants=${grants} constraints=${constraints} statistics=${statistics}

        else

           exp / file=${pipe} log=${exp_log} owner=${owner} direct=n rows=${rows} consistent=${consistent} indexes=${indexes} compress=${compress} grants=${grants} constraints=${constraints} triggers=${triggers} statistics=${statistics}

        fi
        ;;
    
 esac

exit

# Check return code for export utility.  
#
 if [[ $? != 0 ]]; then
    e_msg="Error executing export.\n"
    error_out  8
 fi

# See if there were errors in the export log
#
grep 'without warnings' ${exp_log} 1> /dev/null 2> /dev/null

if [[ $? != 0 ]]; then

   exp_error=`awk '!/EXP-00068/ && !/EXP-00067/ && \
                   !/ORA-00376/ && !/ORA-01110/ && \
                   !/EXP-00056: ORACLE error 376 encountered/ && \
                   (/EXP-/ || /ORA-/) {k++} \
                   END {printf "%d\n", k}' ${exp_log}`

   if [[ $exp_error != 0 ]]; then
   
      e_msg="Error in Export Log for ${instance}.\n"
      error_out  8

   fi

fi

# If -b parameter was specified, copy export file to directory.
#
if [[ ! -z "${bk_copy_dir}" ]]; then
   cp ${exp_file} ${bk_copy_dir}/${exp_name}.exp.${comp_suffix}

   if [[ $? != 0 ]]; then
      e_msg="Error copying export file to backup directory.\n"
      error_out  8
   fi
fi

#  Delete pipe after finished
#
 rm ${pipe} 

 if [[ $? != 0 ]]; then
    e_msg="Error deleting pipe: ${pipe} \n"
    error_out  8
 fi

#  No errors, exit.
#
exit 0
