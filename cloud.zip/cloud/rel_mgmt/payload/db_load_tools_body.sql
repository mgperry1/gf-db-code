CREATE OR REPLACE PACKAGE BODY DBA_ORA.db_load_tools AS
--**********************************************
--  COIS Application Schema Account Data Maintenance Tools
--
--  V1.1 - My first version after receiving from Ian.  Renamed and commented stuff.
--  V1.2 - Added ability to coalesce  a "merged" function to
--         enable/disable constraints/triggers
--  V1.3 - Added ability to truncate a partition or subpartition of a table and
--          analyze a partition or subpartition of a table.
--  V1.4 - Added ability to drop and recreate a partitioned index.
--         Added ability to change tablespaces for a user to read-write mode.
--  V1.5 - Altered readwrite_tablespace_pro to accept either upper or lower case
--         schema names.
--         Added ability to refresh materialized view.
--  V1.6 - Changed cursor so that DDL for bitmap indexes could be captured.
--  V1.7 - Modified code the determines which index enforces which constraint.
--              Roy Jones
--  V9.0.1 - Modified version number for new 9i features that will be added
--             -DBMS_STATS package usage
--              Roy Jones
--  V9.0.2 - Modified version number for new 9i features that will be added
--           Features that will be added
--             -Set Index Unusable
--             -Rebuild Index
--              Coded by Ted Trocky
--  V9.0.3 - Modified version number for new 9i features that will be added
--           Features that will be added
--             -Add/Drop partition values
--             -Rebuild unusable indexes (maybe local partitioned only)
--              Roy Jones
--  V9.0.4 - Closed hole in DROP_INDEX_PRO / CREATE_INDEX_PRO for parallel parameters
--           Removed unneeded package specs
--              Roy Jones
--  V9.0.5 - Fixed missing IF for gran_p parameter in DBMS_STATS proc
--              Roy Jones
--  V9.0.7 - Modified REBUILD_INDEX_PRO and SET_UNUSABLE_INDEX_PRO for partitioning
--           Modified REBUILD_INDEX_PRO for domain indexes
--              Roy Jones
--  V9.0.8 - Added Spec back for READWRITE_TABLESPACE_PRO
--              Roy Jones
--  V9.0.9 - Corrected Storage clause creation for NULL parameter values.
--  V10.0.2 - Added DEGREE option to gather optimizer statistics parallel
--              Prashant Khandke
--  V10.0.3 - Added OPTIONS option DBMS_STATS_ANALYZE_PRO procedure
--              Prashant Khandke
--  Last modified: Apr, 2009
--**********************************************
global_mod_v  CHAR := ' ';
TYPE build_index_rec_type IS RECORD
    (owner       DBA_INDEXES.OWNER%TYPE,
     index_name  DBA_INDEXES.INDEX_NAME%TYPE,
     block       INTEGER,
     ord         INTEGER,
     block_name  VARCHAR2(100),
     text        VARCHAR2(1000));
TYPE build_index_part_rec_type IS RECORD
    (owner       DBA_INDEXES.OWNER%TYPE,
     index_name  DBA_INDEXES.INDEX_NAME%TYPE,
     block       INTEGER,
     ord         INTEGER,
     subord      INTEGER,
     block_name  VARCHAR2(100),
     text        VARCHAR2(1000));
CURSOR build_index_cur (owner_p VARCHAR2, index_name_p VARCHAR2)
RETURN build_index_rec_type IS
   SELECT OWNER, INDEX_NAME, 1 "BLOCK", 1 "ORD", 'CREATE' "BLOCK_NAME",
          'CREATE ' || DECODE(INDEX_TYPE,'BITMAP','BITMAP') ||
              DECODE(UNIQUENESS, 'NONUNIQUE', NULL, UNIQUENESS) || ' INDEX ' ||
               OWNER || '.' || INDEX_NAME || CHR(10) ||
          ' ON ' || TABLE_OWNER || '.' ||TABLE_NAME "TEXT"
   FROM DBA_INDEXES
   WHERE OWNER = UPPER(owner_p)
         AND INDEX_NAME = UPPER(index_name_p)
   UNION
   SELECT INDEX_OWNER, INDEX_NAME, 2, COLUMN_POSITION, 'COLUMNS',
          DECODE(COLUMN_POSITION, 1, '(', ',') || COLUMN_NAME
   FROM DBA_IND_COLUMNS
   WHERE INDEX_OWNER = UPPER(owner_p)
         AND INDEX_NAME = UPPER(index_name_p)
   UNION
   SELECT OWNER, INDEX_NAME, 3, 1, 'COLUMNS END', ' ) ' || CHR(10)
   FROM DBA_INDEXES
   WHERE OWNER = UPPER(owner_p)
         AND INDEX_NAME = UPPER(index_name_p)
   UNION
   SELECT OWNER, INDEX_NAME, 4, 1, 'PARAMS', CHR(10) || ' INITRANS ' || INI_TRANS || CHR(10) ||
          ' MAXTRANS ' || MAX_TRANS || CHR(10) || ' TABLESPACE ' || TABLESPACE_NAME ||
          CHR(10) || ' PCTFREE ' || PCT_FREE
   FROM DBA_INDEXES
   WHERE OWNER = UPPER(owner_p)
         AND INDEX_NAME = UPPER(index_name_p)
   UNION
   SELECT OWNER, INDEX_NAME, 5, 1, 'STORAGE', DECODE(next_extent, NULL, NULL,
                                             ' STORAGE (' ||  CHR(10) ||
                                                        ' INITIAL ' || INITIAL_EXTENT || CHR(10) ||
                                                        ' NEXT ' || NEXT_EXTENT || CHR(10) ||
                                                        ' MINEXTENTS ' || MIN_EXTENTS || CHR(10) ||
                                                        ' MAXEXTENTS ' || MAX_EXTENTS || CHR(10) ||
                                                        ' PCTINCREASE ' || PCT_INCREASE || CHR(10) ||
                                                        DECODE(FREELISTS, NULL, NULL,
                                                              ' FREELISTS ' ||FREELISTS) || CHR(10) || ')')
   FROM DBA_INDEXES
   WHERE OWNER = UPPER(owner_p)
         AND INDEX_NAME = UPPER(index_name_p)
   ORDER BY 1,2;
CURSOR build_index_part_cur (owner_p VARCHAR2, index_name_p VARCHAR2) RETURN build_index_part_rec_type IS
SELECT OWNER, INDEX_NAME, 1 "BLOCK", 1 "ORD", 1 "SUBORD", 'CREATE' "BLOCK_NAME",
          'CREATE ' || DECODE(INDEX_TYPE,'BITMAP','BITMAP') ||
                 DECODE(UNIQUENESS, 'NONUNIQUE', NULL, UNIQUENESS) || ' INDEX ' ||
                 OWNER || '.' || INDEX_NAME || CHR(10) ||
          ' ON ' || TABLE_OWNER || '.' || TABLE_NAME "TEXT"
   FROM DBA_INDEXES
   WHERE OWNER = UPPER(owner_p)
         AND INDEX_NAME = UPPER(index_name_p)
  UNION
   SELECT INDEX_OWNER, INDEX_NAME, 2, 1, COLUMN_POSITION, 'COLUMNS',
          DECODE(COLUMN_POSITION, 1, '(', ',') || COLUMN_NAME
   FROM DBA_IND_COLUMNS
   WHERE INDEX_OWNER = UPPER(owner_p)
         AND INDEX_NAME = UPPER(index_name_p)
   UNION
   SELECT OWNER, INDEX_NAME, 3, 1, 1, 'COLUMNS END', ' ) ' || CHR(10)
   FROM DBA_INDEXES
   WHERE OWNER = UPPER(owner_p)
         AND INDEX_NAME = UPPER(index_name_p)
   UNION
   SELECT OWNER, INDEX_NAME, 4, 1, 1, 'LOCAL', 'LOCAL ('
   FROM DBA_INDEXES
   WHERE OWNER = UPPER (owner_p)
        and INDEX_NAME = UPPER (index_name_p)
   UNION
   SELECT INDEX_OWNER, INDEX_NAME, 5, PARTITION_POSITION, 1, 'PARTITION',
            DECODE (PARTITION_POSITION, 1, 'PARTITION ', ',PARTITION ') || PARTITION_name
      FROM DBA_IND_PARTITIONS
   WHERE INDEX_OWNER = UPPER (owner_p)
        and INDEX_NAME = UPPER (index_name_p)
   UNION
   SELECT INDEX_OWNER, INDEX_NAME, 5, PARTITION_POSITION, 2, 'PARAMS', ' INITRANS ' || INI_TRANS || CHR(10) ||
          ' MAXTRANS ' || MAX_TRANS || CHR(10) || ' TABLESPACE ' || TABLESPACE_NAME ||
          CHR(10) || ' PCTFREE ' || PCT_FREE
     FROM DBA_IND_PARTITIONS
   WHERE INDEX_OWNER = UPPER (owner_p)
        and INDEX_NAME = UPPER (index_name_p)
   UNION
   SELECT INDEX_OWNER, INDEX_NAME, 5, PARTITION_POSITION, 3, 'STORAGE', DECODE(next_extent, NULL, NULL,
   										' STORAGE (' ||  CHR(10) ||
          								' INITIAL ' || INITIAL_EXTENT || CHR(10) ||
          								' NEXT ' || NEXT_EXTENT || CHR(10) ||
          								' MINEXTENTS ' || MIN_EXTENT || CHR(10) ||
          								' MAXEXTENTS ' || MAX_EXTENT ||
          								CHR(10) || ' PCTINCREASE ' || PCT_INCREASE || CHR(10) ||
								          DECODE(FREELISTS, NULL, NULL, ' FREELISTS ' ||FREELISTS )|| CHR(10) || ')')
     FROM DBA_IND_PARTITIONS
   WHERE INDEX_OWNER = UPPER (owner_p)
        and INDEX_NAME = UPPER (index_name_p)
        and INDEX_NAME = INDEX_NAME
   UNION
   SELECT OWNER, INDEX_NAME, 6, 1, 1, 'LOCAL END', ')'
   FROM DBA_INDEXES
   WHERE OWNER = UPPER (owner_p)
        and INDEX_NAME = UPPER (index_name_p)
   ORDER BY 1,2;
TYPE error_msgs_tab_type IS TABLE OF VARCHAR2(2000) INDEX BY BINARY_INTEGER;
error_msgs_tab           error_msgs_tab_type;
gmp_version_c            CONSTANT VARCHAR2(8) := '9.0.8';
no_error_c               CONSTANT INTEGER := -20000;
no_privs_c               CONSTANT INTEGER := -20001;
invalid_option_c         CONSTANT INTEGER := -20002;
index_not_defined_c      CONSTANT INTEGER := -20003;
error_log_c              CONSTANT INTEGER := -20004;
object_not_found_c       CONSTANT INTEGER := -20005;
unique_index_not_found_c CONSTANT INTEGER := -20006;
ts_readwrite_c           CONSTANT INTEGER := -20007;
missing_partition_c      CONSTANT INTEGER := -20008;
--|=
--| Start Private Procedures
--| Roy 9.0.4 changes (creation of private procedure sections)
--|=
--**********************************************
--  Write a entry of what is occuring to a log file.
--**********************************************
PROCEDURE WRITE_LOG_PRO (status_p IN CHAR, error_p IN NUMBER, proc_p IN VARCHAR2,
                         schema_object_p IN VARCHAR2, message_p IN VARCHAR2) AS
BEGIN
   INSERT INTO DB_TOOLS_LOG (user_id, seq, time_stamp, status, error, proc,
                                     schema_object, message)
   VALUES (USER, DB_TOOLS_LOG_SEQ.NEXTVAL, SYSDATE, UPPER(status_p), error_p,
           UPPER(proc_p), UPPER(NVL(schema_object_p,'UNKNOWN')), message_p);
   COMMIT;
EXCEPTION
   WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(error_log_c, error_msgs_tab(error_log_c) || SQLCODE || ' ' ||
                              SQLERRM, TRUE);
END WRITE_LOG_PRO;
--**********************************************
--  Obtains the requestor's object privs from a GW maintained security table.  If the requestor
--    is the object owner, allow request (security entry not required.)
--**********************************************
PROCEDURE CHECK_PRIVS_PRO (current_user_p IN VARCHAR2, object_owner_p IN VARCHAR2) AS
   proc_c          CONSTANT VARCHAR2(50) := 'CHECK_PRIVS_PRO';
   current_user_v  VARCHAR2(30) := UPPER(current_user_p);
   object_owner_v  VARCHAR2(30) := UPPER(object_owner_p);
   error_object_v  VARCHAR2(65) := current_user_v || '.' || object_owner_v;
   count_v         NUMBER;
   role_cnt_v      NUMBER;
   no_privs_e      EXCEPTION;
BEGIN
   IF (object_owner_v IN ('DBA_ORA'
                         ,'DBA_ORACLE'
                         ,'ORACLE'
                         ,'OPS$ORACLE'
                         ,'SYSTEM'
                         ,'SYS'
                         ,'CSMIG'
                         ,'DBSNMP'
                         ,'LBACSYS'
                         ,'MTSSYS'
                         ,'PERSTAT'
                         ,'SCOTT'
                         ,'HR'
                         ,'ANONYMOUS'
                         ,'CTXSYS'
                         ,'MDSYS'
                         ,'OLAPSYS'
                         ,'ORDPLUGINS'
                         ,'ORDSYS'
                         ,'OUTLN'
                         ,'OAS_PUBLIC'
                         ,'OE'
                         ,'PM'
                         ,'QS'
                         ,'QS_ADM'
                         ,'QS_CBADM'
                         ,'QS_CB'
                         ,'QS_CS'
                         ,'QS_ES'
                         ,'QS_OS'
                         ,'QS_WS'
                         ,'SH'
                         ,'WKPROXY'
                         ,'WKSYS'
                         ,'WMSYS'
                         ,'XDB' )) THEN
      RAISE no_privs_e;
   END IF;

   -- If requestor is the owner of the objects...
   IF ((USER = current_user_v) AND (USER = object_owner_v)) THEN
      RETURN;
   END IF;
   -- Allows AppDBAs to run against any schema expect those listed above
   -- Added by Roy Jones, 26-Jan-06
   SELECT count(*)
     INTO role_cnt_v
     FROM dba_role_privs
     WHERE granted_role = 'DB_APP_DBA'
       AND grantee = USER;
   IF role_cnt_v = 1 THEN
     RETURN;
   END IF;
    SELECT COUNT(*) INTO count_v
    FROM DB_TOOLS_ACCESS
    WHERE REQUESTOR_SCHEMA = current_user_v AND
          OBJECT_OWNER_SCHEMA = object_owner_v;
   IF (count_v > 0) THEN
      RETURN;
   ELSE
      RAISE no_privs_e;
   END IF;
EXCEPTION
   WHEN no_privs_e THEN
      RAISE_APPLICATION_ERROR (no_privs_c, error_msgs_tab(no_privs_c), TRUE);
   WHEN OTHERS THEN
      WRITE_LOG_PRO ('E', SQLCODE, proc_c, error_object_v, SQLERRM);
      RAISE;
END CHECK_PRIVS_PRO;
--**********************************************
--  Extract the SQL from the dictionary that is required to build an existing index.
--    Is called prior to dropping an index so that it can be easily recreated.
--**********************************************
PROCEDURE BUILD_INDEX_SQL_PRO (owner_p IN VARCHAR2, index_name_p IN VARCHAR2,
                               build_index_sql_p IN OUT VARCHAR2) AS
   proc_c               CONSTANT VARCHAR2(50) := 'BUILD_INDEX_SQL_PRO';
   owner_v              VARCHAR2(30) := UPPER(owner_p);
   index_name_v         VARCHAR2(30) := UPPER(index_name_p);
   error_object_v       VARCHAR2(65) := owner_v || '.' || index_name_v;
   partition_p          DBA_INDEXES.PARTITIONED%TYPE;
   build_index_rec      build_index_rec_type;
   build_index_part_rec build_index_part_rec_type;
   no_privs_e           EXCEPTION;
   index_not_found_e    EXCEPTION;
BEGIN
   /* Check if user has the proper privs. */
   CHECK_PRIVS_PRO (USER, owner_v);
   build_index_sql_p := NULL;
   /* Check to see if index is partitioned or not */
   SELECT partitioned
     INTO partition_p
     FROM dba_indexes
     WHERE owner = owner_v
       AND index_name = index_name_v;
   IF (partition_p = 'NO') THEN
        OPEN build_index_cur (owner_v, index_name_v);
        LOOP
            FETCH build_index_cur INTO build_index_rec;
            EXIT WHEN build_index_cur%NOTFOUND;
            build_index_sql_p := build_index_sql_p || build_index_rec.text;
        END LOOP;
        CLOSE build_index_cur;
        IF (build_index_sql_p IS NULL) THEN
         RAISE index_not_found_e;
        END IF;
   ELSIF (partition_p = 'YES') THEN
        OPEN build_index_part_cur (owner_v, index_name_v);
        LOOP
            FETCH build_index_part_cur INTO build_index_part_rec;
            EXIT WHEN build_index_part_cur%NOTFOUND;
            build_index_sql_p := build_index_sql_p || build_index_part_rec.text;
        END LOOP;
        CLOSE build_index_part_cur;
        IF (build_index_sql_p IS NULL) THEN
         RAISE index_not_found_e;
        END IF;
   END IF;
EXCEPTION
   WHEN no_privs_e THEN
      WRITE_LOG_PRO ('E', no_privs_c, proc_c, error_object_v, error_msgs_tab(no_privs_c));
      RAISE_APPLICATION_ERROR (no_privs_c, error_msgs_tab(no_privs_c), TRUE);
   WHEN index_not_found_e THEN
      WRITE_LOG_PRO ('W', index_not_defined_c, proc_c, error_object_v,
                     error_msgs_tab(index_not_defined_c));
      RAISE_APPLICATION_ERROR (index_not_defined_c, error_msgs_tab(index_not_defined_c), TRUE);
   WHEN OTHERS THEN
      IF (partition_p = 'NO') THEN
        CLOSE build_index_cur;
      ELSE
        CLOSE build_index_part_cur;
      END IF;
      WRITE_LOG_PRO('E', SQLCODE, proc_c, error_object_v, SQLERRM);
      RAISE;  -- reraise the exception
END BUILD_INDEX_SQL_PRO;
--**********************************************
--  Writes the index's DDL to DB_TOOLS_OBJECTS so that the index can be easily recreated.
--**********************************************
PROCEDURE SAVE_INDEX_DEF_PRO (owner_p IN VARCHAR2, index_name_p IN VARCHAR2) AS
   proc_c            CONSTANT VARCHAR2(50) := 'SAVE_INDEX_DEF_PRO';
   owner_v           VARCHAR2(30) := UPPER(owner_p);
   index_name_v      VARCHAR2(30) := UPPER(index_name_p);
   error_object_v    VARCHAR2(65) := owner_v || '.' || index_name_v;
   build_index_sql_v VARCHAR2(4000);
   par_deg_v         VARCHAR2(40);
   logging_v         VARCHAR2(10);
   no_privs_e        EXCEPTION;
BEGIN
   /* Check if user has the proper privs. */
   BUILD_INDEX_SQL_PRO (owner_v, index_name_v, build_index_sql_v);
   --| 9.0.4 Added selects for saving of Parallel and Logging
   SELECT degree
     INTO par_deg_v
     FROM dba_indexes
     WHERE owner = owner_v
       AND index_name = index_name_v;
   SELECT DECODE(logging, 'YES','LOGGING','NOLOGGING')
     INTO logging_v
     FROM dba_indexes
     WHERE owner = owner_v
       AND index_name = index_name_v;
   DELETE
     FROM DB_TOOLS_OBJECTS
     WHERE OWNER = owner_v
       AND OBJECT_TYPE = 'INDEX'
       AND OBJECT_NAME = index_name_v;
   INSERT INTO db_tools_objects (owner, object_type, object_name, sql_stmt, related_object_info)
     VALUES (owner_v, 'INDEX', index_name_v, build_index_sql_v, 'PARALLEL (DEGREE '||par_deg_v||') '||logging_v);
   COMMIT;
EXCEPTION
   WHEN no_privs_e THEN
      WRITE_LOG_PRO( 'E', no_privs_c, proc_c, error_object_v, error_msgs_tab(no_privs_c));
      RAISE_APPLICATION_ERROR(no_privs_c, error_msgs_tab(no_privs_c), TRUE);
   WHEN OTHERS THEN
      WRITE_LOG_PRO( 'E', SQLCODE, proc_c, error_object_v, SQLERRM );
   RAISE;  -- reraise the exception
END SAVE_INDEX_DEF_PRO;
--**********************************************
--  Enables a priviously disabled constraint or enables all priviously disabled triggers.
--    For PKs/UKs, requires that the unique index be created beforehand.
--**********************************************
PROCEDURE ENABLE_CONS_TRIGS_PRO (cons_trigs_p IN CHAR, owner_p IN VARCHAR2,
                                 table_name_p IN VARCHAR2,
                                 constraint_name_p IN VARCHAR2 DEFAULT NULL,
                                 exceptions_table_p IN VARCHAR2 DEFAULT NULL,
                                 exceptions_schema_p IN VARCHAR2 DEFAULT NULL) AS
   proc_c                   CONSTANT VARCHAR2(50) := 'ENABLE_CONS_TRIGS_PRO';
   cons_trigs_v             CHAR := UPPER(cons_trigs_p);
   owner_v                  VARCHAR2(30) := UPPER(owner_p);
   table_name_v             VARCHAR2(30) := UPPER(table_name_p);
   constraint_name_v        VARCHAR2(30) := UPPER(constraint_name_p);
   exceptions_table_v       DBA_TABLES.TABLE_NAME%TYPE := UPPER(exceptions_table_p);
   exceptions_schema_v      DBA_TABLES.TABLE_NAME%TYPE := UPPER(exceptions_schema_p);
   error_object_v           VARCHAR2(95) := owner_v || '.' || table_name_v || '.' ||
                                            constraint_name_v;
   sql_stmt_v               VARCHAR2(1000);
   constraint_type_v        sys.DBA_CONSTRAINTS.CONSTRAINT_TYPE%TYPE;
   unique_key_index_v       DBA_INDEXES.INDEX_NAME%TYPE;
   cid_v                    INTEGER;
   no_privs_e               EXCEPTION;
   invalid_option_e         EXCEPTION;
   object_not_found_e       EXCEPTION;
   unique_index_not_found_e EXCEPTION;
BEGIN
   /* Check if user has the proper privs. */
   CHECK_PRIVS_PRO (USER, owner_v);
   sql_stmt_v := 'ALTER TABLE ' || owner_v || '.' || table_name_v;
   IF (cons_trigs_v = 'C') THEN
      sql_stmt_v := sql_stmt_v || ' ENABLE CONSTRAINT ' || constraint_name_v;
      BEGIN
         SELECT CONSTRAINT_TYPE INTO constraint_type_v
         FROM sys.DBA_CONSTRAINTS
         WHERE OWNER = owner_v AND
               TABLE_NAME = table_name_v AND
               CONSTRAINT_NAME = constraint_name_v;
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            RAISE object_not_found_e;
         WHEN OTHERS THEN
            RAISE;
      END;
      IF (exceptions_table_v IS NOT NULL OR exceptions_schema_v IS NOT NULL) THEN
         IF (exceptions_schema_v IS NULL) THEN
            exceptions_schema_v := owner_v;
         ELSE
            CHECK_PRIVS_PRO (USER, exceptions_schema_v);
        END IF;
         sql_stmt_v := sql_stmt_v || ' EXCEPTIONS INTO ' ||
                       exceptions_schema_v || '.' || exceptions_table_v;
      END IF;
   ELSIF (cons_trigs_v = 'T') THEN
      sql_stmt_v := sql_stmt_v || ' ENABLE ALL TRIGGERS';
   ELSE
      RAISE invalid_option_e;
   END IF;
   IF ((constraint_type_v = 'P') OR (constraint_type_v = 'U')) THEN
      BEGIN
/*
  Replaced to fix code to determine what index is enforcing what constraint -- Roy ( 1.7 )
  1/14 code removed due to error
*/
         SELECT UNIQUE DI.INDEX_NAME INTO unique_key_index_v
         FROM sys.DBA_CONSTRAINTS DC, DBA_CONS_COLUMNS DCC, DBA_INDEXES DI, DBA_IND_COLUMNS DIC
         WHERE DC.OWNER = owner_v AND
               DC.TABLE_NAME = table_name_v AND
               DC.CONSTRAINT_TYPE IN ('P','U') AND
               DC.CONSTRAINT_NAME = constraint_name_v AND
               DCC.OWNER = DC.OWNER AND
               DCC.TABLE_NAME = DC.TABLE_NAME AND
               DC.CONSTRAINT_NAME = DCC.CONSTRAINT_NAME AND
               DCC.COLUMN_NAME = DIC.COLUMN_NAME AND
               DCC.POSITION = DIC.COLUMN_POSITION AND
               DI.OWNER = DC.OWNER AND
               DI.TABLE_NAME = DC.TABLE_NAME AND
               DI.UNIQUENESS = 'UNIQUE' AND
               DIC.TABLE_OWNER = DI.TABLE_OWNER AND
               DIC.TABLE_NAME = DI.TABLE_NAME AND
               DIC.INDEX_NAME = DI.INDEX_NAME;
/*
         SELECT --+ rule
                o.object_name
           INTO unique_key_index_v
           FROM sys.cdef$ c
               ,dba_objects o
               ,sys.con$ n
           WHERE c.enabled = o.object_id
             AND c.con# = n.con#
             AND o.owner = owner_v
             AND n.name = constraint_name_v;
*/
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            RAISE unique_index_not_found_e;
         WHEN OTHERS THEN
            RAISE;
      END;
   END IF;
   WRITE_LOG_PRO ('I', no_error_c, proc_c, error_object_v, sql_stmt_v);
   BEGIN
      /* Open new cursor and return cursor ID. */
      cid_v := DBMS_SQL.OPEN_CURSOR;
      /* Parse and immediately execute dynamic SQL statement. */
      DBMS_SQL.PARSE(cid_v, sql_stmt_v, DBMS_SQL.native);
      /* Close cursor. */
      DBMS_SQL.CLOSE_CURSOR(cid_v);
   EXCEPTION
      WHEN OTHERS THEN
         DBMS_SQL.CLOSE_CURSOR(cid_v);
         RAISE;  -- reraise the exception
   END;
EXCEPTION
   WHEN no_privs_e THEN
      WRITE_LOG_PRO ('E', no_privs_c, proc_c, error_object_v, error_msgs_tab (no_privs_c));
      RAISE_APPLICATION_ERROR (no_privs_c, error_msgs_tab (no_privs_c), TRUE);
   WHEN invalid_option_e THEN
      WRITE_LOG_PRO ('E', invalid_option_c, proc_c, error_object_v,
                     error_msgs_tab (invalid_option_c));
      RAISE_APPLICATION_ERROR (invalid_option_c, error_msgs_tab (invalid_option_c), TRUE);
   WHEN object_not_found_e THEN
      WRITE_LOG_PRO('E', object_not_found_c, proc_c, error_object_v,
                    error_msgs_tab(object_not_found_c));
      RAISE_APPLICATION_ERROR (object_not_found_c, error_msgs_tab(object_not_found_c), TRUE);
   WHEN unique_index_not_found_e THEN
      WRITE_LOG_PRO ('E', unique_index_not_found_c, proc_c, error_object_v,
                     error_msgs_tab(unique_index_not_found_c));
      RAISE_APPLICATION_ERROR (unique_index_not_found_c,
                               error_msgs_tab(unique_index_not_found_c), TRUE);
   WHEN OTHERS THEN
      WRITE_LOG_PRO ('E', SQLCODE, proc_c, error_object_v, SQLERRM);
      RAISE;  -- reraise the exception
END ENABLE_CONS_TRIGS_PRO;
--|=
--| End Private Procedures
--|=
--**********************************************
--  Analyzes the requested Table/Index/Cluster if the requestor has the required privalege.
--    Accepts additional analyze options thru a parameter string.
--**********************************************
PROCEDURE ANALYZE_OBJECT_PRO (object_type_p IN CHAR, object_owner_p IN VARCHAR2,
                              object_name_p IN VARCHAR2, user_sql_p IN VARCHAR2 DEFAULT NULL,
                              chained_rows_table_p IN VARCHAR2 DEFAULT NULL,
                              chained_rows_owner_p IN VARCHAR2 DEFAULT NULL,
                              partition_type_p IN VARCHAR2 DEFAULT NULL,
                              paritition_name_p IN VARCHAR2 DEFAULT NULL) AS
   proc_c               CONSTANT VARCHAR2(50) := 'ANALYZE_OBJECT_PRO';
   object_type_v        CHAR := UPPER(object_type_p);
   object_owner_v       VARCHAR2(30) := UPPER(object_owner_p);
   object_name_v        VARCHAR2(30) := UPPER(object_name_p);
   chained_rows_table_v VARCHAR2(30) := UPPER(chained_rows_table_p);
   chained_rows_owner_v VARCHAR2(30) := UPPER(chained_rows_owner_p);
   error_object_v       VARCHAR2(95) := object_owner_v || '.' || object_name_v;
   sql_stmt_v           VARCHAR2(1000) := 'ANALYZE ';
   cid_v                INTEGER;
   no_privs_e           EXCEPTION;
   invalid_option_e     EXCEPTION;
BEGIN
   -- Check if user has the proper privs.
   CHECK_PRIVS_PRO (USER, object_owner_v);
   -- Begin building ANALYZE string.
   IF (UPPER(object_type_p) = 'T') THEN
      sql_stmt_v := sql_stmt_v || 'TABLE ';
   ELSIF (UPPER(object_type_p) = 'I') THEN
      sql_stmt_v := sql_stmt_v || 'INDEX ';
   ELSIF (UPPER(object_type_p) = 'C') THEN
      sql_stmt_v := sql_stmt_v || 'CLUSTER ';
   ELSE
      RAISE invalid_option_e;
   END IF;
   sql_stmt_v := sql_stmt_v || object_owner_v || '.' || object_name_v || ' ';
   IF (partition_type_p IS NOT NULL) THEN
       IF (UPPER(partition_type_p) = 'P') THEN
          sql_stmt_v := sql_stmt_v || ' PARTITION (';
       ELSIF (UPPER(partition_type_p) = 'S') THEN
          sql_stmt_v := sql_stmt_v || ' SUBPARTITION (';
       ELSE
          RAISE invalid_option_e;
       END IF;
   sql_stmt_v := sql_stmt_v || paritition_name_p || ') ';
   END IF;
  sql_stmt_v := sql_stmt_v || user_sql_p;
   IF (chained_rows_table_v IS NOT NULL) THEN
      IF (chained_rows_owner_v IS NULL) THEN
         chained_rows_owner_v := object_owner_v;
         error_object_v := chained_rows_owner_v || '.' || chained_rows_table_v;
         CHECK_PRIVS_PRO( USER, chained_rows_owner_v );  --??????
      END IF;
   sql_stmt_v := sql_stmt_v || ' LIST CHAINED ROWS INTO ' || chained_rows_owner_v ||
                 '.' || chained_rows_table_v;
   END IF;
   WRITE_LOG_PRO ('I', no_error_c, proc_c, error_object_v, sql_stmt_v);
   BEGIN
      --  Execute the constructed Analyze SQL string.
      cid_v := DBMS_SQL.OPEN_CURSOR;
      DBMS_SQL.PARSE (cid_v, sql_stmt_v, DBMS_SQL.native);
      DBMS_SQL.CLOSE_CURSOR (cid_v);
   EXCEPTION
      WHEN OTHERS THEN
         DBMS_SQL.CLOSE_CURSOR (cid_v);
         RAISE;
   END;
EXCEPTION
   WHEN no_privs_e THEN
      WRITE_LOG_PRO ('E', no_privs_c, proc_c, error_object_v, error_msgs_tab(no_privs_c));
      RAISE_APPLICATION_ERROR (no_privs_c, error_msgs_tab(no_privs_c), TRUE);
   WHEN invalid_option_e THEN
      WRITE_LOG_PRO ('E', invalid_option_c, proc_c, error_object_v,
                     error_msgs_tab(invalid_option_c));
      RAISE_APPLICATION_ERROR (invalid_option_c, error_msgs_tab(invalid_option_c), TRUE);
   WHEN OTHERS THEN
      WRITE_LOG_PRO ('E', SQLCODE, proc_c, error_object_v, SQLERRM);
      RAISE;
END ANALYZE_OBJECT_PRO;
--**********************************************
--  Coalesces the requested tablespace, if requestor has been granted that ability.
--**********************************************
PROCEDURE COALESCE_TABLESPACE_PRO (ts_name_p IN VARCHAR2) AS
   proc_c               CONSTANT VARCHAR2(50) := 'COALESCE_TABLESPACE_PRO';
   ts_name_v            VARCHAR2(30) := UPPER(ts_name_p);
   error_object_v       VARCHAR2(95) := upper(ts_name_p);
   sql_stmt_v           VARCHAR2(1000) := 'ALTER TABLESPACE ';
   count_v              NUMBER;
   cid_v                INTEGER;
BEGIN
   -- Build ALTER TABLESPACE COALESCE string.
   sql_stmt_v := sql_stmt_v || ts_name_v || ' COALESCE';
   WRITE_LOG_PRO ('I', no_error_c, proc_c, error_object_v, sql_stmt_v);
   BEGIN
      --  Execute the constructed Alter Tablespace Coalesce SQL string.
      cid_v := DBMS_SQL.OPEN_CURSOR;
      DBMS_SQL.PARSE (cid_v, sql_stmt_v, DBMS_SQL.native);
      DBMS_SQL.CLOSE_CURSOR (cid_v);
   EXCEPTION
      WHEN OTHERS THEN
         DBMS_SQL.CLOSE_CURSOR (cid_v);
         RAISE;
   END;
EXCEPTION
   WHEN OTHERS THEN
      WRITE_LOG_PRO ('E', SQLCODE, proc_c, error_object_v, SQLERRM);
      RAISE;
END COALESCE_TABLESPACE_PRO;
--**********************************************
--  Recreates an index that was dropped using DROP_INDEX_PRO.  Gets create stmt details
--    from DB_TOOLS_OBJECTS.
--**********************************************
PROCEDURE CREATE_INDEX_PRO (owner_p IN VARCHAR2, index_name_p IN VARCHAR2,
                            recoverable_p IN BOOLEAN DEFAULT NULL,
                            sorted_p IN BOOLEAN DEFAULT FALSE,
                            parallel_degree_p IN INTEGER DEFAULT NULL,
                            parallel_instances_p IN INTEGER DEFAULT NULL) AS
   proc_c         CONSTANT VARCHAR2(50) := 'CREATE_INDEX_PRO';
   owner_v        VARCHAR2(30) := UPPER(owner_p);
   index_name_v   VARCHAR2(30) := UPPER(index_name_p);
   error_object_v VARCHAR2(65) := owner_v || '.' || index_name_v;
   sql_stmt_v     VARCHAR2(4000);
   cid_v          INTEGER;
   indx_parm_v    VARCHAR2(128);
   no_privs_e     EXCEPTION;
BEGIN
   /* Check if user has the proper privs. */
   CHECK_PRIVS_PRO (USER, owner_v);
   --| 9.0.4 Added code to retreive Parallel and Logging params.
   SELECT REPLACE(REPLACE(REPLACE(sql_stmt, 'NEXT '||CHR(10), NULL),
   						'FREELISTS '||CHR(10), NULL),
   						'PCTINCREASE '||CHR(10), NULL) sql_stmt,
          related_object_info
     INTO sql_stmt_v,indx_parm_v
     FROM DB_TOOLS_OBJECTS
     WHERE OWNER = owner_v
       AND OBJECT_NAME = index_name_v;
   IF (recoverable_p = TRUE) THEN
      sql_stmt_v := sql_stmt_v || ' LOGGING ';
   ELSIF (recoverable_p = FALSE) THEN
      sql_stmt_v := sql_stmt_v || ' NOLOGGING ';
   END IF;
   IF (sorted_p = TRUE) THEN
      sql_stmt_v := sql_stmt_v || ' NOSORT';
   END IF;
   IF ((parallel_degree_p IS NOT NULL) OR (parallel_instances_p IS NOT NULL)) THEN
      sql_stmt_v := sql_stmt_v || ' PARALLEL (';
      IF (parallel_degree_p IS NOT NULL) THEN
         sql_stmt_v := sql_stmt_v || ' DEGREE ' || parallel_degree_p;
      END IF;
      IF (parallel_instances_p IS NOT NULL) THEN
         sql_stmt_v := sql_stmt_v || ' INSTANCES ' || parallel_instances_p;
      END IF;
      sql_stmt_v := sql_stmt_v || ')';
   END IF;
   WRITE_LOG_PRO ('I', no_error_c, proc_c, error_object_v, sql_stmt_v);
   BEGIN
      /* Open new cursor and return cursor ID. */
      cid_v := DBMS_SQL.OPEN_CURSOR;
      /* Parse and immediately execute dynamic SQL statement. */
      DBMS_SQL.PARSE(cid_v, sql_stmt_v, DBMS_SQL.native);
      /* 9.0.4 Alter index to original specs */
      IF indx_parm_v IS NOT NULL THEN
        DBMS_SQL.PARSE(cid_v, 'ALTER INDEX '||owner_v||'.'||index_name_v||' '||indx_parm_v, DBMS_SQL.native);
      END IF;
      /* Close cursor. */
      DBMS_SQL.CLOSE_CURSOR(cid_v);
   EXCEPTION
      WHEN OTHERS THEN
         DBMS_SQL.CLOSE_CURSOR(cid_v);
         RAISE;  -- reraise the exception
   END;
EXCEPTION
   WHEN no_privs_e THEN
      WRITE_LOG_PRO ('E', no_privs_c, proc_c, error_object_v, error_msgs_tab(no_privs_c));
      RAISE_APPLICATION_ERROR (no_privs_c, error_msgs_tab(no_privs_c), TRUE);
   WHEN NO_DATA_FOUND THEN
      WRITE_LOG_PRO ('E', object_not_found_c, proc_c, error_object_v,
                     error_msgs_tab(object_not_found_c));
      RAISE_APPLICATION_ERROR(object_not_found_c, error_msgs_tab(object_not_found_c), TRUE);
   WHEN OTHERS THEN
      WRITE_LOG_PRO ('E', SQLCODE, proc_c, error_object_v, SQLERRM);
      RAISE;  -- reraise the exception
END CREATE_INDEX_PRO;
--**********************************************
-- Uses DBMS_STATS package to do analyzes
--**********************************************
PROCEDURE DBMS_STATS_ANALYZE_PRO (analyze_type_p IN CHAR
                                 ,object_type_p IN CHAR
                                 ,owner_p IN VARCHAR2
                                 ,object_name_p IN VARCHAR2 DEFAULT NULL
                                 ,part_name_p IN VARCHAR2 DEFAULT NULL
                                 ,est_pct_p IN NUMBER DEFAULT NULL
                                 ,blk_samp_p IN BOOLEAN DEFAULT FALSE
                                 ,gran_p IN VARCHAR2 DEFAULT 'DEFAULT'
                                 ,cascade_p IN BOOLEAN DEFAULT FALSE
                                 ,no_invalid_p BOOLEAN DEFAULT FALSE
                                 ,method_opt_p IN VARCHAR2 DEFAULT 'FOR ALL COLUMNS SIZE 1'
                                 ,degree_p IN NUMBER DEFAULT NULL
                                 ,option_p IN VARCHAR2 DEFAULT NULL
                                 ) AS
   proc_c               CONSTANT VARCHAR2(50) := 'DBMS_STATS_ANALYZE_PRO';
   analyze_type_v       CHAR := UPPER(analyze_type_p);
   object_type_v        CHAR := UPPER(object_type_p);
   owner_v              VARCHAR2(60) := UPPER(owner_p);
   object_name_v        VARCHAR2(60) := UPPER(object_name_p);
   method_opt_v         VARCHAR2(60) := UPPER(method_opt_p);
   degree_v             NUMBER       := NULL ;
   part_name_v          VARCHAR2(60) := UPPER(part_name_p);
   gran_v               VARCHAR2(60) := UPPER(gran_p);
   no_invalid_v         VARCHAR2(5);
   cascade_v            VARCHAR2(5);
   blk_samp_v           VARCHAR2(5);
   error_object_v       VARCHAR2(95);
   sql_stmt_v           VARCHAR2(1000) := 'begin DBMS_STATS.';
   cid_v                INTEGER;
   no_privs_e           EXCEPTION;
   invalid_option_e     EXCEPTION;
BEGIN
   -- Build err_obj name
   IF object_name_v IS NOT NULL THEN
      error_object_v := owner_v || '.' || object_name_v;
   ELSIF part_name_v IS NOT NULL THEN
      error_object_v := owner_v || '.' || object_name_v || '.' || part_name_v;
   ELSE
      error_object_v := owner_v;
   END IF;
   -- Check if user has the proper privs.
   CHECK_PRIVS_PRO (USER, owner_v);
   -- Begin building DBMS_STATS string.
   IF (UPPER(analyze_type_v) = 'G') THEN
      sql_stmt_v := sql_stmt_v || 'GATHER_';
   ELSIF (UPPER(analyze_type_v) = 'D') THEN
      sql_stmt_v := sql_stmt_v || 'DELETE_';
   ELSE
      RAISE invalid_option_e;
   END IF;
   IF (UPPER(object_type_v) = 'T') THEN
      sql_stmt_v := sql_stmt_v || 'TABLE_STATS(';
   ELSIF (UPPER(object_type_v) = 'I') THEN
      sql_stmt_v := sql_stmt_v || 'INDEX_STATS(';
   ELSIF (UPPER(object_type_v) = 'S') THEN
      sql_stmt_v := sql_stmt_v || 'SCHEMA_STATS(';
   ELSE
      RAISE invalid_option_e;
   END IF;
   IF no_invalid_p THEN
     no_invalid_v := 'TRUE';
   ELSE
     no_invalid_v := 'FALSE';
   END IF;
   IF cascade_p THEN
     cascade_v := 'TRUE';
   ELSE
     cascade_v := 'FALSE';
   END IF;
   IF blk_samp_p THEN
     blk_samp_v := 'TRUE';
   ELSE
     blk_samp_v := 'FALSE';
   END IF;
   IF degree_p IS NOT NULL THEN
      IF degree_p > 0 AND degree_p <= 4 THEN
         degree_v := degree_p ;
      ELSE 
         RAISE invalid_option_e;
      END IF ;
   ELSE 
      degree_v := NULL ;
   END IF ;

   sql_stmt_v := sql_stmt_v || 'ownname=>'||CHR(39)||owner_v||CHR(39) ||
                               ',no_invalidate=>'||CHR(39)||no_invalid_v||CHR(39) ;
   IF (UPPER(analyze_type_v) = 'G' and UPPER(object_type_v) != 'I' ) THEN
       sql_stmt_v := sql_stmt_v || ',method_opt=>'||CHR(39)||method_opt_v||chr(39) ;
   END IF ;
   IF (UPPER(object_type_v) = 'T') THEN
      sql_stmt_v := sql_stmt_v || ',tabname=>'||CHR(39)||object_name_v||CHR(39);
   ELSIF (UPPER(object_type_v) = 'I') THEN
      sql_stmt_v := sql_stmt_v || ',indname=>'||CHR(39)||object_name_v||CHR(39);
   END IF;
   IF part_name_v IS NOT NULL THEN
      sql_stmt_v := sql_stmt_v || ',partname=>'||CHR(39)||part_name_v||CHR(39);
   END IF;
   IF (UPPER(analyze_type_v) = 'G') THEN
      IF est_pct_p IS NOT NULL THEN
         sql_stmt_v := sql_stmt_v || ',estimate_percent=>'||est_pct_p;
      END IF;
      IF option_p IS NOT NULL AND UPPER(object_type_v) = 'S' THEN
         sql_stmt_v := sql_stmt_v || ',options=>'||CHR(39)||option_p||CHR(39);
      END IF ;
      --| 9.0.5 Added IF
      IF gran_p IS NOT NULL THEN
        sql_stmt_v := sql_stmt_v || ',granularity=>'||CHR(39)||gran_v||CHR(39);
      END IF;
      IF (UPPER(object_type_v) = 'T' OR UPPER(object_type_v) = 'S') THEN
         sql_stmt_v := sql_stmt_v || ',block_sample=>'||CHR(39)||blk_samp_v||CHR(39)||
                                     ',cascade=>'||CHR(39)||cascade_v||CHR(39);
      END IF;
      IF degree_v IS NOT NULL THEN
        sql_stmt_v := sql_stmt_v || ',degree=>'||degree_v;
      END IF ;
   END IF;
   sql_stmt_v := sql_stmt_v || ',force=>TRUE' ;
   sql_stmt_v := REPLACE(REPLACE(sql_stmt_v, CHR(39)||'TRUE'||CHR(39), 'TRUE'), CHR(39)||'FALSE'||CHR(39), 'FALSE') || '); end;';
   -- Write to log
   WRITE_LOG_PRO ('I', no_error_c, proc_c, error_object_v, sql_stmt_v);
   -- Execute statement
   EXECUTE IMMEDIATE sql_stmt_v;
EXCEPTION
   WHEN no_privs_e THEN
      WRITE_LOG_PRO ('E', no_privs_c, proc_c, error_object_v, error_msgs_tab(no_privs_c));
      RAISE_APPLICATION_ERROR (no_privs_c, error_msgs_tab(no_privs_c), TRUE);
   WHEN invalid_option_e THEN
      WRITE_LOG_PRO ('E', invalid_option_c, proc_c, error_object_v,
                     error_msgs_tab(invalid_option_c));
      RAISE_APPLICATION_ERROR (invalid_option_c, error_msgs_tab(invalid_option_c), TRUE);
   WHEN OTHERS THEN
      WRITE_LOG_PRO ('E', SQLCODE, proc_c, error_object_v, SQLERRM);
      RAISE;
END DBMS_STATS_ANALYZE_PRO;
--**********************************************
--  Disables the specified contraint on a table or disables all triggers on the table.
--    For constraints that require supporting indexes (PKs or UKs), the definition of the
--    index will be stored in DB_TOOLS_OBJ prior to index deletion.
--**********************************************
PROCEDURE DISABLE_CONS_TRIGS_PRO (cons_trigs_p IN CHAR, owner_p IN VARCHAR2,
                                  table_name_p IN VARCHAR2,
                                  constraint_name_p IN VARCHAR2 DEFAULT NULL) AS
   proc_c             CONSTANT VARCHAR2(50) := 'DISABLE_CONS_TRIGS_PRO';
   cons_trigs_v       CHAR := UPPER(cons_trigs_p);
   owner_v            VARCHAR2(30) := UPPER(owner_p);
   table_name_v       VARCHAR2(30) := UPPER(table_name_p);
   constraint_name_v  VARCHAR2(30) := UPPER(constraint_name_p);
   error_object_v     VARCHAR2(95) := owner_v || '.' || table_name_v || '.' || constraint_name_v;
   sql_stmt_v         VARCHAR2(1000);
   constraint_type_v  DBA_CONSTRAINTS.CONSTRAINT_TYPE%TYPE;
   unique_key_index_v DBA_INDEXES.INDEX_NAME%TYPE;
   cid_v              INTEGER;
   no_privs_e         EXCEPTION;
   invalid_option_e   EXCEPTION;
   object_not_found_e EXCEPTION;
BEGIN
   /* Check if user has the proper privs. */
   CHECK_PRIVS_PRO (USER, owner_v);
   sql_stmt_v := 'ALTER TABLE ' || owner_v || '.' || table_name_v;
   WRITE_LOG_PRO('I', no_error_c, proc_c, error_object_v,
                 'Sql ' || sql_stmt_v );


   IF (cons_trigs_v = 'C') THEN
      sql_stmt_v := sql_stmt_v || ' DISABLE CONSTRAINT ' || constraint_name_v;
      BEGIN
         SELECT CONSTRAINT_TYPE INTO constraint_type_v
         FROM DBA_CONSTRAINTS
         WHERE OWNER = owner_v AND
               TABLE_NAME = table_name_v AND
              CONSTRAINT_NAME = constraint_name_v;
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            RAISE object_not_found_e;
         WHEN OTHERS THEN
            RAISE;
      END;
   ELSIF (cons_trigs_v = 'T') THEN
      sql_stmt_v := sql_stmt_v || ' DISABLE ALL TRIGGERS';
   ELSE
      RAISE invalid_option_e;
   END IF;
   IF ((constraint_type_v = 'P') OR (constraint_type_v = 'U')) THEN
      BEGIN
/*  Replaced to fix code to determine what index is enforcing what constraint -- Roy ( 1.7 )
         SELECT UNIQUE DI.INDEX_NAME INTO unique_key_index_v
         FROM DBA_CONSTRAINTS DC, DBA_CONS_COLUMNS DCC,
              DBA_INDEXES DI, DBA_IND_COLUMNS DIC
         WHERE DC.OWNER = owner_v AND
               DC.TABLE_NAME = table_name_v AND
               DC.CONSTRAINT_TYPE IN ('P','U') AND
               DC.CONSTRAINT_NAME = constraint_name_v AND
               DCC.OWNER = DC.OWNER AND
               DCC.TABLE_NAME = DC.TABLE_NAME AND
               DC.CONSTRAINT_NAME = DCC.CONSTRAINT_NAME AND
               DCC.COLUMN_NAME = DIC.COLUMN_NAME AND
               DCC.POSITION = DIC.COLUMN_POSITION AND
               DI.OWNER = DC.OWNER AND
               DI.TABLE_NAME = DC.TABLE_NAME AND
               DI.UNIQUENESS = 'UNIQUE' AND
               DIC.TABLE_OWNER = DI.TABLE_OWNER AND
               DIC.TABLE_NAME = DI.TABLE_NAME AND
               DIC.INDEX_NAME = DI.INDEX_NAME;
*/
         SELECT --+ rule
                o.object_name
           INTO unique_key_index_v
           FROM sys.cdef$ c
               ,dba_objects o
               ,sys.con$ n
           WHERE c.enabled = o.object_id
             AND c.con# = n.con#
             AND o.owner = owner_v
             AND n.name = constraint_name_v;
      END;
      SAVE_INDEX_DEF_PRO(owner_v, unique_key_index_v);
      UPDATE DB_TOOLS_OBJECTS
      SET RELATED_OWNER = owner_v, RELATED_OBJECT_NAME = table_name_v ||
                          '.' || constraint_name_v
      WHERE OWNER = owner_v AND
            OBJECT_TYPE = 'INDEX' AND
            OBJECT_NAME = unique_key_index_v;
   END IF;
   WRITE_LOG_PRO ('I', no_error_c, proc_c, error_object_v, sql_stmt_v);
   BEGIN
      /* Open new cursor and return cursor ID. */
      cid_v := DBMS_SQL.OPEN_CURSOR;
      /* Parse and immediately execute dynamic SQL statement. */
      DBMS_SQL.PARSE(cid_v, sql_stmt_v, DBMS_SQL.native);
      /* Close cursor. */
      DBMS_SQL.CLOSE_CURSOR(cid_v);
      dbms_output.put_line('Executed '||sql_stmt_v);
   EXCEPTION
      WHEN OTHERS THEN
         DBMS_SQL.CLOSE_CURSOR(cid_v);
         RAISE;  -- reraise the exception
   END;
EXCEPTION
   WHEN invalid_option_e THEN
      WRITE_LOG_PRO ('E', invalid_option_c, proc_c, error_object_v,
                     error_msgs_tab(invalid_option_c));
      RAISE_APPLICATION_ERROR (invalid_option_c, error_msgs_tab(invalid_option_c), TRUE);
   WHEN no_privs_e THEN
      WRITE_LOG_PRO ('E', no_privs_c, proc_c, error_object_v, error_msgs_tab(no_privs_c));
      RAISE_APPLICATION_ERROR (no_privs_c, error_msgs_tab(no_privs_c), TRUE);
   WHEN object_not_found_e THEN
      WRITE_LOG_PRO ('E', object_not_found_c, proc_c, error_object_v,
                     error_msgs_tab(object_not_found_c));
      RAISE_APPLICATION_ERROR (object_not_found_c, error_msgs_tab(object_not_found_c), TRUE);
   WHEN OTHERS THEN
      WRITE_LOG_PRO ('E', SQLCODE, proc_c, error_object_v, SQLERRM);
      RAISE;  -- reraise the exception
END DISABLE_CONS_TRIGS_PRO;
--**********************************************
--  Disables/Enables all FKs for a given table.
--**********************************************
PROCEDURE DIS_ENABLE_ALL_FK_CONS_PRO (dis_enable_p IN CHAR, owner_p IN VARCHAR2,
                                      table_name_p IN VARCHAR2,
                                      exceptions_table_p IN VARCHAR2 DEFAULT NULL,
                                      exceptions_schema_p IN VARCHAR2 DEFAULT NULL) AS
   proc_c              CONSTANT VARCHAR2(50) := 'DIS_ENABLE_ALL_FK_CONS_PRO';
   owner_v             DBA_TABLES.OWNER%TYPE := UPPER(owner_p);
   table_name_v        DBA_TABLES.TABLE_NAME%TYPE := UPPER(table_name_p);
   exceptions_table_v  DBA_TABLES.TABLE_NAME%TYPE := UPPER(exceptions_table_p);
   exceptions_schema_v DBA_TABLES.TABLE_NAME%TYPE := UPPER(exceptions_schema_p);
   constraint_name_v   DBA_CONSTRAINTS.CONSTRAINT_NAME%TYPE;
   error_object_v      VARCHAR2(95) := owner_v || '.' || table_name_v;
   dis_enable_v        CHAR := UPPER(dis_enable_p);
   no_privs_e          EXCEPTION;
   invalid_option_e    EXCEPTION;
   object_not_found_e  EXCEPTION;
   CURSOR FK_CURSOR IS
      SELECT CONSTRAINT_NAME
      FROM DBA_CONSTRAINTS
      WHERE owner_v = OWNER AND
            table_name_v = TABLE_NAME AND
            CONSTRAINT_TYPE = 'R';
BEGIN
   WRITE_LOG_PRO('I', no_error_c, proc_c, error_object_v,
                 'Running procedure with option ' || dis_enable_v||
                 ';o=<'||owner_v||
                 '>;t=<'||table_name_v||'>' );
   IF ((dis_enable_v != 'D') AND (dis_enable_v != 'E')) THEN
      RAISE invalid_option_e;
   END IF;
   CHECK_PRIVS_PRO (USER, owner_v);
   OPEN FK_CURSOR;
   LOOP
      FETCH FK_CURSOR INTO constraint_name_v;
      EXIT WHEN FK_CURSOR%NOTFOUND;
      error_object_v := owner_v || '.' || table_name_v || '.' || constraint_name_v;
      IF dis_enable_v = 'D' THEN
   			WRITE_LOG_PRO('I', no_error_c, proc_c, error_object_v,
                 'Disabling constriant ' || constraint_name_v );
         DISABLE_CONS_TRIGS_PRO ('C', owner_v, table_name_v, constraint_name_v);
      ELSE
         ENABLE_CONS_TRIGS_PRO ('C', owner_v, table_name_v, constraint_name_v,
                                exceptions_table_v, exceptions_schema_v);
      END IF;
   END LOOP;
   CLOSE FK_CURSOR;
EXCEPTION
   WHEN invalid_option_e THEN
      WRITE_LOG_PRO ('E', invalid_option_c, proc_c, error_object_v,
                     error_msgs_tab(invalid_option_c));
      RAISE_APPLICATION_ERROR (invalid_option_c, error_msgs_tab(invalid_option_c), TRUE);
   WHEN no_privs_e THEN
      WRITE_LOG_PRO ('E', no_privs_c, proc_c, error_object_v, error_msgs_tab(no_privs_c));
      RAISE_APPLICATION_ERROR (no_privs_c, error_msgs_tab(no_privs_c), TRUE);
   WHEN object_not_found_e THEN
      WRITE_LOG_PRO ('E', object_not_found_c, proc_c, error_object_v,
                     error_msgs_tab(object_not_found_c));
      RAISE_APPLICATION_ERROR (object_not_found_c, error_msgs_tab(object_not_found_c), TRUE);
   WHEN OTHERS THEN
      WRITE_LOG_PRO ('E', SQLCODE, proc_c, error_object_v, SQLERRM);
   RAISE;  -- reraise the exception
END DIS_ENABLE_ALL_FK_CONS_PRO;
--**********************************************
--  Disables/enables the specified contraint on a table or disables/enables all triggers
--    on the table.  For constraints that require supporting indexes (PKs or UKs), the
--    definition of the index will be stored in DB_TOOLS_OBJ prior to index deletion.
--    In order to enable a constraint, it must have been priviously disabled.
--    To renabling PKs/UKs, requires that the unique index be created beforehand.
--**********************************************
PROCEDURE DIS_ENABLE_CONS_TRIGS_PRO (dis_enable_p IN CHAR, cons_trigs_p IN CHAR,
                                     owner_p IN VARCHAR2, table_name_p IN VARCHAR2,
                                     constraint_name_p IN VARCHAR2 DEFAULT NULL,
                                     exceptions_table_p IN VARCHAR2 DEFAULT NULL,
                                     exceptions_schema_p IN VARCHAR2 DEFAULT NULL) AS
   proc_c                   CONSTANT VARCHAR2(50) := 'DIS_ENABLE_CONS_TRIGS_PRO';
   cons_trigs_v             CHAR := UPPER(cons_trigs_p);
   owner_v                  VARCHAR2(30) := UPPER(owner_p);
   table_name_v             VARCHAR2(30) := UPPER(table_name_p);
   constraint_name_v        VARCHAR2(30) := UPPER(constraint_name_p);
   error_object_v           VARCHAR2(95) := owner_v || '.' || table_name_v || '.' ||
                                            constraint_name_v;
   dis_enable_v             CHAR := UPPER(dis_enable_p);
   sql_stmt_v               VARCHAR2(1000);
   constraint_type_v        DBA_CONSTRAINTS.CONSTRAINT_TYPE%TYPE;
   unique_key_index_v       DBA_INDEXES.INDEX_NAME%TYPE;
   cid_v                    INTEGER;
   exceptions_table_v       DBA_TABLES.TABLE_NAME%TYPE := UPPER(exceptions_table_p);
   exceptions_schema_v      DBA_TABLES.TABLE_NAME%TYPE := UPPER(exceptions_schema_p);
   no_privs_e               EXCEPTION;
   invalid_option_e         EXCEPTION;
   object_not_found_e       EXCEPTION;
   unique_index_not_found_e EXCEPTION;
BEGIN
   IF ((dis_enable_v != 'D') AND (dis_enable_v != 'E')) THEN
      RAISE invalid_option_e;
   END IF;
   /* Check if user has the proper privs. */
   CHECK_PRIVS_PRO (USER, owner_v);
   sql_stmt_v := 'ALTER TABLE ' || owner_v || '.' || table_name_v;
   /*  Process request for a specific constraint */
   IF (cons_trigs_v = 'C') THEN
      if (dis_enable_v = 'D') then
         sql_stmt_v := sql_stmt_v || ' DISABLE CONSTRAINT ' || constraint_name_v;
      else
         sql_stmt_v := sql_stmt_v || ' ENABLE CONSTRAINT ' || constraint_name_v;
      end if;
      BEGIN
         SELECT CONSTRAINT_TYPE INTO constraint_type_v
         FROM DBA_CONSTRAINTS
         WHERE OWNER = owner_v AND
               TABLE_NAME = table_name_v AND
               CONSTRAINT_NAME = constraint_name_v;
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            RAISE object_not_found_e;
         WHEN OTHERS THEN
            RAISE;
      END;
      IF ((dis_enable_v = 'E') and (exceptions_table_v IS NOT NULL OR
                                    exceptions_schema_v IS NOT NULL)) THEN
         IF (exceptions_schema_v IS NULL) THEN
            exceptions_schema_v := owner_v;
         ELSE
            CHECK_PRIVS_PRO (USER, exceptions_schema_v);
         END IF;
         sql_stmt_v := sql_stmt_v || ' EXCEPTIONS INTO ' ||
                       exceptions_schema_v || '.' || exceptions_table_v;
      END IF;
   ELSIF (cons_trigs_v = 'T') THEN
      if (dis_enable_v = 'D') then
         sql_stmt_v := sql_stmt_v || ' DISABLE ALL TRIGGERS';
      else
         sql_stmt_v := sql_stmt_v || ' ENABLE ALL TRIGGERS';
      end if;
   ELSE
      RAISE invalid_option_e;
   END IF;
   IF ((constraint_type_v = 'P') OR (constraint_type_v = 'U')) THEN
      BEGIN
--  Modified code to determine what index is enforcing what constraint -- Roy ( 1.7 )
        IF (dis_enable_v = 'E') THEN
         SELECT UNIQUE DI.INDEX_NAME INTO unique_key_index_v
         FROM DBA_CONSTRAINTS DC, DBA_CONS_COLUMNS DCC,
              DBA_INDEXES DI, DBA_IND_COLUMNS DIC
         WHERE DC.OWNER = owner_v AND
               DC.TABLE_NAME = table_name_v AND
               DC.CONSTRAINT_TYPE IN ('P','U') AND
               DC.CONSTRAINT_NAME = constraint_name_v AND
               DCC.OWNER = DC.OWNER AND
               DCC.TABLE_NAME = DC.TABLE_NAME AND
               DC.CONSTRAINT_NAME = DCC.CONSTRAINT_NAME AND
               DCC.COLUMN_NAME = DIC.COLUMN_NAME AND
               DCC.POSITION = DIC.COLUMN_POSITION AND
               DI.OWNER = DC.OWNER AND
               DI.TABLE_NAME = DC.TABLE_NAME AND
               DI.UNIQUENESS = 'UNIQUE' AND
               DIC.TABLE_OWNER = DI.TABLE_OWNER AND
               DIC.TABLE_NAME = DI.TABLE_NAME AND
               DIC.INDEX_NAME = DI.INDEX_NAME;
        ELSIF (dis_enable_v = 'D') THEN
         SELECT --+ rule
                o.object_name
           INTO unique_key_index_v
           FROM sys.cdef$ c
               ,dba_objects o
               ,sys.con$ n
           WHERE c.enabled = o.object_id
             AND c.con# = n.con#
             AND o.owner = owner_v
             AND n.name = constraint_name_v;
        END IF;
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            RAISE unique_index_not_found_e;
         WHEN OTHERS THEN
            RAISE;
      END;
--  Save UK/PK index stuff so that it can be recreated when constraint is to be
--     renabled.
      if (dis_enable_v = 'D') then
         SAVE_INDEX_DEF_PRO(owner_v, unique_key_index_v);
         UPDATE DB_TOOLS_OBJECTS
         SET RELATED_OWNER = owner_v, RELATED_OBJECT_NAME = table_name_v ||
                             '.' || constraint_name_v
         WHERE OWNER = owner_v AND
               OBJECT_TYPE = 'INDEX' AND
               OBJECT_NAME = unique_key_index_v;
      end if;
   END IF;
   WRITE_LOG_PRO ('I', no_error_c, proc_c, error_object_v, sql_stmt_v);
   BEGIN
      /* Open new cursor and return cursor ID. */
      cid_v := DBMS_SQL.OPEN_CURSOR;
      /* Parse and immediately execute dynamic SQL statement. */
      DBMS_SQL.PARSE(cid_v, sql_stmt_v, DBMS_SQL.native);
      /* Close cursor. */
      DBMS_SQL.CLOSE_CURSOR(cid_v);
   EXCEPTION
      WHEN OTHERS THEN
         DBMS_SQL.CLOSE_CURSOR(cid_v);
         RAISE;  -- reraise the exception
   END;
EXCEPTION
   WHEN no_privs_e THEN
      WRITE_LOG_PRO ('E', no_privs_c, proc_c, error_object_v, error_msgs_tab (no_privs_c));
      RAISE_APPLICATION_ERROR (no_privs_c, error_msgs_tab (no_privs_c), TRUE);
   WHEN invalid_option_e THEN
      WRITE_LOG_PRO ('E', invalid_option_c, proc_c, error_object_v,
                     error_msgs_tab (invalid_option_c));
      RAISE_APPLICATION_ERROR (invalid_option_c, error_msgs_tab (invalid_option_c), TRUE);
   WHEN object_not_found_e THEN
      WRITE_LOG_PRO('E', object_not_found_c, proc_c, error_object_v,
                    error_msgs_tab(object_not_found_c));
      RAISE_APPLICATION_ERROR (object_not_found_c, error_msgs_tab(object_not_found_c), TRUE);
   WHEN unique_index_not_found_e THEN
      WRITE_LOG_PRO ('E', unique_index_not_found_c, proc_c, error_object_v,
                     error_msgs_tab(unique_index_not_found_c));
      RAISE_APPLICATION_ERROR (unique_index_not_found_c,
                               error_msgs_tab(unique_index_not_found_c), TRUE);
   WHEN OTHERS THEN
      WRITE_LOG_PRO ('E', SQLCODE, proc_c, error_object_v, SQLERRM);
      RAISE;  -- reraise the exception
END DIS_ENABLE_CONS_TRIGS_PRO;
--**********************************************
--  Drops the requested index, given the appropriate priveleges.  Before dropping, writes
--    the index's DDL to DB_TOOLS_OBJECTS so that the index can be easily recreated.
--**********************************************
PROCEDURE DROP_INDEX_PRO (owner_p IN VARCHAR2, index_name_p IN VARCHAR2) AS
   proc_c         CONSTANT VARCHAR2(50) := 'DROP_INDEX_PRO';
   owner_v        VARCHAR2(30) := UPPER(owner_p);
   index_name_v   VARCHAR2(30) := UPPER(index_name_p);
   error_object_v VARCHAR2(65) := owner_v || '.' || index_name_v;
   sql_stmt_v     VARCHAR2(1000);
   cid_v          INTEGER;
   no_privs_e     EXCEPTION;
BEGIN
   /* Check if user has the proper privs. */
   CHECK_PRIVS_PRO (USER, owner_v);
   SAVE_INDEX_DEF_PRO (owner_v, index_name_v);
   sql_stmt_v := 'DROP INDEX ' || owner_v || '.' || index_name_v;
   WRITE_LOG_PRO ('I', no_error_c, proc_c, error_object_v, sql_stmt_v);
   BEGIN
      /* Open new cursor and return cursor ID. */
      cid_v := DBMS_SQL.OPEN_CURSOR;
      /* Parse and immediately execute dynamic SQL statement. */
      DBMS_SQL.PARSE(cid_v, sql_stmt_v, DBMS_SQL.native);
      /* Close cursor. */
      DBMS_SQL.CLOSE_CURSOR(cid_v);
   EXCEPTION
      WHEN OTHERS THEN
         DBMS_SQL.CLOSE_CURSOR(cid_v);
         RAISE;  -- reraise the exception
   END;
EXCEPTION
   WHEN no_privs_e THEN
      WRITE_LOG_PRO( 'E', no_privs_c, proc_c, error_object_v, error_msgs_tab(no_privs_c));
      RAISE_APPLICATION_ERROR(no_privs_c, error_msgs_tab(no_privs_c), TRUE);
   WHEN OTHERS THEN
      WRITE_LOG_PRO( 'E', SQLCODE, proc_c, error_object_v, SQLERRM );
      RAISE;  -- reraise the exception
END DROP_INDEX_PRO;
--**********************************************
--  This will allow someone to add, drop, swap_highest value
--    in a list partition
--**********************************************
PROCEDURE MOD_LIST_PART_PRO (modify_type_p IN CHAR
                            ,owner_p IN VARCHAR2
                            ,table_name_p IN VARCHAR2
                            ,part_name_p IN VARCHAR2
                            ,list_value_p IN VARCHAR2) AS
   proc_c               CONSTANT VARCHAR2(50) := 'MOD_LIST_PART_PRO';
   owner_v              VARCHAR2(30) := UPPER(owner_p);
   table_name_v         VARCHAR2(30) := UPPER(table_name_p);
   part_name_v          VARCHAR2(30) := UPPER(part_name_p);
   error_object_v       VARCHAR2(95) := owner_v || '.' || table_name_v || '.' ||
                                        part_name_v;
   sql_stmt_v           VARCHAR2(1000) := 'ALTER TABLE '||owner_v || '.' || table_name_v ||
                                          ' MODIFY PARTITION '|| part_name_v;
   cursor_v             INTEGER DEFAULT dbms_sql.open_cursor;
   number_v             NUMBER;
   long_v               VARCHAR2(4000);
   long_len_v           NUMBER;
   buflen_v             NUMBER := 4000;
   curpos_v             NUMBER := 0;
   obj_chk_v            NUMBER := 0;
   local_mod_v          CHAR := ' ';
   no_privs_e           EXCEPTION;
   invalid_option_e     EXCEPTION;
   object_not_found_e   EXCEPTION;
BEGIN
DBMS_OUTPUT.enable(1000000);
   /* Check to see if owner exists */
   SELECT COUNT(*)
     INTO obj_chk_v
     FROM all_users
     WHERE username = owner_v;
   IF (obj_chk_v != 1) THEN
      RAISE object_not_found_e;
   END IF;
   /* Check if user has the proper privs. */
   CHECK_PRIVS_PRO (USER, owner_v);
   /* Check to see if owner exists */
   SELECT COUNT(*)
     INTO obj_chk_v
     FROM dba_tab_partitions
     WHERE table_owner = owner_v
       AND table_name = table_name_v
       AND partition_name = part_name_v;
   IF (obj_chk_v != 1) THEN
      RAISE object_not_found_e;
   END IF;
   -- Check modify type and start building alter statement
   IF (UPPER(modify_type_p) = 'A') THEN
      local_mod_v := 'A';
      sql_stmt_v := sql_stmt_v || ' ADD VALUES ('||CHR(39)||list_value_p||CHR(39)||')';
   ELSIF (UPPER(modify_type_p) = 'D') THEN
      local_mod_v := 'D';
      sql_stmt_v := sql_stmt_v || ' DROP VALUES ('||CHR(39)||list_value_p||CHR(39)||')';
   ELSIF (UPPER(modify_type_p) = 'R') THEN
      global_mod_v := 'R';
      local_mod_v := 'R';
      dbms_sql.parse(cursor_v, 'SELECT high_value' ||
                               '  FROM dba_tab_partitions' ||
                               '  WHERE table_name = ''' || table_name_v || '''' ||
                               '    AND partition_name = ''' || part_name_v || ''''
                               ,DBMS_SQL.native);
      dbms_sql.define_column_long(cursor_v, 1);
      number_v := dbms_sql.execute(cursor_v);
      IF (dbms_sql.fetch_rows(cursor_v)>0) THEN
        dbms_sql.column_value_long(cursor_v,1,buflen_v,curpos_v,long_v,long_len_v);
      END IF;
      dbms_sql.close_cursor(cursor_v);
      mod_list_part_pro('A',owner_v,table_name_v,part_name_v,list_value_p);
      BEGIN
        mod_list_part_pro('D',owner_v,table_name_v,part_name_v,REPLACE(REPLACE(long_v, CHR(39)),', ',CHR(39)||', '||CHR(39)));
      EXCEPTION
         WHEN OTHERS THEN
            mod_list_part_pro('D',owner_v,table_name_v,part_name_v,list_value_p);
            RAISE;  -- reraise the exception
      END;
   ELSE
      RAISE invalid_option_e;
   END IF;
   -- Write to log
   IF UPPER(modify_type_p) IN ('A','D') THEN
     WRITE_LOG_PRO ('I', no_error_c, proc_c, error_object_v, sql_stmt_v);
   END IF;
   -- Execute statement
   EXECUTE IMMEDIATE sql_stmt_v;
EXCEPTION
   WHEN invalid_option_e THEN
      IF (global_mod_v = 'R' AND local_mod_v = 'R') OR
         global_mod_v != 'R' THEN
         WRITE_LOG_PRO ('E', invalid_option_c, proc_c, error_object_v,
                        error_msgs_tab(invalid_option_c));
      END IF;
      RAISE_APPLICATION_ERROR (invalid_option_c, error_msgs_tab(invalid_option_c), TRUE);
   WHEN no_privs_e THEN
      IF (global_mod_v = 'R' AND local_mod_v = 'R') OR
         global_mod_v != 'R' THEN
         WRITE_LOG_PRO ('E', no_privs_c, proc_c, error_object_v, error_msgs_tab(no_privs_c));
      END IF;
      RAISE_APPLICATION_ERROR (no_privs_c, error_msgs_tab(no_privs_c), TRUE);
   WHEN object_not_found_e THEN
      IF (global_mod_v = 'R' AND local_mod_v = 'R') OR
         global_mod_v != 'R' THEN
         WRITE_LOG_PRO ('E', object_not_found_c, proc_c, error_object_v,
                        error_msgs_tab(object_not_found_c));
      END IF;
      RAISE_APPLICATION_ERROR (object_not_found_c, error_msgs_tab(object_not_found_c), TRUE);
   WHEN OTHERS THEN
      IF (global_mod_v = 'R' AND local_mod_v = 'R') OR
         global_mod_v != 'R' THEN
         WRITE_LOG_PRO ('E', SQLCODE, proc_c, error_object_v, SQLERRM);
      END IF;
      RAISE;  -- reraise the exception
END MOD_LIST_PART_PRO;
--**********************************************
--  Changes all tablespaces the user has quota to read-write status, if the
--  if requestor has been granted that ability.
--**********************************************
PROCEDURE READWRITE_TABLESPACE_PRO (owner_p IN VARCHAR2) AS
   proc_c               CONSTANT VARCHAR2(50) := 'READWRITE_TABLESPACE_PRO';
   owner_v              VARCHAR2(30) := UPPER(owner_p);
   ts_name_v            DBA_TS_QUOTAS.TABLESPACE_NAME%TYPE;
   ts_status_v          DBA_TABLESPACES.STATUS%TYPE;
   error_object_v       VARCHAR2(95);
   sql_stmt_v           VARCHAR2(1000);
   count_v              NUMBER;
   cid_v                INTEGER;
   no_privs_e           EXCEPTION;
   object_not_found_e   EXCEPTION;
   ts_readwrite_e       EXCEPTION;
   CURSOR tablespace_cursor
   IS
    SELECT      upper(q.tablespace_name), t.status
    FROM        dba_ts_quotas q, dba_tablespaces t
    WHERE       q.username = owner_v
    and         q.tablespace_name = t.tablespace_name;
BEGIN
   /* Check if user has the proper privs. */
   CHECK_PRIVS_PRO (USER, owner_v);
   /* Get tablespaces user has quota on */
   OPEN tablespace_cursor;
   LOOP
        sql_stmt_v := 'ALTER TABLESPACE ';
        FETCH tablespace_cursor INTO ts_name_v, ts_status_v;
        EXIT WHEN tablespace_cursor%NOTFOUND;
        IF (ts_name_v IS NULL) THEN
            RAISE object_not_found_e;
        END IF;
        /* Build SQL statement for each tablespace */
        error_object_v := ts_name_v;
        IF (ts_status_v != 'READ ONLY') THEN
            WRITE_LOG_PRO ('I', ts_readwrite_c, proc_c, error_object_v, error_msgs_tab (ts_readwrite_c));
        ELSE
            sql_stmt_v:= sql_stmt_v || ts_name_v || ' READ WRITE';
            WRITE_LOG_PRO ('I', no_error_c, proc_c, error_object_v, sql_stmt_v);
            BEGIN
                --  Execute the constructed Alter Tablespace Read Write SQL string.
                cid_v := DBMS_SQL.OPEN_CURSOR;
                DBMS_SQL.PARSE (cid_v, sql_stmt_v, DBMS_SQL.native);
                DBMS_SQL.CLOSE_CURSOR (cid_v);
                EXCEPTION
                WHEN OTHERS THEN
                    DBMS_SQL.CLOSE_CURSOR (cid_v);
                RAISE;
            END;
        END IF;
    END LOOP;
    CLOSE tablespace_cursor;
EXCEPTION
   WHEN no_privs_e THEN
      WRITE_LOG_PRO ('E', no_privs_c, proc_c, error_object_v, error_msgs_tab (no_privs_c));
      RAISE_APPLICATION_ERROR (no_privs_c, error_msgs_tab (no_privs_c), TRUE);
   WHEN object_not_found_e THEN
      WRITE_LOG_PRO ('E', object_not_found_c, proc_c, error_object_v, error_msgs_tab (object_not_found_c));
      RAISE_APPLICATION_ERROR (object_not_found_c, error_msgs_tab (object_not_found_c), TRUE);
   WHEN OTHERS THEN
      WRITE_LOG_PRO ('E', SQLCODE, proc_c, error_object_v, SQLERRM);
      RAISE;
END READWRITE_TABLESPACE_PRO;
--**********************************************
--  Rebuilds an index in place, given the appropriate priveleges.
--  Normally used with an index set to unusable for bulk loading (SET_UNUSABLE_INDEX_PRO)
--**********************************************
PROCEDURE REBUILD_INDEX_PRO (owner_p IN VARCHAR2,
                             index_name_p IN VARCHAR2,
                             partition_type_p IN VARCHAR2 DEFAULT NULL,
                             paritition_name_p IN VARCHAR2 DEFAULT NULL) AS
   proc_c         CONSTANT VARCHAR2(50) := 'REBUILD_INDEX_PRO';
   owner_v        VARCHAR2(30) := UPPER(owner_p);
   index_name_v   VARCHAR2(30) := UPPER(index_name_p);
   error_object_v VARCHAR2(65) := owner_v || '.' || index_name_v;
   sql_stmt_v     VARCHAR2(1000);
   cid_v          INTEGER;
   index_type_v   all_indexes.index_type%TYPE;
   no_privs_e     EXCEPTION;
   invalid_option_e EXCEPTION;
   missing_partition_e EXCEPTION;
BEGIN
   /* Check if user has the proper privs. */
   CHECK_PRIVS_PRO (USER, owner_v);
   sql_stmt_v := 'ALTER INDEX ' || owner_v || '.' || index_name_v || ' REBUILD';

   IF (partition_type_p IS NOT NULL) THEN
       IF (UPPER(partition_type_p) = 'P') THEN
          sql_stmt_v := sql_stmt_v || ' PARTITION ';
       ELSIF (UPPER(partition_type_p) = 'S') THEN
          sql_stmt_v := sql_stmt_v || ' SUBPARTITION ';
       ELSE
          RAISE invalid_option_e;
       END IF;
       IF (rtrim(paritition_name_p) IS NULL) THEN
           -- verify that we received a partition name
           RAISE missing_partition_e;
       END IF;
   sql_stmt_v := sql_stmt_v || paritition_name_p;
   END IF;
   SELECT index_type
     INTO index_type_v
     FROM all_indexes
     WHERE owner = owner_v
       AND index_name = index_name_v;
   IF index_type_v != 'DOMAIN' THEN
     sql_stmt_v := sql_stmt_v || ' NOLOGGING';
   END IF;
   WRITE_LOG_PRO ('I', no_error_c, proc_c, error_object_v, sql_stmt_v);
   BEGIN
      /* Open new cursor and return cursor ID. */
      cid_v := DBMS_SQL.OPEN_CURSOR;
      /* Parse and immediately execute dynamic SQL statement. */
      DBMS_SQL.PARSE(cid_v, sql_stmt_v, DBMS_SQL.native);
      /* Close cursor. */
      DBMS_SQL.CLOSE_CURSOR(cid_v);
   EXCEPTION
      WHEN OTHERS THEN
         DBMS_SQL.CLOSE_CURSOR(cid_v);
         RAISE;  -- reraise the exception
   END;
EXCEPTION
   WHEN no_privs_e THEN
      WRITE_LOG_PRO( 'E', no_privs_c, proc_c, error_object_v, error_msgs_tab(no_privs_c));
      RAISE_APPLICATION_ERROR(no_privs_c, error_msgs_tab(no_privs_c), TRUE);
   WHEN invalid_option_e THEN
      WRITE_LOG_PRO ('E', invalid_option_c, proc_c, error_object_v,
                     error_msgs_tab (invalid_option_c));
      RAISE_APPLICATION_ERROR (invalid_option_c, error_msgs_tab (invalid_option_c), TRUE);
   WHEN missing_partition_e THEN
      WRITE_LOG_PRO ('E', missing_partition_c, proc_c, error_object_v,
                     error_msgs_tab (missing_partition_c));
      RAISE_APPLICATION_ERROR (missing_partition_c, error_msgs_tab (missing_partition_c), TRUE);
   WHEN OTHERS THEN
      WRITE_LOG_PRO( 'E', SQLCODE, proc_c, error_object_v, SQLERRM );
      RAISE;  -- reraise the exception
END REBUILD_INDEX_PRO;
--**********************************************
--  Refreshes materialized view specified, given the appropriate access.
--**********************************************
PROCEDURE REFRESH_MVIEW_PRO (owner_p IN VARCHAR2,
                               mview_name_p IN VARCHAR2,
                               refresh_method_p IN VARCHAR2 DEFAULT NULL,
                               rollback_seg_p IN VARCHAR2 DEFAULT NULL) AS
   proc_c           CONSTANT VARCHAR2(50) := 'REFRESH_MVIEW_PRO';
   owner_v          VARCHAR2(30) := UPPER(owner_p);
   mview_name_v     VARCHAR2(30) := UPPER(mview_name_p);
   refresh_method_v CHAR := UPPER(refresh_method_p);
   rollback_seg_v   VARCHAR2(30) := UPPER(rollback_seg_p);
   error_object_v   VARCHAR2(65) := owner_v || '.' || mview_name_v;
   sql_stmt_v       VARCHAR2(4000);
   no_privs_e       EXCEPTION;
   invalid_option_e EXCEPTION;
BEGIN
   /* Check if user has the proper privs. */
   CHECK_PRIVS_PRO (USER, owner_v);
   sql_stmt_v := 'dbms_mview.refresh(''' || owner_v || '.' || mview_name_v || '''';
   IF (refresh_method_v IS NOT NULL) THEN
      IF ((refresh_method_v != 'C') AND (refresh_method_v != 'F') AND
          (refresh_method_v != '?') AND (refresh_method_v != 'A')) THEN
        RAISE invalid_option_e;
      ELSE
        IF (rollback_seg_v IS NOT NULL) THEN
            sql_stmt_v := sql_stmt_v || ',''' || refresh_method_v || ''','''
                            || rollback_seg_v || ''')' ;
        ELSE
            sql_stmt_v := sql_stmt_v || ',''' || refresh_method_v || ''')' ;
        END IF;
      END IF;
   ELSE
        IF (rollback_seg_v IS NOT NULL) THEN
            sql_stmt_v := sql_stmt_v || ','''',''' || rollback_seg_v || ''')' ;
        ELSE
            sql_stmt_v := sql_stmt_v || ')' ;
        END IF;
   END IF;
   WRITE_LOG_PRO ('I', no_error_c, proc_c, error_object_v, sql_stmt_v);
   BEGIN
        IF (refresh_method_p IS NULL) THEN
            IF (rollback_seg_v IS NULL) THEN
                dbms_mview.refresh(owner_v || '.' || mview_name_v, atomic_refresh => FALSE );
            ELSE
                dbms_mview.refresh(owner_v || '.' || mview_name_v,'',
                                        rollback_seg_v, atomic_refresh=>FALSE );
            END IF;
        ELSE
            IF (rollback_seg_v IS NULL) THEN
                dbms_mview.refresh(owner_v || '.' || mview_name_v,
                                        refresh_method_v, atomic_refresh => FALSE );
            ELSE
                dbms_mview.refresh(owner_v || '.' || mview_name_v,
                                        refresh_method_v , rollback_seg_v , atomic_refresh => FALSE );
            END IF;
        END IF;
   EXCEPTION
      WHEN OTHERS THEN
         RAISE;  -- reraise the exception
   END;
EXCEPTION
   WHEN no_privs_e THEN
      WRITE_LOG_PRO ('E', no_privs_c, proc_c, error_object_v, error_msgs_tab(no_privs_c));
      RAISE_APPLICATION_ERROR (no_privs_c, error_msgs_tab(no_privs_c), TRUE);
   WHEN invalid_option_e THEN
      WRITE_LOG_PRO ('E', invalid_option_c, proc_c, error_object_v,
                     error_msgs_tab (invalid_option_c));
      RAISE_APPLICATION_ERROR (invalid_option_c, error_msgs_tab (invalid_option_c), TRUE);
   WHEN OTHERS THEN
      WRITE_LOG_PRO ('E', SQLCODE, proc_c, error_object_v, SQLERRM);
      RAISE;  -- reraise the exception
END REFRESH_MVIEW_PRO;
--**********************************************
--  Sets the index as unusable (for loading), given the appropriate priveleges.
--  Use with rebuild index (REBUILD_INDEX_PRO)
--**********************************************
PROCEDURE SET_UNUSABLE_INDEX_PRO (owner_p IN VARCHAR2,
                                  index_name_p IN VARCHAR2,
                                  partition_type_p IN VARCHAR2 DEFAULT NULL,
                                  paritition_name_p IN VARCHAR2 DEFAULT NULL) AS
   proc_c         CONSTANT VARCHAR2(50) := 'SET_UNUSABLE_INDEX_PRO';
   owner_v        VARCHAR2(30) := UPPER(owner_p);
   index_name_v   VARCHAR2(30) := UPPER(index_name_p);
   error_object_v VARCHAR2(65) := owner_v || '.' || index_name_v;
   sql_stmt_v     VARCHAR2(1000);
   cid_v          INTEGER;
   no_privs_e     EXCEPTION;
   invalid_option_e EXCEPTION;
   missing_partition_e EXCEPTION;

BEGIN
   /* Check if user has the proper privs. */
   CHECK_PRIVS_PRO (USER, owner_v);
   --   alter index <index name > modify partition unusable;
   sql_stmt_v := 'ALTER INDEX ' || owner_v || '.' || index_name_v ;
   IF (partition_type_p IS NOT NULL) THEN
     IF (UPPER(partition_type_p) = 'P') THEN
        sql_stmt_v := sql_stmt_v || ' MODIFY PARTITION ';
     ELSIF (UPPER(partition_type_p) = 'S') THEN
        sql_stmt_v := sql_stmt_v || ' MODIFY SUBPARTITION ';
     ELSE
        RAISE invalid_option_e;
     END IF;
     IF (rtrim(paritition_name_p) IS NULL) THEN
        -- verify that we received a partition name
        RAISE missing_partition_e;
     END IF;
   sql_stmt_v := sql_stmt_v || paritition_name_p;
   END IF;
   sql_stmt_v := sql_stmt_v || ' UNUSABLE';
   -- dbms_output.put_line (sql_stmt_v);
   WRITE_LOG_PRO ('I', no_error_c, proc_c, error_object_v, sql_stmt_v);
   BEGIN
      /* Open new cursor and return cursor ID. */
      cid_v := DBMS_SQL.OPEN_CURSOR;
      /* Parse and immediately execute dynamic SQL statement. */
      DBMS_SQL.PARSE(cid_v, sql_stmt_v, DBMS_SQL.native);
      /* Close cursor. */
      DBMS_SQL.CLOSE_CURSOR(cid_v);
   EXCEPTION
      WHEN OTHERS THEN
         DBMS_SQL.CLOSE_CURSOR(cid_v);
         RAISE;  -- reraise the exception
   END;
EXCEPTION
   WHEN no_privs_e THEN
      WRITE_LOG_PRO( 'E', no_privs_c, proc_c, error_object_v, error_msgs_tab(no_privs_c));
      RAISE_APPLICATION_ERROR(no_privs_c, error_msgs_tab(no_privs_c), TRUE);
   WHEN invalid_option_e THEN
      WRITE_LOG_PRO ('E', invalid_option_c, proc_c, error_object_v,
                     error_msgs_tab (invalid_option_c));
      RAISE_APPLICATION_ERROR (invalid_option_c, error_msgs_tab (invalid_option_c), TRUE);
   WHEN missing_partition_e THEN
      WRITE_LOG_PRO ('E', missing_partition_c, proc_c, error_object_v,
                     error_msgs_tab (missing_partition_c));
      RAISE_APPLICATION_ERROR (missing_partition_c, error_msgs_tab (missing_partition_c), TRUE);
   WHEN OTHERS THEN
      WRITE_LOG_PRO( 'E', SQLCODE, proc_c, error_object_v, SQLERRM );
      RAISE;  -- reraise the exception
END SET_UNUSABLE_INDEX_PRO;
--**********************************************
--  Truncates the requested table/cluster, given the appropriate access.
--**********************************************
PROCEDURE TRUNCATE_OBJECT_PRO (object_type_p IN CHAR, object_owner_p IN VARCHAR2,
                               object_name_p IN VARCHAR2,
                               drop_storage_p IN BOOLEAN DEFAULT TRUE) AS
   proc_c                CONSTANT VARCHAR2(50) := 'TRUNCATE_OBJECT_PRO';
   object_type_v         CHAR := UPPER(object_type_p);
   object_owner_v        VARCHAR2(30) := UPPER(object_owner_p);
   object_name_v         VARCHAR2(30) := UPPER(object_name_p);
   error_object_v        VARCHAR2(95) := object_owner_v || '.' || object_name_v;
   sql_stmt_v            VARCHAR2(1000) := 'TRUNCATE ';
   cid_v                 INTEGER;
   no_privs_e            EXCEPTION;
   invalid_object_type_e EXCEPTION;
BEGIN
   /* Check if user has the proper privs. */
   CHECK_PRIVS_PRO (USER, object_owner_v);
   IF (object_type_v = 'T') THEN
      sql_stmt_v := sql_stmt_v || 'TABLE ';
   ELSIF (object_type_v = 'C') THEN
      sql_stmt_v := sql_stmt_v || 'CLUSTER ';
   ELSE
      RAISE invalid_object_type_e;
   END IF;
   sql_stmt_v := sql_stmt_v || object_owner_v || '.' || object_name_v;
   IF (drop_storage_p = TRUE) THEN
      sql_stmt_v := sql_stmt_v || ' DROP STORAGE';
   ELSE
      sql_stmt_v := sql_stmt_v || ' REUSE STORAGE';
   END IF;
   WRITE_LOG_PRO ('I', no_error_c, proc_c, error_object_v, sql_stmt_v);
   BEGIN
      /* Open new cursor and return cursor ID. */
      cid_v := DBMS_SQL.OPEN_CURSOR;
      /* Parse and immediately execute dynamic SQL statement. */
      DBMS_SQL.PARSE(cid_v, sql_stmt_v, DBMS_SQL.native);
      /* Close cursor. */
      DBMS_SQL.CLOSE_CURSOR(cid_v);
   EXCEPTION
      WHEN OTHERS THEN
         DBMS_SQL.CLOSE_CURSOR(cid_v);
         RAISE;  -- reraise the exception
   END;
EXCEPTION
   WHEN no_privs_e THEN
      WRITE_LOG_PRO ('E', no_privs_c, proc_c, error_object_v, error_msgs_tab(no_privs_c));
      RAISE_APPLICATION_ERROR (no_privs_c, error_msgs_tab(no_privs_c), TRUE);
   WHEN OTHERS THEN
      WRITE_LOG_PRO ('E', SQLCODE, proc_c, error_object_v, SQLERRM);
  RAISE;  -- reraise the exception
END;
--**********************************************
--  Truncates the requested partition or subpartition, given the appropriate access.
--**********************************************
PROCEDURE TRUNCATE_PARTITION_PRO (   partition_type_p IN VARCHAR2,
                                object_owner_p IN VARCHAR2,
                                object_name_p IN VARCHAR2,
                                partition_name_p IN VARCHAR2,
                                drop_storage_p IN BOOLEAN DEFAULT TRUE) AS
   proc_c                CONSTANT VARCHAR2(50) := 'TRUNCATE_PARTITION_PRO';
   object_type_v         CHAR := UPPER(partition_type_p);
   object_owner_v        VARCHAR2(30) := UPPER(object_owner_p);
   object_name_v         VARCHAR2(30) := UPPER(object_name_p);
   error_object_v        VARCHAR2(95) := object_owner_v || '.' || object_name_v;
   sql_stmt_v            VARCHAR2(1000) := 'ALTER TABLE ';
   cid_v                 INTEGER;
   no_privs_e            EXCEPTION;
   invalid_object_type_e EXCEPTION;
BEGIN
   /* Check if user has the proper privs. */
   CHECK_PRIVS_PRO (USER, object_owner_v);
   sql_stmt_v := sql_stmt_v || object_owner_v || '.' || object_name_v;
   IF (partition_type_p = 'P') THEN
      sql_stmt_v := sql_stmt_v || ' TRUNCATE PARTITION ';
   ELSIF (partition_type_p = 'S') THEN
      sql_stmt_v := sql_stmt_v || ' TRUNCATE SUBPARTITION ';
   ELSE
      RAISE invalid_object_type_e;
   END IF;
   sql_stmt_v := sql_stmt_v || partition_name_p;
   IF (drop_storage_p = TRUE) THEN
      sql_stmt_v := sql_stmt_v || ' DROP STORAGE';
   ELSE
      sql_stmt_v := sql_stmt_v || ' REUSE STORAGE';
   END IF;
   WRITE_LOG_PRO ('I', no_error_c, proc_c, error_object_v, sql_stmt_v);
   BEGIN
      /* Open new cursor and return cursor ID. */
      cid_v := DBMS_SQL.OPEN_CURSOR;
      /* Parse and immediately execute dynamic SQL statement. */
      DBMS_SQL.PARSE(cid_v, sql_stmt_v, DBMS_SQL.native);
      /* Close cursor. */
      DBMS_SQL.CLOSE_CURSOR(cid_v);
   EXCEPTION
      WHEN OTHERS THEN
         DBMS_SQL.CLOSE_CURSOR(cid_v);
         RAISE;  -- reraise the exception
   END;
EXCEPTION
   WHEN no_privs_e THEN
      WRITE_LOG_PRO ('E', no_privs_c, proc_c, error_object_v, error_msgs_tab(no_privs_c));
      RAISE_APPLICATION_ERROR (no_privs_c, error_msgs_tab(no_privs_c), TRUE);
   WHEN OTHERS THEN
      WRITE_LOG_PRO ('E', SQLCODE, proc_c, error_object_v, SQLERRM);
  RAISE;  -- reraise the exception
END;
--  Run at the beginning of every procedure call to initialize error messages and clean
--    up the log table.
BEGIN
   error_msgs_tab(no_error_c) := 'No error.';
   error_msgs_tab(no_privs_c) := 'You do not have the privilege to perform this ' ||
                                 'function on this object.';
   error_msgs_tab(invalid_option_c) := 'Invalid parameter option.';
   error_msgs_tab(index_not_defined_c) := 'Index definition not found.';
   error_msgs_tab(error_log_c) := 'Error writing to log table : ';
   error_msgs_tab(object_not_found_c) := 'Unable to find requested object.';
   error_msgs_tab(unique_index_not_found_c) := 'Index to support uniqueness does not exist.';
   error_msgs_tab(ts_readwrite_c) := 'Tablespace already read write mode.';
   error_msgs_tab(missing_partition_c) := 'Missing partition name.';
   DELETE FROM DB_TOOLS_LOG
   WHERE TIME_STAMP < TRUNC(SYSDATE) - 10;
   COMMIT;
END;
/
show error
