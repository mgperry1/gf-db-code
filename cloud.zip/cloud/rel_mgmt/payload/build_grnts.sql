SET HEADING OFF
SET FEEDBACK OFF
SET SERVEROUT ON SIZE 1000000
PROMPT build_grnts.sql

DECLARE
    CURSOR cur_grant IS
        SELECT 'GRANT '||privilege||' ON DBA_ORA.DB_'||
                       REPLACE(SUBSTR(table_name, 4), 'SCHEMA_ACCESS', 'ACCESS')||
                       ' TO '||grantee
        FROM dba_tab_privs
        WHERE table_name like 'GW%';

    CURSOR cur_revoke IS
        SELECT 'REVOKE '||privilege||' ON GW_MAINT_PROCS.'||table_name||' FROM '||grantee
        FROM dba_tab_privs
        WHERE table_name like 'GW%';
    var_sql VARCHAR2(32000);
BEGIN
     OPEN cur_grant;
     LOOP
         FETCH cur_grant
             INTO var_sql;
     EXIT WHEN cur_grant%NOTFOUND;
         BEGIN
             EXECUTE IMMEDIATE var_sql;
         EXCEPTION
            WHEN OTHERS THEN
               DBMS_OUTPUT.put_line(SUBSTR(SQLERRM, 1, 200));
         END;
     END LOOP;
/*     CLOSE cur_grant;
     OPEN cur_revoke;
     LOOP
         FETCH cur_revoke
             INTO var_sql;
     EXIT WHEN cur_revoke%NOTFOUND;
         BEGIN
             EXECUTE IMMEDIATE var_sql;
         EXCEPTION
            WHEN OTHERS THEN
               DBMS_OUTPUT.put_line(SUBSTR(SQLERRM, 1, 200));
         END;
     END LOOP;
     CLOSE cur_revoke;
*/
END;
/

