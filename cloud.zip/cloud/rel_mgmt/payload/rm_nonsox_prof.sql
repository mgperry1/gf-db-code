SET SERVEROUTPUT ON

DECLARE
    v_ignore         INTEGER;
    v_cursor1        NUMBER;
    v_profile        dba_profiles.profile%TYPE;
    v_cursor_str     VARCHAR2(2000);
    v_profile_str1   VARCHAR2(2000);
    v_profile_str2   VARCHAR2(2000);


    v_sqlcode       NUMBER;
    v_sqlerrm       VARCHAR2(512);

BEGIN

-- Reset DBMS_OUTPUT.
  DBMS_OUTPUT.DISABLE;
  DBMS_OUTPUT.ENABLE(50000);

v_profile_str1 := 'CREATE PROFILE DBS_EXCEPT LIMIT SESSIONS_PER_USER UNLIMITED ' || 
                  'CPU_PER_SESSION           UNLIMITED CPU_PER_CALL              UNLIMITED ' ||
                  'CONNECT_TIME              UNLIMITED IDLE_TIME                 UNLIMITED ' ||
                  'LOGICAL_READS_PER_SESSION UNLIMITED LOGICAL_READS_PER_CALL    UNLIMITED ' ||
                  'COMPOSITE_LIMIT           UNLIMITED PRIVATE_SGA               UNLIMITED ' ||
                  'FAILED_LOGIN_ATTEMPTS     UNLIMITED PASSWORD_LIFE_TIME        UNLIMITED ' ||
                  'PASSWORD_REUSE_TIME       UNLIMITED PASSWORD_REUSE_MAX        UNLIMITED ' ||
                  'PASSWORD_LOCK_TIME        UNLIMITED PASSWORD_GRACE_TIME       UNLIMITED ' ||
                  'PASSWORD_VERIFY_FUNCTION  NULL';

v_profile_str2 := 'CREATE PROFILE DBS_APPLICATION LIMIT SESSIONS_PER_USER        UNLIMITED ' ||
                  'CPU_PER_SESSION           UNLIMITED CPU_PER_CALL              UNLIMITED ' ||
                  'CONNECT_TIME              UNLIMITED IDLE_TIME                 UNLIMITED ' ||
                  'LOGICAL_READS_PER_SESSION UNLIMITED LOGICAL_READS_PER_CALL    UNLIMITED ' ||
                  'COMPOSITE_LIMIT           UNLIMITED PRIVATE_SGA               UNLIMITED ' ||
                  'FAILED_LOGIN_ATTEMPTS     UNLIMITED PASSWORD_LIFE_TIME        UNLIMITED ' ||
                  'PASSWORD_REUSE_TIME       UNLIMITED PASSWORD_REUSE_MAX        UNLIMITED ' ||
                  'PASSWORD_LOCK_TIME        UNLIMITED PASSWORD_GRACE_TIME       UNLIMITED ' ||
                  'PASSWORD_VERIFY_FUNCTION  verify_function';

v_cursor1 := DBMS_SQL.OPEN_CURSOR;

v_cursor_str := v_profile_str1;

SELECT DISTINCT profile INTO v_profile
FROM   dba_profiles
WHERE profile = 'DBS_EXCEPT';

IF v_profile <> 'DBS_EXCEPT' THEN
   DBMS_SQL.PARSE(v_cursor1, v_cursor_str, DBMS_SQL.V7);
   v_ignore := DBMS_SQL.EXECUTE(v_cursor1);
END IF;

v_cursor_str := v_profile_str2;

SELECT DISTINCT profile INTO v_profile
FROM   dba_profiles
WHERE profile = 'DBS_APPLICATION';

IF v_profile <> 'DBS_APPLICATION' THEN
   DBMS_SQL.PARSE(v_cursor1, v_cursor_str, DBMS_SQL.V7);
   v_ignore := DBMS_SQL.EXECUTE(v_cursor1);
END IF;

DBMS_SQL.CLOSE_CURSOR(v_cursor1);

EXCEPTION
  WHEN NO_DATA_FOUND THEN
       DBMS_SQL.PARSE(v_cursor1, v_cursor_str, DBMS_SQL.V7);
       v_ignore := DBMS_SQL.EXECUTE(v_cursor1);

  WHEN OTHERS THEN

-- out to SQL*PLUS any exceptions....
  DBMS_OUTPUT.PUT_LINE('EXCEPTION ERROR');
  v_sqlcode := SQLCODE;
  v_sqlerrm := SQLERRM;
  DBMS_OUTPUT.PUT_LINE(v_sqlcode || ',' || v_sqlerrm);

-- Close cursor before exiting.
  DBMS_SQL.CLOSE_CURSOR(v_cursor1);

END;
/
