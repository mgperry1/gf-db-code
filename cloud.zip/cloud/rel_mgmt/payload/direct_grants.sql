DEF grant_to_user=&1
GRANT SELECT ON dba_ora.db_tools_log to &grant_to_user;
GRANT EXECUTE ON dba_ora.db_load_tools to &grant_to_user;
GRANT SELECT ON dba_ora.db_tools_access to &grant_to_user;
GRANT SELECT ON dba_ora.db_tools_objects to &grant_to_user;
