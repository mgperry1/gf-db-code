REM name          rm_build_database_datafile.sql
REM version       1.00a
REM author        Angus Aull
REM 
REM purpose       build a script to remove the datafiles 
REM 
REM usage         rm_build_database_datafile.sql <DatabaeName> <spool file> 
REM 
REM parameters
REM 
REM Revisions
REM     Rev No.   Date          Description
REM     ================================================================
REM     1.0    03/2007         Original
REM **************************************************
REM select 'rm -f '||file_name from dba_data_files;
REM select 'rm -f '||member from v$logfile;
REM select 'rm -f '||name from v$controlfile;
REM select 'rm -f '||file_name from dba_temp_files;


SET VERIFY OFF
DEF DATABSE=&1
DEF SPOOLFILE=&2
SET SERVEROUT ON SIZE 1000000
SET FEEDBACK OFF

COLUMN version NEW_VALUE chk_proc_version NOPRINT
COLUMN input_users NEW_VALUE user_list NOPRINT

SPOOL &SPOOLFILE
PROMPT Database= &DATABSE
PROMPT Spool file = &SPOOLFILE

SET TERMOUT OFF

DECLARE
    CURSOR cur_get_version
    IS
        SELECT DECODE(SUBSTR(version, 1, INSTR(version, '.') -1), '8', '_8', NULL) version
        FROM v$instance;

    CURSOR cur_tablespace_files
    IS
    	SELECT file_name
        FROM dba_data_files 
        UNION
        SELECT file_name
        FROM dba_temp_files
        UNION
        SELECT member
        FROM v$logfile
        UNION 
        SELECT name 
        FROM v$controlfile
    	ORDER BY 1;

    var_out_string          VARCHAR2(32000);
    var_version             VARCHAR2(50);

BEGIN
    OPEN cur_get_version;
        FETCH cur_get_version
            INTO var_version;
    CLOSE cur_get_version;
    OPEN cur_tablespace_files;
    LOOP
        FETCH cur_tablespace_files
            INTO var_out_string;
    EXIT WHEN cur_tablespace_files%NOTFOUND;
        DBMS_OUTPUT.put_line('DATAFILE: '||var_out_string);
    END LOOP;
    CLOSE cur_tablespace_files;
    DBMS_OUTPUT.put_line('Completed Succesfully');
END;
/

SPOOL OFF
EXIT


