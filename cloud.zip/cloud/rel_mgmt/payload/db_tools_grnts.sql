REM db_tools_grnts.sql
REM Creates ROLE and grants accesses

connect dba_ora/&dba_ora_pwd
CREATE ROLE db_tool_access;
GRANT SELECT  ON db_tools_log           TO db_tool_access;
GRANT SELECT  ON db_tools_objects       TO db_tool_access;
GRANT SELECT
     ,INSERT
     ,DELETE  ON db_tools_schema_access TO db_tool_access;
GRANT EXECUTE ON dba_ora.db_load_tools  TO db_tool_access;

GRANT db_tool_access                    TO db_app_dba WITH ADMIN OPTION;
