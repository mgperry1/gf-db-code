SET SERVEROUT ON size 1000000

DECLARE
	CURSOR cur_get IS
		SELECT *
		FROM all_sequences
		WHERE sequence_owner = 'DBA_ORA'
		AND sequence_name = 'DB_TOOLS_LOG_SEQ';
	var_rec cur_get%ROWTYPE;
BEGIN
	OPEN cur_get;
	FETCH cur_get INTO var_rec;
	IF cur_get%NOTFOUND THEN
		EXECUTE IMMEDIATE 'CREATE SEQUENCE DBA_ORA.DB_TOOLS_LOG_SEQ START WITH 1 INCREMENT BY 1';
		DBMS_OUTPUT.put_line ('Sequece DB_TOOLS_LOG_SEQ Created');
	ELSE
		DBMS_OUTPUT.put_line ('DB_TOOLS_LOG_SEQ exists');
	END IF;
	CLOSE cur_get;
EXCEPTION 
    WHEN OTHERS THEN
        DBMS_OUTPUT.put_line(SUBSTR(SQLERRM, 1, 200));
END;
/
