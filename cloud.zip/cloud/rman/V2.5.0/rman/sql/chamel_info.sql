---
--- $Id: //depot/rman/sql/chamel_info.sql#3 $ 
--- $Header: //depot/rman/sql/chamel_info.sql#3 $  
--- $Date: 2011/08/31 $ 
--- $DateTime: 2011/08/31 15:34:40 $ 
--- $Change: 1827 $ 
--- $File: //depot/rman/sql/chamel_info.sql $ 
--- $Revision: #3 $ 
--- $Author: dfp0908 $
---
set linesize 400
set pagesize 0
set heading off
set feedback off
set trimspool on
set timing off
whenever sqlerror exit
whenever oserror exit
set heading off echo off verify off serveroutput off
spool ${ORADBA_HOME}/rman/config/${ORACLE_SID}_chameleon_new.ksh
select 'export DBID='||DBID FROM V$DATABASE;
select 'export ORACLE_VERSION='||VERSION FROM V$INSTANCE;
select 'export ORACLE_MVERSION='||SUBSTR(VERSION, 1, INSTR(VERSION,'.')-1) FROM V$INSTANCE;
select 'export DB_CHAMELEON_ID='''||COMP_INV_ID||'''' FROM DBA_ORA.DATABASE_INFORMATION;
select 'export DB_SIZE='||round(sum(bytes)/1048576) FROM v$datafile;
spool off
host cp ${ORADBA_HOME}/rman/config/${ORACLE_SID}_chameleon_new.ksh ${ORADBA_HOME}/rman/config/${ORACLE_SID}_chameleon.ksh
host chmod +x "${ORADBA_HOME}/rman/config/${ORACLE_SID}_chameleon.ksh"
exit;
