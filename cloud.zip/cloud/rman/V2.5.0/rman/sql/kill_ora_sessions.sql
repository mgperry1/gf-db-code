---
--- $Id: //depot/rman/sql/kill_ora_sessions.sql#4 $ 
--- $Header: //depot/rman/sql/kill_ora_sessions.sql#4 $ 
--- $Date: 2006/01/26 $ 
--- $DateTime: 2006/01/26 15:27:17 $ 
--- $Change: 954 $ 
--- $File: //depot/rman/sql/kill_ora_sessions.sql $ 
--- $Revision: #4 $ 
--- $Author: dfp0908 $
---
set head off
set feedback off;
set linesize 90;
set verify off;
spool &1
select 'set term off' from sys.dual;
select 'spool '||'&1'||'.tmp' from sys.dual;
select 'alter system set job_queue_processes=0'||decode(substr(version,1,1),8,'',' scope=memory')||';' from sys.v$instance;

select 'alter system kill session '''||sid||', '||serial#||''';' 
  from v$session
 where schemaname <> 'SYS'
   and schemaname <> 'OPS$ORACLE' 
   and schemaname <> 'ORACLE';
select 'spool off;' from sys.dual;
spool off;
@&1
exit

