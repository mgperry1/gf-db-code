---
--- $Id: //depot/rman/sql/db_control.sql#1 $ 
--- $Header: //depot/rman/sql/db_control.sql#1 $ 
--- $Date: 2005/02/15 $ 
--- $DateTime: 2005/02/15 07:49:55 $ 
--- $Change: 718 $ 
--- $File: //depot/rman/sql/db_control.sql $ 
--- $Revision: #1 $ 
--- $Author: dfp0908 $
---
accept filename PROMPT 'Enter location to Backup the controlfile:'
alter database backup controlfile to '&filename';
