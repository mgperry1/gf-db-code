---
--- $Id: //depot/rman/sql/dataguard_info.sql#1 $ 
--- $Header: //depot/rman/sql/dataguard_info.sql#1 $ 
--- $Date: 2005/12/12 $ 
--- $DateTime: 2005/12/12 13:17:32 $ 
--- $Change: 901 $ 
--- $File: //depot/rman/sql/dataguard_info.sql $ 
--- $Revision: #1 $ 
--- $Author: dfp0908 $
---
set feedback off
set pagesize 0
set echo off
select count(value) from v$parameter 
 where name like 'log_archive_dest%' 
   and upper(value) like '%SERVICE%';
exit;
