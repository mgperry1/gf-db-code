---
--- $Id: //depot/rman/sql/db_info.sql#8 $ 
--- $Header: //depot/rman/sql/db_info.sql#8 $ 
--- $Date: 2010/02/24 $ 
--- $DateTime: 2010/02/24 16:45:37 $ 
--- $Change: 1767 $ 
--- $File: //depot/rman/sql/db_info.sql $ 
--- $Revision: #8 $ 
--- $Author: dfp0908 $
---
set feedback off
set pagesize 0
set echo off
select a.value || '_' || b.value || '.' || c.value || ',' ||
       d.log_mode || ',' || substr(e.banner,1,8) || ',' || d.name
  from v$nls_parameters a,
       v$nls_parameters b,
       v$nls_parameters c,
       V$database d,
       v$version e
 where a.parameter = 'NLS_LANGUAGE'
   and b.parameter = 'NLS_TERRITORY'
   and c.parameter = 'NLS_CHARACTERSET'
   and e.banner like '%Oracle%'
   and e.banner like '%Release%';
exit;
