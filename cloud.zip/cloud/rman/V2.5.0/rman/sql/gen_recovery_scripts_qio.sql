---
--- $Id: //depot/rman/sql/gen_recovery_scripts_qio.sql#2 $ 
--- $Header: //depot/rman/sql/gen_recovery_scripts_qio.sql#2 $ 
--- $Date: 2004/11/03 $ 
--- $DateTime: 2004/11/03 14:07:44 $ 
--- $Change: 529 $ 
--- $File: //depot/rman/sql/gen_recovery_scripts_qio.sql $ 
--- $Revision: #2 $ 
--- $Author: dfp0908 $
---
set linesize 400
set pagesize 0
set heading off
set feedback off
set trimspool on
set timing off
set heading off echo off verify off serveroutput off
--
-- This SQL will create a script for generating the data directory tree(s) for a database.
-- It assumed that the mount point exists and oradata parent directory exists.
--
col "Mount Points" for a120
prompt
spool ${ORADBA_HOME}/rman/recovery_scripts/${ORACLE_SID}_mkdir.ksh
select unique 'mkdir -p ' || substr(file_name,1,instr(file_name,'/',-1,1)) "Mount Points"
  from dba_data_Files
union
select unique 'mkdir -p ' || substr(name,1,instr(name,'/',-1,1)) "Mount Points"
  from v$controlfile
union
select unique 'mkdir -p ' || substr(member,1,instr(member,'/',-1,1)) "Mount Points"
  from v$logfile
union
select unique 'mkdir -p ' || substr(name,1,instr(name,'/',-1,1)) "Mount Points"
  from v$tempfile
 order by 1;
spool off
host chmod 660 ${ORADBA_HOME}/rman/recovery_scripts/${ORACLE_SID}_mkdir.ksh
--
-- This SQL will create a script for removing all datafiles for a database
--
spool ${ORADBA_HOME}/rman/recovery_scripts/${ORACLE_SID}_remove_files.ksh
select '\rm ' || file_name,
       '\rm ' || substr(file_name,1,instr(file_name,'/',-1,1)) || '.' || substr(file_name,instr(file_name,'/',-1,1)+1)
  from dba_data_files
 where file_name not like '%::cdev:vxfs:'
/
select '\rm ' || substr(file_name,1,instr(file_name,'::cdev',-1,1) - 1),
       '\rm ' || substr(file_name,1,instr(file_name,'.',-1,2) - 1) ||
       substr(file_name,instr(file_name,'.',-1,2)+1,instr(file_name,'::cdev',-1,1) - (instr(file_name,'.',-1,2)+1))
  from dba_data_files
 where file_name like '%::cdev:vxfs:'
/
select '\rm ' || member,
       '\rm ' || substr(member,1,instr(member,'/',-1,1)) || '.' || substr(member,instr(member,'/',-1,1)+1)
  from v$logfile
/
select '\rm ' || name from v$controlfile
/
select '\rm ' || name,
       '\rm ' || substr(name,1,instr(name,'/',-1,1)) || '.' || substr(name,instr(name,'/',-1,1)+1)
  from v$tempfile
/
spool off
host chmod 660 ${ORADBA_HOME}/rman/recovery_scripts/${ORACLE_SID}_remove_files.ksh
--
-- This SQL will create a script to create the quick i/o files
--
spool ${ORADBA_HOME}/rman/recovery_scripts/${ORACLE_SID}_create_qio_files.ksh
select '/opt/VRTSvxfs/sbin/qiomkfile -a -h ' || value || ' -s ' || bytes/1024 || 'k ' || file_name 
  from dba_data_files, v$parameter
 where name = 'db_block_size'
   and instr(file_name,'.',-1,2) = 0
   and file_name not like '%::cdev:vxfs:'
/
select '/opt/VRTSvxfs/sbin/qiomkfile -a -h ' || value || ' -s ' || bytes/1024 || 'k ' ||
       substr(file_name,1,instr(file_name,'.',-1,2) - 1) || 
       substr(file_name,instr(file_name,'.',-1,2)+1,instr(file_name,'::cdev',-1,1) - (instr(file_name,'.',-1,2)+1))
  from dba_data_files, v$parameter 
 where name = 'db_block_size'
   and file_name like '%::cdev:vxfs:'
/
select '/opt/VRTSvxfs/sbin/qiomkfile -a -h ' || value || ' -s ' || bytes/1024 || 'k ' || member
  from v$logfile, v$log, v$parameter
 where name = 'db_block_size'
   and v$logfile.group# = v$log.group#
/
select '/opt/VRTSvxfs/sbin/qiomkfile -a -h ' || value || ' -s ' || bytes/1024 || 'k ' || t.name
  from v$tempfile t, v$parameter p
 where p.name = 'db_block_size'
/
spool off
host chmod 660 ${ORADBA_HOME}/rman/recovery_scripts/${ORACLE_SID}_create_qio_files.ksh
--
-- This SQL will create a script for adding the tempfiles to the temporary tablespace
--
spool ${ORADBA_HOME}/rman/recovery_scripts/${ORACLE_SID}_create_temp_ddl.sql
select 'create_temp_ddl_${ORACLE_SID}.log'
  from dual;
select 'set echo on'
  from dual;
select 'alter tablespace ' || tablespace_name || ' add tempfile ', chr(39) || file_name || chr(39) || ' size ' ||
        bytes/1024 || 'K reuse;' 
  from dba_temp_files;
select 'spool off'
  from dual;
spool off

alter system switch logfile;
