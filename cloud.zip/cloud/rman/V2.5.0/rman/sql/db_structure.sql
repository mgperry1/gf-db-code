---
--- $Id: //depot/rman/sql/db_structure.sql#1 $ 
--- $Header: //depot/rman/sql/db_structure.sql#1 $ 
--- $Date: 2009/06/12 $ 
--- $DateTime: 2009/06/12 15:41:06 $ 
--- $Change: 1729 $ 
--- $File: //depot/rman/sql/db_structure.sql $ 
--- $Revision: #1 $ 
--- $Author: dfp0908 $
---
set linesize 400
set pagesize 0
set heading off
set feedback off
set trimspool on
set timing off
whenever sqlerror exit
whenever oserror exit 
set heading off echo off verify off serveroutput off
SELECT 'DATABASE INFO GENERATED - '||SYSDATE FROM DUAL;
SELECT 'DATA:'||ts#||':'||file#||':'||name||':'||bytes "DBINFO" FROM V$DATAFILE
UNION
SELECT 'TEMP:'||ts#||':'||file#||':'||name||':'||bytes FROM V$TEMPFILE
UNION
SELECT 'REDO:'||lf.group#||':'||lf.member||':'||l.bytes FROM V$LOGFILE lf, V$LOG l
WHERE lf.group# = l.group#
UNION
SELECT 'CONTROL:'||name FROM V$CONTROLFILE
UNION
SELECT 'TABLESPACE:'||ts#||':'||name FROM V$TABLESPACE;
exit;


