---
--- $Id: //depot/rman/sql/pre_archivelog_backup.sql#2 $ 
--- $Header: //depot/rman/sql/pre_archivelog_backup.sql#2 $ 
--- $Date: 2004/11/03 $ 
--- $DateTime: 2004/11/03 14:07:44 $ 
--- $Change: 529 $ 
--- $File: //depot/rman/sql/pre_archivelog_backup.sql $ 
--- $Revision: #2 $ 
--- $Author: dfp0908 $
---
alter system switch logfile;
exit
