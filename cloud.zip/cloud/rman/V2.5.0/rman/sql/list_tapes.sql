---
--- $Id: //depot/rman/sql/list_tapes.sql#2 $ 
--- $Header: //depot/rman/sql/list_tapes.sql#2 $ 
--- $Date: 2011/08/31 $ 
--- $DateTime: 2011/08/31 15:34:40 $ 
--- $Change: 1827 $ 
--- $File: //depot/rman/sql/list_tapes.sql $ 
--- $Revision: #2 $ 
--- $Author: dfp0908 $
---
col "PIECE_MEDIA" for a140
col "BACKUP_PIECE_INFO" for a140
col "ARCHIVE_PIECE_INFO" for a140
set linesize 180 
set pagesize 1200
set heading off
set verify off
SELECT 
  'PIECEINFO,'||
  HANDLE||','||
  MEDIA||','||
  TO_CHAR(START_TIME, 'DD-Mon-YYYY HH24:MI:SS')||','||
  TO_CHAR(COMPLETION_TIME, 'DD-Mon-YYYY HH24:MI:SS')||','||
  TO_CHAR(ROUND((COMPLETION_TIME - START_TIME)*(60*24),0)) "PIECE_MEDIA" 
FROM V$BACKUP_PIECE 
WHERE HANDLE LIKE '%&1%'
ORDER BY 1;
--
SELECT 'PIECEDF:'||BP.HANDLE||':'||BF.FILE#||':'||BF.DATAFILE_BLOCKS||':'||BF.BLOCKS||':'||BF.BLOCK_SIZE||':'||
       (BF.DATAFILE_BLOCKS+1)*BF.BLOCK_SIZE||':'||(BF.BLOCKS+1)*BF.BLOCK_SIZE||':'||
       round((BF.BLOCKS+1)*BF.BLOCK_SIZE*100/((BF.DATAFILE_BLOCKS+1)*BF.BLOCK_SIZE),0) "BACKUP_PIECE_INFO"
FROM V$BACKUP_PIECE BP, V$BACKUP_DATAFILE BF
WHERE BP.SET_STAMP = BF.SET_STAMP
  AND BP.SET_COUNT = BF.SET_COUNT
  AND BP.HANDLE like '%&1%' 
ORDER by BP.HANDLE, BF.FILE#;
--
SELECT 'PIECEAR:'||BP.HANDLE||':'||BR.THREAD#||':'||BR.SEQUENCE#||':'||BR.BLOCKS||':'||BR.BLOCK_SIZE "ARCHIVE_PIECE_INFO"
FROM V$BACKUP_PIECE BP, V$BACKUP_REDOLOG BR
WHERE BP.SET_STAMP = BR.SET_STAMP
  AND BP.SET_COUNT = BR.SET_COUNT
  AND BP.HANDLE like '%&1%' 
ORDER by BP.HANDLE, BR.THREAD#, BR.SEQUENCE#
/
exit
