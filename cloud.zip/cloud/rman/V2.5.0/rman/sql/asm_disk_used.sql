---
--- $Id: //depot/rman/sql/asm_disk_used.sql#1 $ 
--- $Header: //depot/rman/sql/asm_disk_used.sql#1 $ 
--- $Date: 2009/06/12 $ 
--- $DateTime: 2009/06/12 15:41:06 $ 
--- $Change: 1729 $ 
--- $File: //depot/rman/sql/asm_disk_used.sql $ 
--- $Revision: #1 $ 
--- $Author: dfp0908 $
---
set feedback off
set pagesize 0 
set echo off
select ltrim(round(((total_mb - free_mb)/total_mb)*100,0)) usage from v$asm_diskgroup where name='ARCHIVE';
exit;
