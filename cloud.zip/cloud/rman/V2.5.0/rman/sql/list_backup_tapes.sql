---
--- $Id: //depot/rman/sql/list_backup_tapes.sql#4 $ 
--- $Header: //depot/rman/sql/list_backup_tapes.sql#4 $ 
--- $Date: 2011/08/31 $ 
--- $DateTime: 2011/08/31 15:34:40 $ 
--- $Change: 1827 $ 
--- $File: //depot/rman/sql/list_backup_tapes.sql $ 
--- $Revision: #4 $ 
--- $Author: dfp0908 $
---
connect / as sysdba
col "Tapes Required" for a40
set verify off
select 'PULL TAPELIST FROM PORTAL (USPRD700)' "Tapes Required" FROM DUAL;
exit;
