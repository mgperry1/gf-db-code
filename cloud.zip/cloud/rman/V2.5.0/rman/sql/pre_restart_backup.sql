---
--- $Id: //depot/rman/sql/pre_restart_backup.sql#3 $ 
--- $Header: //depot/rman/sql/pre_restart_backup.sql#3 $  
--- $Date: 2009/06/12 $ 
--- $DateTime: 2009/06/12 10:46:35 $ 
--- $Change: 1726 $ 
--- $File: //depot/rman/sql/pre_restart_backup.sql $ 
--- $Revision: #3 $ 
--- $Author: dfp0908 $
---
@${ORADBA_HOME}/rman/sql/gen_recovery_scripts.sql
shutdown immediate
startup restrict
alter system switch logfile;
shutdown
startup
exit
