---
--- $Id: //depot/rman/sql/create_rman_rcvry_tbs.sql#1 $ 
--- $Header: //depot/rman/sql/create_rman_rcvry_tbs.sql#1 $ 
--- $Date: 2009/06/12 $ 
--- $DateTime: 2009/06/12 15:41:06 $ 
--- $Change: 1729 $ 
--- $File: //depot/rman/sql/create_rman_rcvry_tbs.sql $ 
--- $Revision: #1 $ 
--- $Author: dfp0908 $
---
create tablespace rman_rcvry_tbs datafile '/oracle/u03/oradata/usprd463/rman_rcvry_tbs.dbs' size 2M;                    
create table rman_rcvry_tbl tablespace rman_rcvry_tbs as select tablespace_name, status from dba_tablespaces;            
commit;                                                                                                                 
