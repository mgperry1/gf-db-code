---
--- $Id: //depot/rman/sql/rman_rcvry_tst_bld.sql#2 $ 
--- $Header: //depot/rman/sql/rman_rcvry_tst_bld.sql#2 $ 
--- $Date: 2005/04/27 $ 
--- $DateTime: 2005/04/27 13:37:39 $ 
--- $Change: 756 $ 
--- $File: //depot/rman/sql/rman_rcvry_tst_bld.sql $ 
--- $Revision: #2 $ 
--- $Author: dfp0908 $
---
set verify off
set newpage 0
set space 0
set pagesize 0
set linesize 120
set echo off
set heading off
set feedback off
set show off
prompt Enter the storage location for the recovery test table space.
prompt For example: /oracle/u01/oradata/usprd999
accept tbs_file_loc prompt 'Location: '
spool create_rman_rcvry_tbs.sql
select 'create tablespace rman_rcvry_tbs datafile '''||'&tbs_file_loc'||'/rman_rcvry_tbs.dbs'||''' size 2M;'
from dual;
select 'create table rman_rcvry_tbl tablespace rman_rcvry_tbs as select tablespace_name, status from dba_tablespaces;'
from dual;
select 'commit;' 
from dual;
spool off;
spool delete_rman_rcvry_tbs_file.ksh
select '#! /bin/ksh -xv' 
from dual;
select 'rm '||'&tbs_file_loc'||'/rman_rcvry_tbs.dbs' 
from dual;
spool off;
spool drop_rman_rcvry_tbs.sql
select 'drop tablespace rman_rcvry_tbs including contents;' 
from dual;
spool off;
