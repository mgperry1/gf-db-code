---
--- $Id: //depot/rman/sql/gen_recovery_scripts.sql#3 $  
--- $Header: //depot/rman/sql/gen_recovery_scripts.sql#3 $ 
--- $Date: 2009/06/12 $ 
--- $DateTime: 2009/06/12 10:46:35 $ 
--- $Change: 1726 $ 
--- $File: //depot/rman/sql/gen_recovery_scripts.sql $ 
--- $Revision: #3 $ 
--- $Author: dfp0908 $
---
set linesize 400
set pagesize 0
set heading off
set feedback off
set trimspool on
set timing off
set heading off echo off verify off serveroutput off
whenever sqlerror exit
whenever oserror exit
--
-- This script will create a script for generating the data directory tree(s) for a database.
-- It assumed that the mount point exists and oradata parent directory exists.
--
col "Mount Points" for a120
prompt
spool ${ORADBA_HOME}/rman/recovery_scripts/${ORACLE_SID}_mkdir.ksh
select unique 'mkdir -p ' || substr(name,1,instr(name,'/',-1,1)) "Mount Points"
  from v$datafile
union
select unique 'mkdir -p ' || substr(name,1,instr(name,'/',-1,1)) "Mount Points"
  from v$controlfile
union
select unique 'mkdir -p ' || substr(member,1,instr(member,'/',-1,1)) "Mount Points"
  from v$logfile
union
select unique 'mkdir -p ' || substr(name,1,instr(name,'/',-1,1)) "Mount Points"
  from v$tempfile
 order by 1;
spool off
host chmod 660 ${ORADBA_HOME}/rman/recovery_scripts/${ORACLE_SID}_mkdir.ksh
--
-- This script will create a script for removing all datafiles for a database
--
spool ${ORADBA_HOME}/rman/recovery_scripts/${ORACLE_SID}_remove_files.ksh
select '\rm ' || name from v$datafile
/
select '\rm ' || member from v$logfile
/
select '\rm ' || name from v$controlfile
/
select '\rm ' || name from v$tempfile
/
spool off
host chmod 660 ${ORADBA_HOME}/rman/recovery_scripts/${ORACLE_SID}_remove_files.ksh
--
-- This script will create a script for adding the tempfiles to the temporary tablespace
--
spool ${ORADBA_HOME}/rman/recovery_scripts/${ORACLE_SID}_create_temp_ddl.sql
select 'set echo on'
  from dual;
select 'alter tablespace ' || ts.name || ' add tempfile ', chr(39) || tf.name || chr(39) || ' size ' ||
        bytes/1024 || 'K reuse;'
  from v$tablespace ts, v$tempfile tf
 where ts.ts# = tf.ts#;
select 'spool off'
  from dual;
spool off

alter system switch logfile;
