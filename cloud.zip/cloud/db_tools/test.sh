sqlplus -silent /nolog @test.sql &
