connect system/password@database
set timing on
set termout off
spool /dev/null
select * from dba_source
where rownum < 25000  
/
spool off
exit
