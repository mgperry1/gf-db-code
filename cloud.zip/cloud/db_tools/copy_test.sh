#!/bin/sh -x
scp -p /oracle/nfs/share/Oracle_software/db_tools/monitor_sqlnet_procs.ksh rtpsduxrac5:/oracle/dba/dba_ora/bin/monitor_sqlnet_procs.ksh
scp -p /oracle/nfs/share/Oracle_software/db_tools/monitor_sqlnet_procs.ksh rtpsduxrac6:/oracle/dba/dba_ora/bin/monitor_sqlnet_procs.ksh
scp -p /oracle/nfs/share/Oracle_software/db_tools/monitor_sqlnet_procs.ksh rtpsduxrac7:/oracle/dba/dba_ora/bin/monitor_sqlnet_procs.ksh
scp -p /oracle/nfs/share/Oracle_software/db_tools/monitor_sqlnet_procs.ksh rtpsduxrac8:/oracle/dba/dba_ora/bin/monitor_sqlnet_procs.ksh
scp -p /oracle/nfs/share/Oracle_software/db_tools/monitor_sqlnet_procs.ksh rtpsduxrac11:/oracle/dba/dba_ora/bin/monitor_sqlnet_procs.ksh
scp -p /oracle/nfs/share/Oracle_software/db_tools/monitor_sqlnet_procs.ksh rtpsduxrac12:/oracle/dba/dba_ora/bin/monitor_sqlnet_procs.ksh
scp -p /oracle/nfs/share/Oracle_software/db_tools/monitor_sqlnet_procs.ksh kopsduxrac5:/oracle/dba/dba_ora/bin/monitor_sqlnet_procs.ksh
scp -p /oracle/nfs/share/Oracle_software/db_tools/monitor_sqlnet_procs.ksh kopsduxrac6:/oracle/dba/dba_ora/bin/monitor_sqlnet_procs.ksh
scp -p /oracle/nfs/share/Oracle_software/db_tools/monitor_sqlnet_procs.ksh bresduxrac001:/oracle/dba/dba_ora/bin/monitor_sqlnet_procs.ksh
scp -p /oracle/nfs/share/Oracle_software/db_tools/monitor_sqlnet_procs.ksh bresduxrac002:/oracle/dba/dba_ora/bin/monitor_sqlnet_procs.ksh
scp -p /oracle/nfs/share/Oracle_software/db_tools/monitor_sqlnet_procs.ksh bresduxrac003:/oracle/dba/dba_ora/bin/monitor_sqlnet_procs.ksh
scp -p /oracle/nfs/share/Oracle_software/db_tools/monitor_sqlnet_procs.ksh bresduxrac004:/oracle/dba/dba_ora/bin/monitor_sqlnet_procs.ksh
scp -p /oracle/nfs/share/Oracle_software/db_tools/monitor_sqlnet_procs.ksh bresduxrac005:/oracle/dba/dba_ora/bin/monitor_sqlnet_procs.ksh
scp -p /oracle/nfs/share/Oracle_software/db_tools/monitor_sqlnet_procs.ksh bresduxrac006:/oracle/dba/dba_ora/bin/monitor_sqlnet_procs.ksh
scp -p /oracle/nfs/share/Oracle_software/db_tools/monitor_sqlnet_procs.ksh bresduxrac007:/oracle/dba/dba_ora/bin/monitor_sqlnet_procs.ksh
scp -p /oracle/nfs/share/Oracle_software/db_tools/monitor_sqlnet_procs.ksh bresduxrac008:/oracle/dba/dba_ora/bin/monitor_sqlnet_procs.ksh
