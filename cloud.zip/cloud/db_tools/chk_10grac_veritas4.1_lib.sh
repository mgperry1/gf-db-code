echo "Checking Veritas 4.1 Libraries used by Oracle10g RAC software"
echo ""
echo "Below is the correct Veritas IPC 64bit library for Oracle10g 64bit in /opt/VRTSvcs/rac/lib directory"
echo ""
ls -l /opt/VRTSvcs/rac/lib/libskgxp102_64.so
echo ""
echo "Below is the current IPC libraries for Oracle10g 64bit in ORACLE_HOME/lib software directories"
echo ""
find /oracle/app/oracle/product -name libskgxp10.so -exec ls -l {} \;
echo ""
echo "The IPC libraries in the ORACLE_HOME/lib directories above should be the same size as in Veritas directory"
echo ""
echo ""
echo ""
#echo "Below is the correct Veritas Memory Module (MM) 64bit library for Oracle10g 64bit in /opt/VRTSvcs/rac/lib library"
#echo ""
#ls -l /opt/VRTSvcs/rac/lib/libskgxn2_64.so.1
# echo ""
#echo "Below are the current MM libraries for Oracle10g 64bit in ORACLE_HOME/lib software directories"
#echo ""
#find /oracle/app/oracle/product -name libskgxn9.so -exec ls -l {} \;
#echo ""
#echo "The MM libraries in the ORACLE_HOME/lib directories above should be the same size as in Veritas directory"
#echo ""
#echo ""
echo "Below is the correct Veritas ODM library in /opt/VRTSodm/lib/libodm.so library"
echo ""
ls -l /opt/VRTSodm/lib/libodm.so
ls -l /opt/VRTSodm/lib/libodm.so.1
echo ""
echo "The /usr/lib/sparcv9/libodm.so file below should be a symbolic link to /opt/VRTSodm/lib/libodm.so library."
echo ""
ls -l /usr/lib/sparcv9/libodm.so
echo ""
echo "Below are the current ODM libraries in ORACLE_HOME/lib software directories"
echo ""
find /oracle/app/oracle/product -name libodm10.so -exec ls -l {} \;
echo "The ODM libraries in the ORACLE_HOME/lib directories above should be a symbolic link to /usr/lib/libodm.so"

